function ri = Modelri

ri = [];

