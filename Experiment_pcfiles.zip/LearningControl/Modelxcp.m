function xcp = Modelxcp

xcp.events     =  repmat(struct('id',{}, 'sampletime', {}, 'offset', {}), getNumEvents, 1 );
xcp.parameters =  repmat(struct('symbol',{}, 'size', {}, 'dtname', {}, 'baseaddr', {}), getNumParameters, 1 );
xcp.signals    =  repmat(struct('symbol',{}), getNumSignals, 1 );
xcp.models     =  cell(1,getNumModels);
    
xcp.models{1} = 'Model';
   
   
         
xcp.events(1).id         = 0;
xcp.events(1).sampletime = 0.0001;
xcp.events(1).offset     = 0.0;
    
xcp.signals(1).symbol =  'Model_B.Error';
    
xcp.signals(2).symbol =  'Model_B.Velocity';
    
xcp.signals(3).symbol =  'Model_B.Position';
    
xcp.signals(4).symbol =  'Model_B.CommAngle';
    
xcp.signals(5).symbol =  'Model_B.ClampAnl';
    
xcp.signals(6).symbol =  'Model_B.ShearAnl';
    
xcp.signals(7).symbol =  'Model_B.reference';
    
xcp.signals(8).symbol =  'Model_B.error';
    
xcp.signals(9).symbol =  'Model_B.Sum_g';
    
xcp.signals(10).symbol =  'Model_B.IO397AnalogInput_o1';
    
xcp.signals(11).symbol =  'Model_B.IO397AnalogInput_o2';
    
xcp.signals(12).symbol =  'Model_B.IO397AnalogInput_o3';
    
xcp.signals(13).symbol =  'Model_B.IO397AnalogInput_o4';
    
xcp.signals(14).symbol =  'Model_B.IO397AnalogInput1_o1';
    
xcp.signals(15).symbol =  'Model_B.IO397AnalogInput1_o2';
    
xcp.signals(16).symbol =  'Model_B.Clock';
    
xcp.signals(17).symbol =  'Model_B.Output';
    
xcp.signals(18).symbol =  'Model_B.LookUpTable1';
    
xcp.signals(19).symbol =  'Model_B.MathFunction';
    
xcp.signals(20).symbol =  'Model_B.Sum';
    
xcp.signals(21).symbol =  'Model_B.Clock_h';
    
xcp.signals(22).symbol =  'Model_B.Output_a';
    
xcp.signals(23).symbol =  'Model_B.LookUpTable1_d';
    
xcp.signals(24).symbol =  'Model_B.MathFunction_e';
    
xcp.signals(25).symbol =  'Model_B.Sum_d';
    
xcp.signals(26).symbol =  'Model_B.Clock_f';
    
xcp.signals(27).symbol =  'Model_B.Output_d';
    
xcp.signals(28).symbol =  'Model_B.LookUpTable1_b';
    
xcp.signals(29).symbol =  'Model_B.MathFunction_a';
    
xcp.signals(30).symbol =  'Model_B.Sum_m';
    
xcp.signals(31).symbol =  'Model_B.sinC';
    
xcp.signals(32).symbol =  'Model_B.cosC';
    
xcp.signals(33).symbol =  'Model_B.encRef';
    
xcp.signals(34).symbol =  'Model_B.encCosUnc';
    
xcp.signals(35).symbol =  'Model_B.idealPos';
    
xcp.signals(36).symbol =  'Model_B.Gain2';
    
xcp.signals(37).symbol =  'Model_B.encCount';
    
xcp.signals(38).symbol =  'Model_B.Gain4';
    
xcp.signals(39).symbol =  'Model_B.encSinCor';
    
xcp.signals(40).symbol =  'Model_B.encInt';
    
xcp.signals(41).symbol =  'Model_B.Gain7';
    
xcp.signals(42).symbol =  'Model_B.encCosCor';
    
xcp.signals(43).symbol =  'Model_B.encSinUnc';
    
xcp.signals(44).symbol =  'Model_B.Divide';
    
xcp.signals(45).symbol =  'Model_B.Add';
    
xcp.signals(46).symbol =  'Model_B.Add1';
    
xcp.signals(47).symbol =  'Model_B.SumofElements';
    
xcp.signals(48).symbol =  'Model_B.SumofElements1';
    
xcp.signals(49).symbol =  'Model_B.Sum1';
    
xcp.signals(50).symbol =  'Model_B.atan2_l';
    
xcp.signals(51).symbol =  'Model_B.Delay';
    
xcp.signals(52).symbol =  'Model_B.Memory';
    
xcp.signals(53).symbol =  'Model_B.index_counter';
    
xcp.signals(54).symbol =  'Model_B.DirectLookupTablenD';
    
xcp.signals(55).symbol =  'Model_B.Gain1';
    
xcp.signals(56).symbol =  'Model_B.Gain2_j';
    
xcp.signals(57).symbol =  'Model_B.ClampTru';
    
xcp.signals(58).symbol =  'Model_B.ShearTru';
    
xcp.signals(59).symbol =  'Model_B.Gain7_j';
    
xcp.signals(60).symbol =  'Model_B.alpha_mod';
    
xcp.signals(61).symbol =  'Model_B.Saturation';
    
xcp.signals(62).symbol =  'Model_B.Sum_i';
    
xcp.signals(63).symbol =  'Model_B.Sum1_o';
    
xcp.signals(64).symbol =  'Model_B.HitCrossingNeg';
    
xcp.signals(65).symbol =  'Model_B.HitCrossingPos';
    
xcp.signals(66).symbol =  'Model_B.LogicalOperatorNeg';
    
xcp.signals(67).symbol =  'Model_B.LogicalOperatorPos';
    
xcp.signals(68).symbol =  'Model_B.Add2';
    
xcp.signals(69).symbol =  'Model_B.Derivative';
    
xcp.signals(70).symbol =  'Model_B.Gain1_f';
    
xcp.signals(71).symbol =  'Model_B.Gain2_m4';
    
xcp.signals(72).symbol =  'Model_B.alpha';
    
xcp.signals(73).symbol =  'Model_B.Integrator';
    
xcp.signals(74).symbol =  'Model_B.Sign';
    
xcp.signals(75).symbol =  'Model_B.Switch';
    
xcp.signals(76).symbol =  'Model_B.Gain';
    
xcp.signals(77).symbol =  'Model_B.Gain1_i';
    
xcp.signals(78).symbol =  'Model_B.Gain10';
    
xcp.signals(79).symbol =  'Model_B.Gain11';
    
xcp.signals(80).symbol =  'Model_B.Gain2_m';
    
xcp.signals(81).symbol =  'Model_B.Gain3';
    
xcp.signals(82).symbol =  'Model_B.Gain4_g';
    
xcp.signals(83).symbol =  'Model_B.Gain5';
    
xcp.signals(84).symbol =  'Model_B.Gain6';
    
xcp.signals(85).symbol =  'Model_B.Gain7_c';
    
xcp.signals(86).symbol =  'Model_B.Gain8';
    
xcp.signals(87).symbol =  'Model_B.utot005';
    
xcp.signals(88).symbol =  'Model_B.u05tot045clamp1';
    
xcp.signals(89).symbol =  'Model_B.u05tot045clamp2';
    
xcp.signals(90).symbol =  'Model_B.u05tot045shear1';
    
xcp.signals(91).symbol =  'Model_B.u05tot045shear2';
    
xcp.signals(92).symbol =  'Model_B.u55tot095clamp1';
    
xcp.signals(93).symbol =  'Model_B.u55tot095clamp2';
    
xcp.signals(94).symbol =  'Model_B.u55tot095shear1';
    
xcp.signals(95).symbol =  'Model_B.u55tot095shear2';
    
xcp.signals(96).symbol =  'Model_B.u95tot1';
    
xcp.signals(97).symbol =  'Model_B.C1';
    
xcp.signals(98).symbol =  'Model_B.C2';
    
xcp.signals(99).symbol =  'Model_B.S1';
    
xcp.signals(100).symbol =  'Model_B.S2';
    
xcp.signals(101).symbol =  'Model_B.test1';
    
xcp.signals(102).symbol =  'Model_B.Add_k';
    
xcp.signals(103).symbol =  'Model_B.Add1_h';
    
xcp.signals(104).symbol =  'Model_B.Add10';
    
xcp.signals(105).symbol =  'Model_B.Add11';
    
xcp.signals(106).symbol =  'Model_B.Add12';
    
xcp.signals(107).symbol =  'Model_B.Add13';
    
xcp.signals(108).symbol =  'Model_B.Add2_h';
    
xcp.signals(109).symbol =  'Model_B.Add3';
    
xcp.signals(110).symbol =  'Model_B.Add4';
    
xcp.signals(111).symbol =  'Model_B.Add6';
    
xcp.signals(112).symbol =  'Model_B.Add7';
    
xcp.signals(113).symbol =  'Model_B.Add8';
    
xcp.signals(114).symbol =  'Model_B.Add9';
    
xcp.signals(115).symbol =  'Model_B.Compare';
    
xcp.signals(116).symbol =  'Model_B.Sum_dz';
    
xcp.signals(117).symbol =  'Model_B.UnitDelay_p';
    
xcp.signals(118).symbol =  'Model_B.Sum_a';
    
xcp.signals(119).symbol =  'Model_B.UnitDelay';
         
xcp.parameters(1).symbol = 'Model_P.Gain_Gain';
xcp.parameters(1).size   =  1;       
xcp.parameters(1).dtname = 'real_T'; 
xcp.parameters(2).baseaddr = '&Model_P.Gain_Gain';     
         
xcp.parameters(2).symbol = 'Model_P.Gain1_Gain_d';
xcp.parameters(2).size   =  1;       
xcp.parameters(2).dtname = 'real_T'; 
xcp.parameters(3).baseaddr = '&Model_P.Gain1_Gain_d';     
         
xcp.parameters(3).symbol = 'Model_P.Gain2_Gain';
xcp.parameters(3).size   =  1;       
xcp.parameters(3).dtname = 'real_T'; 
xcp.parameters(4).baseaddr = '&Model_P.Gain2_Gain';     
         
xcp.parameters(4).symbol = 'Model_P.Gain3_Gain_a';
xcp.parameters(4).size   =  1;       
xcp.parameters(4).dtname = 'real_T'; 
xcp.parameters(5).baseaddr = '&Model_P.Gain3_Gain_a';     
         
xcp.parameters(5).symbol = 'Model_P.Gain4_Gain_p';
xcp.parameters(5).size   =  1;       
xcp.parameters(5).dtname = 'real_T'; 
xcp.parameters(6).baseaddr = '&Model_P.Gain4_Gain_p';     
         
xcp.parameters(6).symbol = 'Model_P.Gain5_Gain_k';
xcp.parameters(6).size   =  1;       
xcp.parameters(6).dtname = 'real_T'; 
xcp.parameters(7).baseaddr = '&Model_P.Gain5_Gain_k';     
         
xcp.parameters(7).symbol = 'Model_P.RepeatingSequence_rep_seq_y';
xcp.parameters(7).size   =  7;       
xcp.parameters(7).dtname = 'real_T'; 
xcp.parameters(8).baseaddr = '&Model_P.RepeatingSequence_rep_seq_y[0]';     
         
xcp.parameters(8).symbol = 'Model_P.RepeatingSequence1_rep_seq_y';
xcp.parameters(8).size   =  3;       
xcp.parameters(8).dtname = 'real_T'; 
xcp.parameters(9).baseaddr = '&Model_P.RepeatingSequence1_rep_seq_y[0]';     
         
xcp.parameters(9).symbol = 'Model_P.RepeatingSequence2_rep_seq_y';
xcp.parameters(9).size   =  3;       
xcp.parameters(9).dtname = 'real_T'; 
xcp.parameters(10).baseaddr = '&Model_P.RepeatingSequence2_rep_seq_y[0]';     
         
xcp.parameters(10).symbol = 'Model_P.Gain1_Gain';
xcp.parameters(10).size   =  1;       
xcp.parameters(10).dtname = 'real_T'; 
xcp.parameters(11).baseaddr = '&Model_P.Gain1_Gain';     
         
xcp.parameters(11).symbol = 'Model_P.IO397AnalogInput_P1';
xcp.parameters(11).size   =  1;       
xcp.parameters(11).dtname = 'real_T'; 
xcp.parameters(12).baseaddr = '&Model_P.IO397AnalogInput_P1';     
         
xcp.parameters(12).symbol = 'Model_P.IO397AnalogInput_P2';
xcp.parameters(12).size   =  1;       
xcp.parameters(12).dtname = 'real_T'; 
xcp.parameters(13).baseaddr = '&Model_P.IO397AnalogInput_P2';     
         
xcp.parameters(13).symbol = 'Model_P.IO397AnalogInput_P3';
xcp.parameters(13).size   =  4;       
xcp.parameters(13).dtname = 'real_T'; 
xcp.parameters(14).baseaddr = '&Model_P.IO397AnalogInput_P3[0]';     
         
xcp.parameters(14).symbol = 'Model_P.IO397AnalogInput_P4';
xcp.parameters(14).size   =  1;       
xcp.parameters(14).dtname = 'real_T'; 
xcp.parameters(15).baseaddr = '&Model_P.IO397AnalogInput_P4';     
         
xcp.parameters(15).symbol = 'Model_P.IO397AnalogInput_P5';
xcp.parameters(15).size   =  1;       
xcp.parameters(15).dtname = 'real_T'; 
xcp.parameters(16).baseaddr = '&Model_P.IO397AnalogInput_P5';     
         
xcp.parameters(16).symbol = 'Model_P.IO397AnalogInput_P6';
xcp.parameters(16).size   =  1;       
xcp.parameters(16).dtname = 'real_T'; 
xcp.parameters(17).baseaddr = '&Model_P.IO397AnalogInput_P6';     
         
xcp.parameters(17).symbol = 'Model_P.IO397AnalogInput_P7';
xcp.parameters(17).size   =  2;       
xcp.parameters(17).dtname = 'real_T'; 
xcp.parameters(18).baseaddr = '&Model_P.IO397AnalogInput_P7[0]';     
         
xcp.parameters(18).symbol = 'Model_P.IO397AnalogInput1_P1';
xcp.parameters(18).size   =  1;       
xcp.parameters(18).dtname = 'real_T'; 
xcp.parameters(19).baseaddr = '&Model_P.IO397AnalogInput1_P1';     
         
xcp.parameters(19).symbol = 'Model_P.IO397AnalogInput1_P2';
xcp.parameters(19).size   =  1;       
xcp.parameters(19).dtname = 'real_T'; 
xcp.parameters(20).baseaddr = '&Model_P.IO397AnalogInput1_P2';     
         
xcp.parameters(20).symbol = 'Model_P.IO397AnalogInput1_P3';
xcp.parameters(20).size   =  2;       
xcp.parameters(20).dtname = 'real_T'; 
xcp.parameters(21).baseaddr = '&Model_P.IO397AnalogInput1_P3[0]';     
         
xcp.parameters(21).symbol = 'Model_P.IO397AnalogInput1_P4';
xcp.parameters(21).size   =  1;       
xcp.parameters(21).dtname = 'real_T'; 
xcp.parameters(22).baseaddr = '&Model_P.IO397AnalogInput1_P4';     
         
xcp.parameters(22).symbol = 'Model_P.IO397AnalogInput1_P5';
xcp.parameters(22).size   =  1;       
xcp.parameters(22).dtname = 'real_T'; 
xcp.parameters(23).baseaddr = '&Model_P.IO397AnalogInput1_P5';     
         
xcp.parameters(23).symbol = 'Model_P.IO397AnalogInput1_P6';
xcp.parameters(23).size   =  1;       
xcp.parameters(23).dtname = 'real_T'; 
xcp.parameters(24).baseaddr = '&Model_P.IO397AnalogInput1_P6';     
         
xcp.parameters(24).symbol = 'Model_P.IO397AnalogInput1_P7';
xcp.parameters(24).size   =  2;       
xcp.parameters(24).dtname = 'real_T'; 
xcp.parameters(25).baseaddr = '&Model_P.IO397AnalogInput1_P7[0]';     
         
xcp.parameters(25).symbol = 'Model_P.IO397AnalogOutput1_P1';
xcp.parameters(25).size   =  1;       
xcp.parameters(25).dtname = 'real_T'; 
xcp.parameters(26).baseaddr = '&Model_P.IO397AnalogOutput1_P1';     
         
xcp.parameters(26).symbol = 'Model_P.IO397AnalogOutput1_P2';
xcp.parameters(26).size   =  1;       
xcp.parameters(26).dtname = 'real_T'; 
xcp.parameters(27).baseaddr = '&Model_P.IO397AnalogOutput1_P2';     
         
xcp.parameters(27).symbol = 'Model_P.IO397AnalogOutput1_P3';
xcp.parameters(27).size   =  4;       
xcp.parameters(27).dtname = 'real_T'; 
xcp.parameters(28).baseaddr = '&Model_P.IO397AnalogOutput1_P3[0]';     
         
xcp.parameters(28).symbol = 'Model_P.IO397AnalogOutput1_P4';
xcp.parameters(28).size   =  4;       
xcp.parameters(28).dtname = 'real_T'; 
xcp.parameters(29).baseaddr = '&Model_P.IO397AnalogOutput1_P4[0]';     
         
xcp.parameters(29).symbol = 'Model_P.IO397AnalogOutput1_P5';
xcp.parameters(29).size   =  4;       
xcp.parameters(29).dtname = 'real_T'; 
xcp.parameters(30).baseaddr = '&Model_P.IO397AnalogOutput1_P5[0]';     
         
xcp.parameters(30).symbol = 'Model_P.IO397AnalogOutput1_P6';
xcp.parameters(30).size   =  1;       
xcp.parameters(30).dtname = 'real_T'; 
xcp.parameters(31).baseaddr = '&Model_P.IO397AnalogOutput1_P6';     
         
xcp.parameters(31).symbol = 'Model_P.IO397AnalogOutput1_P7';
xcp.parameters(31).size   =  2;       
xcp.parameters(31).dtname = 'real_T'; 
xcp.parameters(32).baseaddr = '&Model_P.IO397AnalogOutput1_P7[0]';     
         
xcp.parameters(32).symbol = 'Model_P.IO397AnalogOutput1_P8';
xcp.parameters(32).size   =  1;       
xcp.parameters(32).dtname = 'real_T'; 
xcp.parameters(33).baseaddr = '&Model_P.IO397AnalogOutput1_P8';     
         
xcp.parameters(33).symbol = 'Model_P.Constant_Value';
xcp.parameters(33).size   =  1;       
xcp.parameters(33).dtname = 'real_T'; 
xcp.parameters(34).baseaddr = '&Model_P.Constant_Value';     
         
xcp.parameters(34).symbol = 'Model_P.LookUpTable1_bp01Data';
xcp.parameters(34).size   =  7;       
xcp.parameters(34).dtname = 'real_T'; 
xcp.parameters(35).baseaddr = '&Model_P.LookUpTable1_bp01Data[0]';     
         
xcp.parameters(35).symbol = 'Model_P.Constant_Value_o';
xcp.parameters(35).size   =  1;       
xcp.parameters(35).dtname = 'real_T'; 
xcp.parameters(36).baseaddr = '&Model_P.Constant_Value_o';     
         
xcp.parameters(36).symbol = 'Model_P.LookUpTable1_bp01Data_h';
xcp.parameters(36).size   =  3;       
xcp.parameters(36).dtname = 'real_T'; 
xcp.parameters(37).baseaddr = '&Model_P.LookUpTable1_bp01Data_h[0]';     
         
xcp.parameters(37).symbol = 'Model_P.Constant_Value_n';
xcp.parameters(37).size   =  1;       
xcp.parameters(37).dtname = 'real_T'; 
xcp.parameters(38).baseaddr = '&Model_P.Constant_Value_n';     
         
xcp.parameters(38).symbol = 'Model_P.LookUpTable1_bp01Data_b';
xcp.parameters(38).size   =  3;       
xcp.parameters(38).dtname = 'real_T'; 
xcp.parameters(39).baseaddr = '&Model_P.LookUpTable1_bp01Data_b[0]';     
         
xcp.parameters(39).symbol = 'Model_P.Gain1_Gain_n';
xcp.parameters(39).size   =  1;       
xcp.parameters(39).dtname = 'real_T'; 
xcp.parameters(40).baseaddr = '&Model_P.Gain1_Gain_n';     
         
xcp.parameters(40).symbol = 'Model_P.Gain10_Gain';
xcp.parameters(40).size   =  1;       
xcp.parameters(40).dtname = 'real_T'; 
xcp.parameters(41).baseaddr = '&Model_P.Gain10_Gain';     
         
xcp.parameters(41).symbol = 'Model_P.Gain11_Gain';
xcp.parameters(41).size   =  1;       
xcp.parameters(41).dtname = 'real_T'; 
xcp.parameters(42).baseaddr = '&Model_P.Gain11_Gain';     
         
xcp.parameters(42).symbol = 'Model_P.Gain3_Gain';
xcp.parameters(42).size   =  1;       
xcp.parameters(42).dtname = 'real_T'; 
xcp.parameters(43).baseaddr = '&Model_P.Gain3_Gain';     
         
xcp.parameters(43).symbol = 'Model_P.Gain4_Gain';
xcp.parameters(43).size   =  1;       
xcp.parameters(43).dtname = 'real_T'; 
xcp.parameters(44).baseaddr = '&Model_P.Gain4_Gain';     
         
xcp.parameters(44).symbol = 'Model_P.Gain5_Gain';
xcp.parameters(44).size   =  1;       
xcp.parameters(44).dtname = 'real_T'; 
xcp.parameters(45).baseaddr = '&Model_P.Gain5_Gain';     
         
xcp.parameters(45).symbol = 'Model_P.Gain6_Gain';
xcp.parameters(45).size   =  1;       
xcp.parameters(45).dtname = 'real_T'; 
xcp.parameters(46).baseaddr = '&Model_P.Gain6_Gain';     
         
xcp.parameters(46).symbol = 'Model_P.Gain7_Gain';
xcp.parameters(46).size   =  1;       
xcp.parameters(46).dtname = 'real_T'; 
xcp.parameters(47).baseaddr = '&Model_P.Gain7_Gain';     
         
xcp.parameters(47).symbol = 'Model_P.Gain8_Gain';
xcp.parameters(47).size   =  1;       
xcp.parameters(47).dtname = 'real_T'; 
xcp.parameters(48).baseaddr = '&Model_P.Gain8_Gain';     
         
xcp.parameters(48).symbol = 'Model_P.Gain9_Gain';
xcp.parameters(48).size   =  1;       
xcp.parameters(48).dtname = 'real_T'; 
xcp.parameters(49).baseaddr = '&Model_P.Gain9_Gain';     
         
xcp.parameters(49).symbol = 'Model_P.Delay_InitialCondition';
xcp.parameters(49).size   =  1;       
xcp.parameters(49).dtname = 'real_T'; 
xcp.parameters(50).baseaddr = '&Model_P.Delay_InitialCondition';     
         
xcp.parameters(50).symbol = 'Model_P.Constant_Value_i';
xcp.parameters(50).size   =  1;       
xcp.parameters(50).dtname = 'real_T'; 
xcp.parameters(51).baseaddr = '&Model_P.Constant_Value_i';     
         
xcp.parameters(51).symbol = 'Model_P.Memory_InitialCondition';
xcp.parameters(51).size   =  1;       
xcp.parameters(51).dtname = 'real_T'; 
xcp.parameters(52).baseaddr = '&Model_P.Memory_InitialCondition';     
         
xcp.parameters(52).symbol = 'Model_P.Constant2_Value';
xcp.parameters(52).size   =  1;       
xcp.parameters(52).dtname = 'real_T'; 
xcp.parameters(53).baseaddr = '&Model_P.Constant2_Value';     
         
xcp.parameters(53).symbol = 'Model_P.Gain3_Gain_o';
xcp.parameters(53).size   =  1;       
xcp.parameters(53).dtname = 'real_T'; 
xcp.parameters(54).baseaddr = '&Model_P.Gain3_Gain_o';     
         
xcp.parameters(54).symbol = 'Model_P.Gain4_Gain_c';
xcp.parameters(54).size   =  1;       
xcp.parameters(54).dtname = 'real_T'; 
xcp.parameters(55).baseaddr = '&Model_P.Gain4_Gain_c';     
         
xcp.parameters(55).symbol = 'Model_P.Saturation_UpperSat';
xcp.parameters(55).size   =  4;       
xcp.parameters(55).dtname = 'real_T'; 
xcp.parameters(56).baseaddr = '&Model_P.Saturation_UpperSat[0]';     
         
xcp.parameters(56).symbol = 'Model_P.Saturation_LowerSat';
xcp.parameters(56).size   =  4;       
xcp.parameters(56).dtname = 'real_T'; 
xcp.parameters(57).baseaddr = '&Model_P.Saturation_LowerSat[0]';     
         
xcp.parameters(57).symbol = 'Model_P.CompareToConstant_const';
xcp.parameters(57).size   =  1;       
xcp.parameters(57).dtname = 'real_T'; 
xcp.parameters(58).baseaddr = '&Model_P.CompareToConstant_const';     
         
xcp.parameters(58).symbol = 'Model_P.HitCrossingNeg_Offset';
xcp.parameters(58).size   =  1;       
xcp.parameters(58).dtname = 'real_T'; 
xcp.parameters(59).baseaddr = '&Model_P.HitCrossingNeg_Offset';     
         
xcp.parameters(59).symbol = 'Model_P.HitCrossingPos_Offset';
xcp.parameters(59).size   =  1;       
xcp.parameters(59).dtname = 'real_T'; 
xcp.parameters(60).baseaddr = '&Model_P.HitCrossingPos_Offset';     
         
xcp.parameters(60).symbol = 'Model_P.Gain3_Gain_k';
xcp.parameters(60).size   =  1;       
xcp.parameters(60).dtname = 'real_T'; 
xcp.parameters(61).baseaddr = '&Model_P.Gain3_Gain_k';     
         
xcp.parameters(61).symbol = 'Model_P.Integrator_IC';
xcp.parameters(61).size   =  1;       
xcp.parameters(61).dtname = 'real_T'; 
xcp.parameters(62).baseaddr = '&Model_P.Integrator_IC';     
         
xcp.parameters(62).symbol = 'Model_P.Switch_Threshold';
xcp.parameters(62).size   =  1;       
xcp.parameters(62).dtname = 'real_T'; 
xcp.parameters(63).baseaddr = '&Model_P.Switch_Threshold';     
         
xcp.parameters(63).symbol = 'Model_P.utot005_tableData';
xcp.parameters(63).size   =  3;       
xcp.parameters(63).dtname = 'real_T'; 
xcp.parameters(64).baseaddr = '&Model_P.utot005_tableData[0]';     
         
xcp.parameters(64).symbol = 'Model_P.utot005_bp01Data';
xcp.parameters(64).size   =  3;       
xcp.parameters(64).dtname = 'real_T'; 
xcp.parameters(65).baseaddr = '&Model_P.utot005_bp01Data[0]';     
         
xcp.parameters(65).symbol = 'Model_P.utot005_maxIndex';
xcp.parameters(65).size   =  1;       
xcp.parameters(65).dtname = 'uint32_T'; 
xcp.parameters(66).baseaddr = '&Model_P.utot005_maxIndex';     
         
xcp.parameters(66).symbol = 'Model_P.utot005_dimSizes';
xcp.parameters(66).size   =  1;       
xcp.parameters(66).dtname = 'uint32_T'; 
xcp.parameters(67).baseaddr = '&Model_P.utot005_dimSizes';     
         
xcp.parameters(67).symbol = 'Model_P.utot005_numYWorkElts';
xcp.parameters(67).size   =  2;       
xcp.parameters(67).dtname = 'uint32_T'; 
xcp.parameters(68).baseaddr = '&Model_P.utot005_numYWorkElts[0]';     
         
xcp.parameters(68).symbol = 'Model_P.u05tot045clamp1_tableData';
xcp.parameters(68).size   =  5;       
xcp.parameters(68).dtname = 'real_T'; 
xcp.parameters(69).baseaddr = '&Model_P.u05tot045clamp1_tableData[0]';     
         
xcp.parameters(69).symbol = 'Model_P.u05tot045clamp1_bp01Data';
xcp.parameters(69).size   =  5;       
xcp.parameters(69).dtname = 'real_T'; 
xcp.parameters(70).baseaddr = '&Model_P.u05tot045clamp1_bp01Data[0]';     
         
xcp.parameters(70).symbol = 'Model_P.u05tot045clamp1_maxIndex';
xcp.parameters(70).size   =  1;       
xcp.parameters(70).dtname = 'uint32_T'; 
xcp.parameters(71).baseaddr = '&Model_P.u05tot045clamp1_maxIndex';     
         
xcp.parameters(71).symbol = 'Model_P.u05tot045clamp1_dimSizes';
xcp.parameters(71).size   =  1;       
xcp.parameters(71).dtname = 'uint32_T'; 
xcp.parameters(72).baseaddr = '&Model_P.u05tot045clamp1_dimSizes';     
         
xcp.parameters(72).symbol = 'Model_P.u05tot045clamp1_numYWorkElts';
xcp.parameters(72).size   =  2;       
xcp.parameters(72).dtname = 'uint32_T'; 
xcp.parameters(73).baseaddr = '&Model_P.u05tot045clamp1_numYWorkElts[0]';     
         
xcp.parameters(73).symbol = 'Model_P.u05tot045clamp2_tableData';
xcp.parameters(73).size   =  5;       
xcp.parameters(73).dtname = 'real_T'; 
xcp.parameters(74).baseaddr = '&Model_P.u05tot045clamp2_tableData[0]';     
         
xcp.parameters(74).symbol = 'Model_P.u05tot045clamp2_bp01Data';
xcp.parameters(74).size   =  5;       
xcp.parameters(74).dtname = 'real_T'; 
xcp.parameters(75).baseaddr = '&Model_P.u05tot045clamp2_bp01Data[0]';     
         
xcp.parameters(75).symbol = 'Model_P.u05tot045clamp2_maxIndex';
xcp.parameters(75).size   =  1;       
xcp.parameters(75).dtname = 'uint32_T'; 
xcp.parameters(76).baseaddr = '&Model_P.u05tot045clamp2_maxIndex';     
         
xcp.parameters(76).symbol = 'Model_P.u05tot045clamp2_dimSizes';
xcp.parameters(76).size   =  1;       
xcp.parameters(76).dtname = 'uint32_T'; 
xcp.parameters(77).baseaddr = '&Model_P.u05tot045clamp2_dimSizes';     
         
xcp.parameters(77).symbol = 'Model_P.u05tot045clamp2_numYWorkElts';
xcp.parameters(77).size   =  2;       
xcp.parameters(77).dtname = 'uint32_T'; 
xcp.parameters(78).baseaddr = '&Model_P.u05tot045clamp2_numYWorkElts[0]';     
         
xcp.parameters(78).symbol = 'Model_P.u05tot045shear1_tableData';
xcp.parameters(78).size   =  5;       
xcp.parameters(78).dtname = 'real_T'; 
xcp.parameters(79).baseaddr = '&Model_P.u05tot045shear1_tableData[0]';     
         
xcp.parameters(79).symbol = 'Model_P.u05tot045shear1_bp01Data';
xcp.parameters(79).size   =  5;       
xcp.parameters(79).dtname = 'real_T'; 
xcp.parameters(80).baseaddr = '&Model_P.u05tot045shear1_bp01Data[0]';     
         
xcp.parameters(80).symbol = 'Model_P.u05tot045shear1_maxIndex';
xcp.parameters(80).size   =  1;       
xcp.parameters(80).dtname = 'uint32_T'; 
xcp.parameters(81).baseaddr = '&Model_P.u05tot045shear1_maxIndex';     
         
xcp.parameters(81).symbol = 'Model_P.u05tot045shear1_dimSizes';
xcp.parameters(81).size   =  1;       
xcp.parameters(81).dtname = 'uint32_T'; 
xcp.parameters(82).baseaddr = '&Model_P.u05tot045shear1_dimSizes';     
         
xcp.parameters(82).symbol = 'Model_P.u05tot045shear1_numYWorkElts';
xcp.parameters(82).size   =  2;       
xcp.parameters(82).dtname = 'uint32_T'; 
xcp.parameters(83).baseaddr = '&Model_P.u05tot045shear1_numYWorkElts[0]';     
         
xcp.parameters(83).symbol = 'Model_P.u05tot045shear2_tableData';
xcp.parameters(83).size   =  5;       
xcp.parameters(83).dtname = 'real_T'; 
xcp.parameters(84).baseaddr = '&Model_P.u05tot045shear2_tableData[0]';     
         
xcp.parameters(84).symbol = 'Model_P.u05tot045shear2_bp01Data';
xcp.parameters(84).size   =  5;       
xcp.parameters(84).dtname = 'real_T'; 
xcp.parameters(85).baseaddr = '&Model_P.u05tot045shear2_bp01Data[0]';     
         
xcp.parameters(85).symbol = 'Model_P.u05tot045shear2_maxIndex';
xcp.parameters(85).size   =  1;       
xcp.parameters(85).dtname = 'uint32_T'; 
xcp.parameters(86).baseaddr = '&Model_P.u05tot045shear2_maxIndex';     
         
xcp.parameters(86).symbol = 'Model_P.u05tot045shear2_dimSizes';
xcp.parameters(86).size   =  1;       
xcp.parameters(86).dtname = 'uint32_T'; 
xcp.parameters(87).baseaddr = '&Model_P.u05tot045shear2_dimSizes';     
         
xcp.parameters(87).symbol = 'Model_P.u05tot045shear2_numYWorkElts';
xcp.parameters(87).size   =  2;       
xcp.parameters(87).dtname = 'uint32_T'; 
xcp.parameters(88).baseaddr = '&Model_P.u05tot045shear2_numYWorkElts[0]';     
         
xcp.parameters(88).symbol = 'Model_P.u55tot095clamp1_tableData';
xcp.parameters(88).size   =  5;       
xcp.parameters(88).dtname = 'real_T'; 
xcp.parameters(89).baseaddr = '&Model_P.u55tot095clamp1_tableData[0]';     
         
xcp.parameters(89).symbol = 'Model_P.u55tot095clamp1_bp01Data';
xcp.parameters(89).size   =  5;       
xcp.parameters(89).dtname = 'real_T'; 
xcp.parameters(90).baseaddr = '&Model_P.u55tot095clamp1_bp01Data[0]';     
         
xcp.parameters(90).symbol = 'Model_P.u55tot095clamp1_maxIndex';
xcp.parameters(90).size   =  1;       
xcp.parameters(90).dtname = 'uint32_T'; 
xcp.parameters(91).baseaddr = '&Model_P.u55tot095clamp1_maxIndex';     
         
xcp.parameters(91).symbol = 'Model_P.u55tot095clamp1_dimSizes';
xcp.parameters(91).size   =  1;       
xcp.parameters(91).dtname = 'uint32_T'; 
xcp.parameters(92).baseaddr = '&Model_P.u55tot095clamp1_dimSizes';     
         
xcp.parameters(92).symbol = 'Model_P.u55tot095clamp1_numYWorkElts';
xcp.parameters(92).size   =  2;       
xcp.parameters(92).dtname = 'uint32_T'; 
xcp.parameters(93).baseaddr = '&Model_P.u55tot095clamp1_numYWorkElts[0]';     
         
xcp.parameters(93).symbol = 'Model_P.u55tot095clamp2_tableData';
xcp.parameters(93).size   =  5;       
xcp.parameters(93).dtname = 'real_T'; 
xcp.parameters(94).baseaddr = '&Model_P.u55tot095clamp2_tableData[0]';     
         
xcp.parameters(94).symbol = 'Model_P.u55tot095clamp2_bp01Data';
xcp.parameters(94).size   =  5;       
xcp.parameters(94).dtname = 'real_T'; 
xcp.parameters(95).baseaddr = '&Model_P.u55tot095clamp2_bp01Data[0]';     
         
xcp.parameters(95).symbol = 'Model_P.u55tot095clamp2_maxIndex';
xcp.parameters(95).size   =  1;       
xcp.parameters(95).dtname = 'uint32_T'; 
xcp.parameters(96).baseaddr = '&Model_P.u55tot095clamp2_maxIndex';     
         
xcp.parameters(96).symbol = 'Model_P.u55tot095clamp2_dimSizes';
xcp.parameters(96).size   =  1;       
xcp.parameters(96).dtname = 'uint32_T'; 
xcp.parameters(97).baseaddr = '&Model_P.u55tot095clamp2_dimSizes';     
         
xcp.parameters(97).symbol = 'Model_P.u55tot095clamp2_numYWorkElts';
xcp.parameters(97).size   =  2;       
xcp.parameters(97).dtname = 'uint32_T'; 
xcp.parameters(98).baseaddr = '&Model_P.u55tot095clamp2_numYWorkElts[0]';     
         
xcp.parameters(98).symbol = 'Model_P.u55tot095shear1_tableData';
xcp.parameters(98).size   =  5;       
xcp.parameters(98).dtname = 'real_T'; 
xcp.parameters(99).baseaddr = '&Model_P.u55tot095shear1_tableData[0]';     
         
xcp.parameters(99).symbol = 'Model_P.u55tot095shear1_bp01Data';
xcp.parameters(99).size   =  5;       
xcp.parameters(99).dtname = 'real_T'; 
xcp.parameters(100).baseaddr = '&Model_P.u55tot095shear1_bp01Data[0]';     
         
xcp.parameters(100).symbol = 'Model_P.u55tot095shear1_maxIndex';
xcp.parameters(100).size   =  1;       
xcp.parameters(100).dtname = 'uint32_T'; 
xcp.parameters(101).baseaddr = '&Model_P.u55tot095shear1_maxIndex';     
         
xcp.parameters(101).symbol = 'Model_P.u55tot095shear1_dimSizes';
xcp.parameters(101).size   =  1;       
xcp.parameters(101).dtname = 'uint32_T'; 
xcp.parameters(102).baseaddr = '&Model_P.u55tot095shear1_dimSizes';     
         
xcp.parameters(102).symbol = 'Model_P.u55tot095shear1_numYWorkElts';
xcp.parameters(102).size   =  2;       
xcp.parameters(102).dtname = 'uint32_T'; 
xcp.parameters(103).baseaddr = '&Model_P.u55tot095shear1_numYWorkElts[0]';     
         
xcp.parameters(103).symbol = 'Model_P.u55tot095shear2_tableData';
xcp.parameters(103).size   =  5;       
xcp.parameters(103).dtname = 'real_T'; 
xcp.parameters(104).baseaddr = '&Model_P.u55tot095shear2_tableData[0]';     
         
xcp.parameters(104).symbol = 'Model_P.u55tot095shear2_bp01Data';
xcp.parameters(104).size   =  5;       
xcp.parameters(104).dtname = 'real_T'; 
xcp.parameters(105).baseaddr = '&Model_P.u55tot095shear2_bp01Data[0]';     
         
xcp.parameters(105).symbol = 'Model_P.u55tot095shear2_maxIndex';
xcp.parameters(105).size   =  1;       
xcp.parameters(105).dtname = 'uint32_T'; 
xcp.parameters(106).baseaddr = '&Model_P.u55tot095shear2_maxIndex';     
         
xcp.parameters(106).symbol = 'Model_P.u55tot095shear2_dimSizes';
xcp.parameters(106).size   =  1;       
xcp.parameters(106).dtname = 'uint32_T'; 
xcp.parameters(107).baseaddr = '&Model_P.u55tot095shear2_dimSizes';     
         
xcp.parameters(107).symbol = 'Model_P.u55tot095shear2_numYWorkElts';
xcp.parameters(107).size   =  2;       
xcp.parameters(107).dtname = 'uint32_T'; 
xcp.parameters(108).baseaddr = '&Model_P.u55tot095shear2_numYWorkElts[0]';     
         
xcp.parameters(108).symbol = 'Model_P.u95tot1_tableData';
xcp.parameters(108).size   =  3;       
xcp.parameters(108).dtname = 'real_T'; 
xcp.parameters(109).baseaddr = '&Model_P.u95tot1_tableData[0]';     
         
xcp.parameters(109).symbol = 'Model_P.u95tot1_bp01Data';
xcp.parameters(109).size   =  3;       
xcp.parameters(109).dtname = 'real_T'; 
xcp.parameters(110).baseaddr = '&Model_P.u95tot1_bp01Data[0]';     
         
xcp.parameters(110).symbol = 'Model_P.u95tot1_maxIndex';
xcp.parameters(110).size   =  1;       
xcp.parameters(110).dtname = 'uint32_T'; 
xcp.parameters(111).baseaddr = '&Model_P.u95tot1_maxIndex';     
         
xcp.parameters(111).symbol = 'Model_P.u95tot1_dimSizes';
xcp.parameters(111).size   =  1;       
xcp.parameters(111).dtname = 'uint32_T'; 
xcp.parameters(112).baseaddr = '&Model_P.u95tot1_dimSizes';     
         
xcp.parameters(112).symbol = 'Model_P.u95tot1_numYWorkElts';
xcp.parameters(112).size   =  2;       
xcp.parameters(112).dtname = 'uint32_T'; 
xcp.parameters(113).baseaddr = '&Model_P.u95tot1_numYWorkElts[0]';     
         
xcp.parameters(113).symbol = 'Model_P.C1_tableData';
xcp.parameters(113).size   =  6;       
xcp.parameters(113).dtname = 'real_T'; 
xcp.parameters(114).baseaddr = '&Model_P.C1_tableData[0]';     
         
xcp.parameters(114).symbol = 'Model_P.C1_bp01Data';
xcp.parameters(114).size   =  6;       
xcp.parameters(114).dtname = 'real_T'; 
xcp.parameters(115).baseaddr = '&Model_P.C1_bp01Data[0]';     
         
xcp.parameters(115).symbol = 'Model_P.C2_tableData';
xcp.parameters(115).size   =  6;       
xcp.parameters(115).dtname = 'real_T'; 
xcp.parameters(116).baseaddr = '&Model_P.C2_tableData[0]';     
         
xcp.parameters(116).symbol = 'Model_P.C2_bp01Data';
xcp.parameters(116).size   =  6;       
xcp.parameters(116).dtname = 'real_T'; 
xcp.parameters(117).baseaddr = '&Model_P.C2_bp01Data[0]';     
         
xcp.parameters(117).symbol = 'Model_P.S1_tableData';
xcp.parameters(117).size   =  4;       
xcp.parameters(117).dtname = 'real_T'; 
xcp.parameters(118).baseaddr = '&Model_P.S1_tableData[0]';     
         
xcp.parameters(118).symbol = 'Model_P.S1_bp01Data';
xcp.parameters(118).size   =  4;       
xcp.parameters(118).dtname = 'real_T'; 
xcp.parameters(119).baseaddr = '&Model_P.S1_bp01Data[0]';     
         
xcp.parameters(119).symbol = 'Model_P.S2_tableData';
xcp.parameters(119).size   =  4;       
xcp.parameters(119).dtname = 'real_T'; 
xcp.parameters(120).baseaddr = '&Model_P.S2_tableData[0]';     
         
xcp.parameters(120).symbol = 'Model_P.S2_bp01Data';
xcp.parameters(120).size   =  4;       
xcp.parameters(120).dtname = 'real_T'; 
xcp.parameters(121).baseaddr = '&Model_P.S2_bp01Data[0]';     
         
xcp.parameters(121).symbol = 'Model_P.clamp2_tableData';
xcp.parameters(121).size   =  3;       
xcp.parameters(121).dtname = 'real_T'; 
xcp.parameters(122).baseaddr = '&Model_P.clamp2_tableData[0]';     
         
xcp.parameters(122).symbol = 'Model_P.clamp2_bp01Data';
xcp.parameters(122).size   =  3;       
xcp.parameters(122).dtname = 'real_T'; 
xcp.parameters(123).baseaddr = '&Model_P.clamp2_bp01Data[0]';     
         
xcp.parameters(123).symbol = 'Model_P.clamp2_maxIndex';
xcp.parameters(123).size   =  1;       
xcp.parameters(123).dtname = 'uint32_T'; 
xcp.parameters(124).baseaddr = '&Model_P.clamp2_maxIndex';     
         
xcp.parameters(124).symbol = 'Model_P.clamp2_dimSizes';
xcp.parameters(124).size   =  1;       
xcp.parameters(124).dtname = 'uint32_T'; 
xcp.parameters(125).baseaddr = '&Model_P.clamp2_dimSizes';     
         
xcp.parameters(125).symbol = 'Model_P.clamp2_numYWorkElts';
xcp.parameters(125).size   =  2;       
xcp.parameters(125).dtname = 'uint32_T'; 
xcp.parameters(126).baseaddr = '&Model_P.clamp2_numYWorkElts[0]';     
         
xcp.parameters(126).symbol = 'Model_P.Counts_Y0';
xcp.parameters(126).size   =  1;       
xcp.parameters(126).dtname = 'real_T'; 
xcp.parameters(127).baseaddr = '&Model_P.Counts_Y0';     
         
xcp.parameters(127).symbol = 'Model_P.Constant_neg_Value';
xcp.parameters(127).size   =  1;       
xcp.parameters(127).dtname = 'real_T'; 
xcp.parameters(128).baseaddr = '&Model_P.Constant_neg_Value';     
         
xcp.parameters(128).symbol = 'Model_P.UnitDelay_InitialCondition';
xcp.parameters(128).size   =  1;       
xcp.parameters(128).dtname = 'real_T'; 
xcp.parameters(129).baseaddr = '&Model_P.UnitDelay_InitialCondition';     
         
xcp.parameters(129).symbol = 'Model_P.Counts_Y0_h';
xcp.parameters(129).size   =  1;       
xcp.parameters(129).dtname = 'real_T'; 
xcp.parameters(130).baseaddr = '&Model_P.Counts_Y0_h';     
         
xcp.parameters(130).symbol = 'Model_P.Constant_pos_Value';
xcp.parameters(130).size   =  1;       
xcp.parameters(130).dtname = 'real_T'; 
xcp.parameters(131).baseaddr = '&Model_P.Constant_pos_Value';     
         
xcp.parameters(131).symbol = 'Model_P.UnitDelay_InitialCondition_n';
xcp.parameters(131).size   =  1;       
xcp.parameters(131).dtname = 'real_T'; 
xcp.parameters(132).baseaddr = '&Model_P.UnitDelay_InitialCondition_n';     
         
xcp.parameters(132).symbol = 'Model_P.Clamp1Amp';
xcp.parameters(132).size   =  1;       
xcp.parameters(132).dtname = 'real_T'; 
xcp.parameters(133).baseaddr = '&Model_P.Clamp1Amp';     
         
xcp.parameters(133).symbol = 'Model_P.Clamp2Amp';
xcp.parameters(133).size   =  1;       
xcp.parameters(133).dtname = 'real_T'; 
xcp.parameters(134).baseaddr = '&Model_P.Clamp2Amp';     
         
xcp.parameters(134).symbol = 'Model_P.ClampsSineAmp';
xcp.parameters(134).size   =  1;       
xcp.parameters(134).dtname = 'real_T'; 
xcp.parameters(135).baseaddr = '&Model_P.ClampsSineAmp';     
         
xcp.parameters(135).symbol = 'Model_P.ShearAmp';
xcp.parameters(135).size   =  1;       
xcp.parameters(135).dtname = 'real_T'; 
xcp.parameters(136).baseaddr = '&Model_P.ShearAmp';     
         
xcp.parameters(136).symbol = 'Model_P.backwardGain';
xcp.parameters(136).size   =  1;       
xcp.parameters(136).dtname = 'real_T'; 
xcp.parameters(137).baseaddr = '&Model_P.backwardGain';     
         
xcp.parameters(137).symbol = 'Model_P.clampofset';
xcp.parameters(137).size   =  1;       
xcp.parameters(137).dtname = 'real_T'; 
xcp.parameters(138).baseaddr = '&Model_P.clampofset';     
         
xcp.parameters(138).symbol = 'Model_P.forwardGain';
xcp.parameters(138).size   =  1;       
xcp.parameters(138).dtname = 'real_T'; 
xcp.parameters(139).baseaddr = '&Model_P.forwardGain';     
         
xcp.parameters(139).symbol = 'Model_P.ofsetshear2';
xcp.parameters(139).size   =  1;       
xcp.parameters(139).dtname = 'real_T'; 
xcp.parameters(140).baseaddr = '&Model_P.ofsetshear2';     
         
xcp.parameters(140).symbol = 'Model_P.pAmpGain';
xcp.parameters(140).size   =  4;       
xcp.parameters(140).dtname = 'real_T'; 
xcp.parameters(141).baseaddr = '&Model_P.pAmpGain[0]';     
         
xcp.parameters(141).symbol = 'Model_P.pAngleCorrection';
xcp.parameters(141).size   =  1;       
xcp.parameters(141).dtname = 'real_T'; 
xcp.parameters(142).baseaddr = '&Model_P.pAngleCorrection';     
         
xcp.parameters(142).symbol = 'Model_P.pClampAmpl';
xcp.parameters(142).size   =  1;       
xcp.parameters(142).dtname = 'real_T'; 
xcp.parameters(143).baseaddr = '&Model_P.pClampAmpl';     
         
xcp.parameters(143).symbol = 'Model_P.pClampOffs';
xcp.parameters(143).size   =  1;       
xcp.parameters(143).dtname = 'real_T'; 
xcp.parameters(144).baseaddr = '&Model_P.pClampOffs';     
         
xcp.parameters(144).symbol = 'Model_P.pCosineGain';
xcp.parameters(144).size   =  1;       
xcp.parameters(144).dtname = 'real_T'; 
xcp.parameters(145).baseaddr = '&Model_P.pCosineGain';     
         
xcp.parameters(145).symbol = 'Model_P.pCosineOffset';
xcp.parameters(145).size   =  1;       
xcp.parameters(145).dtname = 'real_T'; 
xcp.parameters(146).baseaddr = '&Model_P.pCosineOffset';     
         
xcp.parameters(146).symbol = 'Model_P.pEncRes';
xcp.parameters(146).size   =  1;       
xcp.parameters(146).dtname = 'real_T'; 
xcp.parameters(147).baseaddr = '&Model_P.pEncRes';     
         
xcp.parameters(147).symbol = 'Model_P.pShearAmpl';
xcp.parameters(147).size   =  1;       
xcp.parameters(147).dtname = 'real_T'; 
xcp.parameters(148).baseaddr = '&Model_P.pShearAmpl';     
         
xcp.parameters(148).symbol = 'Model_P.pShearOffs';
xcp.parameters(148).size   =  1;       
xcp.parameters(148).dtname = 'real_T'; 
xcp.parameters(149).baseaddr = '&Model_P.pShearOffs';     
         
xcp.parameters(149).symbol = 'Model_P.pSineGain';
xcp.parameters(149).size   =  1;       
xcp.parameters(149).dtname = 'real_T'; 
xcp.parameters(150).baseaddr = '&Model_P.pSineGain';     
         
xcp.parameters(150).symbol = 'Model_P.pSineOffset';
xcp.parameters(150).size   =  1;       
xcp.parameters(150).dtname = 'real_T'; 
xcp.parameters(151).baseaddr = '&Model_P.pSineOffset';     
         
xcp.parameters(151).symbol = 'Model_P.tSample';
xcp.parameters(151).size   =  1;       
xcp.parameters(151).dtname = 'real_T'; 
xcp.parameters(152).baseaddr = '&Model_P.tSample';     
         
xcp.parameters(152).symbol = 'Model_P.u_ff';
xcp.parameters(152).size   =  51000;       
xcp.parameters(152).dtname = 'real_T'; 
xcp.parameters(153).baseaddr = '&Model_P.u_ff[0]';     

function n = getNumParameters
n = 152;

function n = getNumSignals
n = 119;

function n = getNumEvents
n = 1;

function n = getNumModels
n = 1;

