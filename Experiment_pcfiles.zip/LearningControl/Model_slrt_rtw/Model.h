/*
 * Model.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Model".
 *
 * Model version              : 1.779
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Jun 23 10:49:18 2023
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Model_h_
#define RTW_HEADER_Model_h_
#include <stddef.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include "rtw_modelmap.h"
#ifndef Model_COMMON_INCLUDES_
# define Model_COMMON_INCLUDES_
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "sg_fpga_io30x_setup_util.h"
#include "sg_fpga_io31x_io32x_setup_util.h"
#include "sg_fpga_io33x_setup_util.h"
#include "sg_fpga_io39x_setup_util.h"
#include "sg_common.h"
#include "sg_printf.h"
#endif                                 /* Model_COMMON_INCLUDES_ */

#include "Model_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rtsplntypes.h"
#include "rt_zcfcn.h"
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetCtrlRateMdlRefTiming
# define rtmGetCtrlRateMdlRefTiming(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTiming
# define rtmSetCtrlRateMdlRefTiming(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateMdlRefTimingPtr
# define rtmGetCtrlRateMdlRefTimingPtr(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTimingPtr
# define rtmSetCtrlRateMdlRefTimingPtr(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateNumTicksToNextHit
# define rtmGetCtrlRateNumTicksToNextHit(rtm) ()
#endif

#ifndef rtmSetCtrlRateNumTicksToNextHit
# define rtmSetCtrlRateNumTicksToNextHit(rtm, val) ()
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ((rtm)->NonInlinedSFcns)
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ((rtm)->NonInlinedSFcns = (val))
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumPeriodicContStates
# define rtmGetNumPeriodicContStates(rtm) ((rtm)->Sizes.numPeriodicContStates)
#endif

#ifndef rtmSetNumPeriodicContStates
# define rtmSetNumPeriodicContStates(rtm, val) ((rtm)->Sizes.numPeriodicContStates = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ()
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ()
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ()
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ()
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSelf
# define rtmGetSelf(rtm)               ()
#endif

#ifndef rtmSetSelf
# define rtmSetSelf(rtm, val)          ()
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ()
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ()
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGettimingBridge
# define rtmGettimingBridge(rtm)       ()
#endif

#ifndef rtmSettimingBridge
# define rtmSettimingBridge(rtm, val)  ()
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) == 0)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) ((rtmIsMajorTimeStep((rtm)) && (rtm)->Timing.sampleHits[(rtm)->Timing.sampleTimeTaskIDPtr[sti]]))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)
#define rtModel_Model                  RT_MODEL_Model_T

/* Definition for use in the target main file */
#define Model_rtModel                  RT_MODEL_Model_T

/* Block signals (default storage) */
typedef struct {
  real_T Clock;                        /* '<S8>/Clock' */
  real_T Sum;                          /* '<S8>/Sum' */
  real_T MathFunction;                 /* '<S8>/Math Function' */
  real_T LookUpTable1;                 /* '<S8>/Look-Up Table1' */
  real_T Output;                       /* '<S8>/Output' */
  real_T reference;                    /* '<S1>/Gain1' */
  real_T IO397AnalogInput_o1;          /* '<S7>/IO397 Analog Input' */
  real_T IO397AnalogInput_o2;          /* '<S7>/IO397 Analog Input' */
  real_T IO397AnalogInput_o3;          /* '<S7>/IO397 Analog Input' */
  real_T IO397AnalogInput_o4;          /* '<S7>/IO397 Analog Input' */
  real_T SumofElements;                /* '<S11>/Sum of Elements' */
  real_T encSinUnc;                    /* '<S11>/Gain9' */
  real_T SumofElements1;               /* '<S11>/Sum of Elements1' */
  real_T encCosUnc;                    /* '<S11>/Gain10' */
  real_T encSinCor;                    /* '<S11>/Gain5' */
  real_T encCosCor;                    /* '<S11>/Gain8' */
  real_T Add2;                         /* '<S18>/Add2' */
  real_T encCount;                     /* '<S11>/Gain3' */
  real_T Gain4;                        /* '<S11>/Gain4' */
  real_T atan2_l;                      /* '<S11>/atan2' */
  real_T encInt;                       /* '<S11>/Gain6' */
  real_T Sum1;                         /* '<S11>/Sum1' */
  real_T Gain7;                        /* '<S11>/Gain7' */
  real_T Gain2;                        /* '<S11>/Gain2' */
  real_T error;                        /* '<S1>/Add1' */
  real_T Delay;                        /* '<S11>/Delay' */
  real_T Add;                          /* '<S11>/Add' */
  real_T idealPos;                     /* '<S11>/Gain11' */
  real_T Add1;                         /* '<S11>/Add1' */
  real_T Divide;                       /* '<S11>/Divide' */
  real_T IO397AnalogInput1_o1;         /* '<S7>/IO397 Analog Input1' */
  real_T IO397AnalogInput1_o2;         /* '<S7>/IO397 Analog Input1' */
  real_T encRef[2];                    /* '<S11>/Gain1' */
  real_T Memory;                       /* '<S12>/Memory' */
  real_T index_counter;                /* '<S12>/Sum' */
  real_T DirectLookupTablenD;          /* '<S12>/Direct Lookup Table (n-D)' */
  real_T Sum_g;                        /* '<S1>/Sum' */
  real_T Integrator;                   /* '<S22>/Integrator' */
  real_T alpha;                        /* '<S22>/Gain3' */
  real_T alpha_mod;                    /* '<S13>/Math Function' */
  real_T Gain1[2];                     /* '<S13>/Gain1' */
  real_T Gain2_j[2];                   /* '<S13>/Gain2' */
  real_T Sum1_o[2];                    /* '<S13>/Sum1' */
  real_T ClampTru[2];                  /* '<S13>/Gain3' */
  real_T Sum_i[2];                     /* '<S13>/Sum' */
  real_T ShearTru[2];                  /* '<S13>/Gain4' */
  real_T Saturation[4];                /* '<S13>/Saturation' */
  real_T Gain7_j[4];                   /* '<S13>/Gain7' */
  real_T Derivative;                   /* '<S22>/Derivative' */
  real_T Sign;                         /* '<S22>/Sign' */
  real_T Switch;                       /* '<S22>/Switch' */
  real_T Clock_h;                      /* '<S9>/Clock' */
  real_T Sum_d;                        /* '<S9>/Sum' */
  real_T MathFunction_e;               /* '<S9>/Math Function' */
  real_T LookUpTable1_d;               /* '<S9>/Look-Up Table1' */
  real_T Output_a;                     /* '<S9>/Output' */
  real_T Clock_f;                      /* '<S10>/Clock' */
  real_T Sum_m;                        /* '<S10>/Sum' */
  real_T MathFunction_a;               /* '<S10>/Math Function' */
  real_T LookUpTable1_b;               /* '<S10>/Look-Up Table1' */
  real_T Output_d;                     /* '<S10>/Output' */
  real_T Error;                        /* '<Root>/Gain' */
  real_T Velocity;                     /* '<Root>/Gain1' */
  real_T Position;                     /* '<Root>/Gain2' */
  real_T CommAngle;                    /* '<Root>/Gain3' */
  real_T ClampAnl[2];                  /* '<Root>/Gain4' */
  real_T ShearAnl[2];                  /* '<Root>/Gain5' */
  real_T C2;                           /* '<S25>/C2' */
  real_T test1;                        /* '<S25>/clamp2' */
  real_T Gain;                         /* '<S25>/Gain' */
  real_T Add_k;                        /* '<S25>/Add' */
  real_T S1;                           /* '<S25>/S1' */
  real_T u55tot095shear1;              /* '<S25>/0.55 tot 0.95 shear1' */
  real_T Gain8;                        /* '<S25>/Gain8' */
  real_T u05tot045shear1;              /* '<S25>/0.05 tot 0.45 shear1' */
  real_T Gain2_m;                      /* '<S25>/Gain2' */
  real_T Add8;                         /* '<S25>/Add8' */
  real_T Add7;                         /* '<S25>/Add7' */
  real_T S2;                           /* '<S25>/S2' */
  real_T u55tot095shear2;              /* '<S25>/0.55 tot 0.95 shear2' */
  real_T Gain4_g;                      /* '<S25>/Gain4' */
  real_T u05tot045shear2;              /* '<S25>/0.05 tot 0.45 shear2' */
  real_T Gain5;                        /* '<S25>/Gain5' */
  real_T Add9;                         /* '<S25>/Add9' */
  real_T Add6;                         /* '<S25>/Add6' */
  real_T u55tot095clamp1;              /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T Gain11;                       /* '<S25>/Gain11' */
  real_T u05tot045clamp1;              /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T Gain10;                       /* '<S25>/Gain10' */
  real_T Add11;                        /* '<S25>/Add11' */
  real_T C1;                           /* '<S25>/C1' */
  real_T utot005;                      /* '<S25>/0 tot 0.05' */
  real_T Gain1_i;                      /* '<S25>/Gain1' */
  real_T u95tot1;                      /* '<S25>/0.95 tot 1' */
  real_T Gain3;                        /* '<S25>/Gain3' */
  real_T Add3;                         /* '<S25>/Add3' */
  real_T Add2_h;                       /* '<S25>/Add2' */
  real_T Add4;                         /* '<S25>/Add4' */
  real_T u55tot095clamp2;              /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T Gain6;                        /* '<S25>/Gain6' */
  real_T u05tot045clamp2;              /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T Gain7_c;                      /* '<S25>/Gain7' */
  real_T Add13;                        /* '<S25>/Add13' */
  real_T Add1_h;                       /* '<S25>/Add1' */
  real_T Add10;                        /* '<S25>/Add10' */
  real_T Add12;                        /* '<S25>/Add12' */
  real_T Gain2_m4;                     /* '<S22>/Gain2' */
  real_T Gain1_f;                      /* '<S22>/Gain1' */
  real_T UnitDelay;                    /* '<S21>/Unit Delay' */
  real_T Sum_a;                        /* '<S21>/Sum' */
  real_T UnitDelay_p;                  /* '<S20>/Unit Delay' */
  real_T Sum_dz;                       /* '<S20>/Sum' */
  real_T sinC;                         /* '<S11>/MATLAB Function' */
  real_T cosC;                         /* '<S11>/MATLAB Function' */
  boolean_T HitCrossingNeg;            /* '<S18>/Hit  Crossing Neg' */
  boolean_T Compare;                   /* '<S19>/Compare' */
  boolean_T LogicalOperatorNeg;        /* '<S18>/Logical Operator Neg' */
  boolean_T HitCrossingPos;            /* '<S18>/Hit  Crossing Pos' */
  boolean_T LogicalOperatorPos;        /* '<S18>/Logical Operator Pos' */
} B_Model_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T Delay_DSTATE;                 /* '<S11>/Delay' */
  real_T UnitDelay_DSTATE;             /* '<S21>/Unit Delay' */
  real_T UnitDelay_DSTATE_o;           /* '<S20>/Unit Delay' */
  real_T Memory_PreviousInput;         /* '<S12>/Memory' */
  real_T TimeStampA;                   /* '<S22>/Derivative' */
  real_T LastUAtTimeA;                 /* '<S22>/Derivative' */
  real_T TimeStampB;                   /* '<S22>/Derivative' */
  real_T LastUAtTimeB;                 /* '<S22>/Derivative' */
  real_T m_bpLambda;                   /* '<S25>/clamp2' */
  real_T m_yyA;                        /* '<S25>/clamp2' */
  real_T m_yyB;                        /* '<S25>/clamp2' */
  real_T m_yy2;                        /* '<S25>/clamp2' */
  real_T m_up[3];                      /* '<S25>/clamp2' */
  real_T m_y2[3];                      /* '<S25>/clamp2' */
  real_T prevBp0AndTableData[6];       /* '<S25>/clamp2' */
  real_T m_bpLambda_m;                 /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_yyA_i;                      /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_yyB_f;                      /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_yy2_h;                      /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_up_g[5];                    /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_y2_d[5];                    /* '<S25>/0.55 tot 0.95 shear1' */
  real_T prevBp0AndTableData_n[10];    /* '<S25>/0.55 tot 0.95 shear1' */
  real_T m_bpLambda_k;                 /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_yyA_j;                      /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_yyB_c;                      /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_yy2_e;                      /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_up_a[5];                    /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_y2_i[5];                    /* '<S25>/0.05 tot 0.45 shear1' */
  real_T prevBp0AndTableData_j[10];    /* '<S25>/0.05 tot 0.45 shear1' */
  real_T m_bpLambda_c;                 /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_yyA_g;                      /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_yyB_a;                      /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_yy2_i;                      /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_up_e[5];                    /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_y2_n[5];                    /* '<S25>/0.55 tot 0.95 shear2' */
  real_T prevBp0AndTableData_m[10];    /* '<S25>/0.55 tot 0.95 shear2' */
  real_T m_bpLambda_j;                 /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_yyA_o;                      /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_yyB_h;                      /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_yy2_k;                      /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_up_p[5];                    /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_y2_l[5];                    /* '<S25>/0.05 tot 0.45 shear2' */
  real_T prevBp0AndTableData_h[10];    /* '<S25>/0.05 tot 0.45 shear2' */
  real_T m_bpLambda_ja;                /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_yyA_e;                      /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_yyB_p;                      /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_yy2_p;                      /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_up_pq[5];                   /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_y2_b[5];                    /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T prevBp0AndTableData_c[10];    /* '<S25>/0.55 tot 0.95 clamp1' */
  real_T m_bpLambda_g;                 /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_yyA_c;                      /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_yyB_c1;                     /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_yy2_d;                      /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_up_l[5];                    /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_y2_n1[5];                   /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T prevBp0AndTableData_o[10];    /* '<S25>/0.05 tot 0.45 clamp1' */
  real_T m_bpLambda_j3;                /* '<S25>/0 tot 0.05' */
  real_T m_yyA_cd;                     /* '<S25>/0 tot 0.05' */
  real_T m_yyB_d;                      /* '<S25>/0 tot 0.05' */
  real_T m_yy2_b;                      /* '<S25>/0 tot 0.05' */
  real_T m_up_k[3];                    /* '<S25>/0 tot 0.05' */
  real_T m_y2_k[3];                    /* '<S25>/0 tot 0.05' */
  real_T prevBp0AndTableData_g[6];     /* '<S25>/0 tot 0.05' */
  real_T m_bpLambda_kc;                /* '<S25>/0.95 tot 1' */
  real_T m_yyA_a;                      /* '<S25>/0.95 tot 1' */
  real_T m_yyB_g;                      /* '<S25>/0.95 tot 1' */
  real_T m_yy2_pk;                     /* '<S25>/0.95 tot 1' */
  real_T m_up_af[3];                   /* '<S25>/0.95 tot 1' */
  real_T m_y2_a[3];                    /* '<S25>/0.95 tot 1' */
  real_T prevBp0AndTableData_oj[6];    /* '<S25>/0.95 tot 1' */
  real_T m_bpLambda_my;                /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_yyA_n;                      /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_yyB_gl;                     /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_yy2_e0;                     /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_up_m[5];                    /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_y2_m[5];                    /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T prevBp0AndTableData_f[10];    /* '<S25>/0.55 tot 0.95 clamp2' */
  real_T m_bpLambda_ks;                /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T m_yyA_am;                     /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T m_yyB_e;                      /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T m_yy2_dw;                     /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T m_up_f[5];                    /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T m_y2_aj[5];                   /* '<S25>/0.05 tot 0.45 clamp2' */
  real_T prevBp0AndTableData_p[10];    /* '<S25>/0.05 tot 0.45 clamp2' */
  void *IO397AnalogInput_PWORK[2];     /* '<S7>/IO397 Analog Input' */
  void *IO397AnalogInput1_PWORK[2];    /* '<S7>/IO397 Analog Input1' */
  void *IO397AnalogOutput1_PWORK[2];   /* '<S7>/IO397 Analog Output1' */
  struct {
    void *USERIO_P_IND;
    void *PROG_SPACE_P_IND;
    void *CONFIG_REGISTER_P_IND;
    void *CONDITIONING_MODULE_IO3xx_2x_P_IND;
    void *DEVICENAME_P_IND;
  } Module1_PWORK;                     /* '<S2>/Module 1' */

  struct {
    void *USERIO_P_IND;
    void *PROG_SPACE_P_IND;
    void *CONFIG_REGISTER_P_IND;
    void *CONDITIONING_MODULE_IO3xx_2x_P_IND;
    void *DEVICENAME_P_IND;
  } Module2_PWORK;                     /* '<S2>/Module 2' */

  void* m_bpDataSet;                   /* '<S25>/clamp2' */
  void* TWork[6];                      /* '<S25>/clamp2' */
  void* SWork[9];                      /* '<S25>/clamp2' */
  struct {
    void *LoggedData[2];
  } Scope_PWORK;                       /* '<S25>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<S25>/Scope1' */

  void* m_bpDataSet_m;                 /* '<S25>/0.55 tot 0.95 shear1' */
  void* TWork_n[6];                    /* '<S25>/0.55 tot 0.95 shear1' */
  void* SWork_d[9];                    /* '<S25>/0.55 tot 0.95 shear1' */
  void* m_bpDataSet_i;                 /* '<S25>/0.05 tot 0.45 shear1' */
  void* TWork_l[6];                    /* '<S25>/0.05 tot 0.45 shear1' */
  void* SWork_o[9];                    /* '<S25>/0.05 tot 0.45 shear1' */
  struct {
    void *LoggedData[2];
  } Scope10_PWORK;                     /* '<S25>/Scope10' */

  struct {
    void *LoggedData;
  } Scope11_PWORK;                     /* '<S25>/Scope11' */

  void* m_bpDataSet_b;                 /* '<S25>/0.55 tot 0.95 shear2' */
  void* TWork_p[6];                    /* '<S25>/0.55 tot 0.95 shear2' */
  void* SWork_f[9];                    /* '<S25>/0.55 tot 0.95 shear2' */
  void* m_bpDataSet_d;                 /* '<S25>/0.05 tot 0.45 shear2' */
  void* TWork_lm[6];                   /* '<S25>/0.05 tot 0.45 shear2' */
  void* SWork_g[9];                    /* '<S25>/0.05 tot 0.45 shear2' */
  void* m_bpDataSet_j;                 /* '<S25>/0.55 tot 0.95 clamp1' */
  void* TWork_o[6];                    /* '<S25>/0.55 tot 0.95 clamp1' */
  void* SWork_b[9];                    /* '<S25>/0.55 tot 0.95 clamp1' */
  void* m_bpDataSet_c;                 /* '<S25>/0.05 tot 0.45 clamp1' */
  void* TWork_lj[6];                   /* '<S25>/0.05 tot 0.45 clamp1' */
  void* SWork_h[9];                    /* '<S25>/0.05 tot 0.45 clamp1' */
  void* m_bpDataSet_p;                 /* '<S25>/0 tot 0.05' */
  void* TWork_d[6];                    /* '<S25>/0 tot 0.05' */
  void* SWork_n[9];                    /* '<S25>/0 tot 0.05' */
  void* m_bpDataSet_n;                 /* '<S25>/0.95 tot 1' */
  void* TWork_l1[6];                   /* '<S25>/0.95 tot 1' */
  void* SWork_e[9];                    /* '<S25>/0.95 tot 1' */
  void* m_bpDataSet_a;                 /* '<S25>/0.55 tot 0.95 clamp2' */
  void* TWork_c[6];                    /* '<S25>/0.55 tot 0.95 clamp2' */
  void* SWork_ee[9];                   /* '<S25>/0.55 tot 0.95 clamp2' */
  void* m_bpDataSet_k;                 /* '<S25>/0.05 tot 0.45 clamp2' */
  void* TWork_i[6];                    /* '<S25>/0.05 tot 0.45 clamp2' */
  void* SWork_bg[9];                   /* '<S25>/0.05 tot 0.45 clamp2' */
  struct {
    void *LoggedData;
  } Scope12_PWORK;                     /* '<S25>/Scope12' */

  struct {
    void *LoggedData[2];
  } Scope13_PWORK;                     /* '<S25>/Scope13' */

  struct {
    void *LoggedData;
  } Scope14_PWORK;                     /* '<S25>/Scope14' */

  struct {
    void *LoggedData[2];
  } Scope15_PWORK;                     /* '<S25>/Scope15' */

  struct {
    void *LoggedData;
  } Scope16_PWORK;                     /* '<S25>/Scope16' */

  struct {
    void *LoggedData[2];
  } Scope4_PWORK;                      /* '<S25>/Scope4' */

  struct {
    void *LoggedData;
  } Scope5_PWORK;                      /* '<S25>/Scope5' */

  struct {
    void *LoggedData[2];
  } Scope8_PWORK;                      /* '<S25>/Scope8' */

  struct {
    void *LoggedData;
  } Scope9_PWORK;                      /* '<S25>/Scope9' */

  uint32_T m_bpIndex;                  /* '<S25>/clamp2' */
  uint32_T m_bpIndex_l;                /* '<S25>/0.55 tot 0.95 shear1' */
  uint32_T m_bpIndex_b;                /* '<S25>/0.05 tot 0.45 shear1' */
  uint32_T m_bpIndex_p;                /* '<S25>/0.55 tot 0.95 shear2' */
  uint32_T m_bpIndex_p2;               /* '<S25>/0.05 tot 0.45 shear2' */
  uint32_T m_bpIndex_bj;               /* '<S25>/0.55 tot 0.95 clamp1' */
  uint32_T m_bpIndex_n;                /* '<S25>/0.05 tot 0.45 clamp1' */
  uint32_T m_bpIndex_h;                /* '<S25>/0 tot 0.05' */
  uint32_T m_bpIndex_c;                /* '<S25>/0.95 tot 1' */
  uint32_T m_bpIndex_d;                /* '<S25>/0.55 tot 0.95 clamp2' */
  uint32_T m_bpIndex_lh;               /* '<S25>/0.05 tot 0.45 clamp2' */
  struct {
    int_T AcquireOK;
  } SFunction_IWORK;                   /* '<S3>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_k;                 /* '<S4>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_a;                 /* '<S5>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_n;                 /* '<S6>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_no;                /* '<S15>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_ax;                /* '<S16>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_g;                 /* '<S17>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_p;                 /* '<S23>/S-Function' */

  struct {
    int_T AcquireOK;
  } SFunction_IWORK_m;                 /* '<S24>/S-Function' */

  int_T IO397AnalogOutput1_IWORK;      /* '<S7>/IO397 Analog Output1' */
  struct {
    int_T MODULEARCHITECTURE_I_IND;
  } Module1_IWORK;                     /* '<S2>/Module 1' */

  struct {
    int_T MODULEARCHITECTURE_I_IND;
  } Module2_IWORK;                     /* '<S2>/Module 2' */

  int_T HitCrossingNeg_MODE;           /* '<S18>/Hit  Crossing Neg' */
  int_T HitCrossingPos_MODE;           /* '<S18>/Hit  Crossing Pos' */
  int8_T PosCounter_SubsysRanBC;       /* '<S18>/PosCounter' */
  int8_T NegCounter_SubsysRanBC;       /* '<S18>/NegCounter' */
  uint8_T reCalcSecDerivFirstDimCoeffs;/* '<S25>/clamp2' */
  uint8_T reCalcSecDerivFirstDimCoeffs_e;/* '<S25>/0.55 tot 0.95 shear1' */
  uint8_T reCalcSecDerivFirstDimCoeffs_eq;/* '<S25>/0.05 tot 0.45 shear1' */
  uint8_T reCalcSecDerivFirstDimCoeffs_c;/* '<S25>/0.55 tot 0.95 shear2' */
  uint8_T reCalcSecDerivFirstDimCoeffs_eo;/* '<S25>/0.05 tot 0.45 shear2' */
  uint8_T reCalcSecDerivFirstDimCoeffs_n;/* '<S25>/0.55 tot 0.95 clamp1' */
  uint8_T reCalcSecDerivFirstDimCoeffs_i;/* '<S25>/0.05 tot 0.45 clamp1' */
  uint8_T reCalcSecDerivFirstDimCoeffs_np;/* '<S25>/0 tot 0.05' */
  uint8_T reCalcSecDerivFirstDimCoeffs_k;/* '<S25>/0.95 tot 1' */
  uint8_T reCalcSecDerivFirstDimCoeffs_a;/* '<S25>/0.55 tot 0.95 clamp2' */
  uint8_T reCalcSecDerivFirstDimCoeffs_o;/* '<S25>/0.05 tot 0.45 clamp2' */
} DW_Model_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S22>/Integrator' */
} X_Model_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S22>/Integrator' */
} XDot_Model_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S22>/Integrator' */
} XDis_Model_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState HitCrossingNeg_Input_ZCE; /* '<S18>/Hit  Crossing Neg' */
  ZCSigState HitCrossingPos_Input_ZCE; /* '<S18>/Hit  Crossing Pos' */
  ZCSigState PosCounter_Trig_ZCE;      /* '<S18>/PosCounter' */
  ZCSigState NegCounter_Trig_ZCE;      /* '<S18>/NegCounter' */
} PrevZCX_Model_T;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* Backward compatible GRT Identifiers */
#define rtB                            Model_B
#define BlockIO                        B_Model_T
#define rtX                            Model_X
#define ContinuousStates               X_Model_T
#define rtXdot                         Model_XDot
#define StateDerivatives               XDot_Model_T
#define tXdis                          Model_XDis
#define StateDisabled                  XDis_Model_T
#define rtP                            Model_P
#define Parameters                     P_Model_T
#define rtDWork                        Model_DW
#define D_Work                         DW_Model_T
#define rtPrevZCSigState               Model_PrevZCX
#define PrevZCSigStates                PrevZCX_Model_T

/* Parameters (default storage) */
struct P_Model_T_ {
  real_T Clamp1Amp;                    /* Variable: Clamp1Amp
                                        * Referenced by:
                                        *   '<S25>/Gain1'
                                        *   '<S25>/Gain3'
                                        */
  real_T Clamp2Amp;                    /* Variable: Clamp2Amp
                                        * Referenced by: '<S25>/Gain'
                                        */
  real_T ClampsSineAmp;                /* Variable: ClampsSineAmp
                                        * Referenced by:
                                        *   '<S25>/Gain10'
                                        *   '<S25>/Gain11'
                                        *   '<S25>/Gain6'
                                        *   '<S25>/Gain7'
                                        */
  real_T ShearAmp;                     /* Variable: ShearAmp
                                        * Referenced by:
                                        *   '<S25>/Gain2'
                                        *   '<S25>/Gain4'
                                        *   '<S25>/Gain5'
                                        *   '<S25>/Gain8'
                                        */
  real_T backwardGain;                 /* Variable: backwardGain
                                        * Referenced by: '<S22>/Gain1'
                                        */
  real_T clampofset;                   /* Variable: clampofset
                                        * Referenced by:
                                        *   '<S25>/Gain11'
                                        *   '<S25>/Gain6'
                                        */
  real_T forwardGain;                  /* Variable: forwardGain
                                        * Referenced by: '<S22>/Gain2'
                                        */
  real_T ofsetshear2;                  /* Variable: ofsetshear2
                                        * Referenced by:
                                        *   '<S25>/Gain4'
                                        *   '<S25>/Gain8'
                                        */
  real_T pAmpGain[4];                  /* Variable: pAmpGain
                                        * Referenced by: '<S13>/Gain7'
                                        */
  real_T pAngleCorrection;             /* Variable: pAngleCorrection
                                        * Referenced by: '<S11>/Constant2'
                                        */
  real_T pClampAmpl;                   /* Variable: pClampAmpl
                                        * Referenced by: '<S13>/Gain1'
                                        */
  real_T pClampOffs;                   /* Variable: pClampOffs
                                        * Referenced by: '<S13>/Constant1'
                                        */
  real_T pCosineGain;                  /* Variable: pCosineGain
                                        * Referenced by: '<S11>/Constant3'
                                        */
  real_T pCosineOffset;                /* Variable: pCosineOffset
                                        * Referenced by: '<S11>/Constant4'
                                        */
  real_T pEncRes;                      /* Variable: pEncRes
                                        * Referenced by: '<S11>/Gain2'
                                        */
  real_T pShearAmpl;                   /* Variable: pShearAmpl
                                        * Referenced by: '<S13>/Gain2'
                                        */
  real_T pShearOffs;                   /* Variable: pShearOffs
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T pSineGain;                    /* Variable: pSineGain
                                        * Referenced by: '<S11>/Constant5'
                                        */
  real_T pSineOffset;                  /* Variable: pSineOffset
                                        * Referenced by: '<S11>/Constant6'
                                        */
  real_T tSample;                      /* Variable: tSample
                                        * Referenced by: '<S11>/Constant1'
                                        */
  real_T u_ff[51000];                  /* Variable: u_ff
                                        * Referenced by: '<S12>/u_ff'
                                        */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S19>/Constant'
                                       */
  real_T RepeatingSequence_rep_seq_y[7];
                                  /* Mask Parameter: RepeatingSequence_rep_seq_y
                                   * Referenced by: '<S8>/Look-Up Table1'
                                   */
  real_T RepeatingSequence1_rep_seq_y[3];
                                 /* Mask Parameter: RepeatingSequence1_rep_seq_y
                                  * Referenced by: '<S9>/Look-Up Table1'
                                  */
  real_T RepeatingSequence2_rep_seq_y[3];
                                 /* Mask Parameter: RepeatingSequence2_rep_seq_y
                                  * Referenced by: '<S10>/Look-Up Table1'
                                  */
  real_T Counts_Y0;                    /* Computed Parameter: Counts_Y0
                                        * Referenced by: '<S20>/Counts'
                                        */
  real_T Constant_neg_Value;           /* Expression: 1
                                        * Referenced by: '<S20>/Constant_neg'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S20>/Unit Delay'
                                        */
  real_T Counts_Y0_h;                  /* Computed Parameter: Counts_Y0_h
                                        * Referenced by: '<S21>/Counts'
                                        */
  real_T Constant_pos_Value;           /* Expression: 1
                                        * Referenced by: '<S21>/Constant_pos'
                                        */
  real_T UnitDelay_InitialCondition_n; /* Expression: 0
                                        * Referenced by: '<S21>/Unit Delay'
                                        */
  real_T C2_tableData[6];              /* Expression: [-1, -1, 1, 1, -1, -1]
                                        * Referenced by: '<S25>/C2'
                                        */
  real_T C2_bp01Data[6];
          /* Expression: [0, 0.05*2*pi, 0.45*2*pi, 0.55*2*pi, 0.95*2*pi, 1*2*pi]
           * Referenced by: '<S25>/C2'
           */
  real_T clamp2_tableData[3];          /* Expression: [0, -1, 0]
                                        * Referenced by: '<S25>/clamp2'
                                        */
  real_T clamp2_bp01Data[3];
              /* Expression: [(0.5-(0.2/2))*2*pi, 0.5*2*pi,  (0.5+(0.2/2))*2*pi]
               * Referenced by: '<S25>/clamp2'
               */
  real_T S1_tableData[4];              /* Expression: [0, 1, -1, 0]
                                        * Referenced by: '<S25>/S1'
                                        */
  real_T S1_bp01Data[4];        /* Expression: [0, 0.45*2*pi, 0.55*2*pi, 1*2*pi]
                                 * Referenced by: '<S25>/S1'
                                 */
  real_T u55tot095shear1_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.55 tot 0.95 shear1'
                                        */
  real_T u55tot095shear1_bp01Data[5];
  /* Expression: [(0.75-0.4/2)*2*pi, (0.75-0.4/4)*2*pi,  0.75*2*pi,   (0.75+0.4/4)*2*pi,  (0.75+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.55 tot 0.95 shear1'
   */
  real_T u05tot045shear1_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.05 tot 0.45 shear1'
                                        */
  real_T u05tot045shear1_bp01Data[5];
  /* Expression: [(0.25-0.4/2)*2*pi, (0.25-0.4/4)*2*pi,  0.25*2*pi,   (0.25+0.4/4)*2*pi,  (0.25+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.05 tot 0.45 shear1'
   */
  real_T S2_tableData[4];              /* Expression: [0, -1, 1, 0]
                                        * Referenced by: '<S25>/S2'
                                        */
  real_T S2_bp01Data[4];        /* Expression: [0, 0.05*2*pi, 0.95*2*pi, 1*2*pi]
                                 * Referenced by: '<S25>/S2'
                                 */
  real_T u55tot095shear2_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.55 tot 0.95 shear2'
                                        */
  real_T u55tot095shear2_bp01Data[5];
  /* Expression: [(0.75-0.4/2)*2*pi, (0.75-0.4/4)*2*pi,  0.75*2*pi,   (0.75+0.4/4)*2*pi,  (0.75+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.55 tot 0.95 shear2'
   */
  real_T u05tot045shear2_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.05 tot 0.45 shear2'
                                        */
  real_T u05tot045shear2_bp01Data[5];
  /* Expression: [(0.25-0.4/2)*2*pi, (0.25-0.4/4)*2*pi,  0.25*2*pi,   (0.25+0.4/4)*2*pi,  (0.25+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.05 tot 0.45 shear2'
   */
  real_T u55tot095clamp1_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.55 tot 0.95 clamp1'
                                        */
  real_T u55tot095clamp1_bp01Data[5];
  /* Expression: [(0.75-0.4/2)*2*pi, (0.75-0.4/4)*2*pi,  0.75*2*pi,   (0.75+0.4/4)*2*pi,  (0.75+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.55 tot 0.95 clamp1'
   */
  real_T u05tot045clamp1_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.05 tot 0.45 clamp1'
                                        */
  real_T u05tot045clamp1_bp01Data[5];
  /* Expression: [(0.25-0.4/2)*2*pi, (0.25-0.4/4)*2*pi,  0.25*2*pi,   (0.25+0.4/4)*2*pi,  (0.25+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.05 tot 0.45 clamp1'
   */
  real_T C1_tableData[6];              /* Expression: [1, 1, -1, -1, 1, 1]
                                        * Referenced by: '<S25>/C1'
                                        */
  real_T C1_bp01Data[6];
          /* Expression: [0, 0.05*2*pi, 0.45*2*pi, 0.55*2*pi, 0.95*2*pi, 1*2*pi]
           * Referenced by: '<S25>/C1'
           */
  real_T utot005_tableData[3];         /* Expression: [0, -1, 0]
                                        * Referenced by: '<S25>/0 tot 0.05'
                                        */
  real_T utot005_bp01Data[3];
           /* Expression: [(0.5-(0.1/2))*2*pi, 0.5*2*pi,  (0.5+(0.1/2))*2*pi]-pi
            * Referenced by: '<S25>/0 tot 0.05'
            */
  real_T u95tot1_tableData[3];         /* Expression: [0, -1, 0]
                                        * Referenced by: '<S25>/0.95 tot 1'
                                        */
  real_T u95tot1_bp01Data[3];
           /* Expression: [(0.5-(0.1/2))*2*pi, 0.5*2*pi,  (0.5+(0.1/2))*2*pi]+pi
            * Referenced by: '<S25>/0.95 tot 1'
            */
  real_T u55tot095clamp2_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.55 tot 0.95 clamp2'
                                        */
  real_T u55tot095clamp2_bp01Data[5];
  /* Expression: [(0.75-0.4/2)*2*pi, (0.75-0.4/4)*2*pi,  0.75*2*pi,   (0.75+0.4/4)*2*pi,  (0.75+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.55 tot 0.95 clamp2'
   */
  real_T u05tot045clamp2_tableData[5]; /* Expression: [0, 1, 0, -1, 0]
                                        * Referenced by: '<S25>/0.05 tot 0.45 clamp2'
                                        */
  real_T u05tot045clamp2_bp01Data[5];
  /* Expression: [(0.25-0.4/2)*2*pi, (0.25-0.4/4)*2*pi,  0.25*2*pi,   (0.25+0.4/4)*2*pi,  (0.25+0.4/2)*2*pi]
   * Referenced by: '<S25>/0.05 tot 0.45 clamp2'
   */
  real_T Constant_Value;               /* Expression: period
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T LookUpTable1_bp01Data[7];     /* Expression: rep_seq_t - min(rep_seq_t)
                                        * Referenced by: '<S8>/Look-Up Table1'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1
                                        * Referenced by: '<S1>/Gain1'
                                        */
  real_T IO397AnalogInput_P1_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P1_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P1;          /* Expression: boardType
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P2_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P2_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P2;          /* Expression: id
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P3_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P3_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P3[4];       /* Expression: chan
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P4_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P4_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P4;          /* Expression: trigger
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P5_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P5_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P5;          /* Expression: range
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P6_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P6_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P6;          /* Expression: ts
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T IO397AnalogInput_P7_Size[2];
                                 /* Computed Parameter: IO397AnalogInput_P7_Size
                                  * Referenced by: '<S7>/IO397 Analog Input'
                                  */
  real_T IO397AnalogInput_P7[2];       /* Expression: pciSlot
                                        * Referenced by: '<S7>/IO397 Analog Input'
                                        */
  real_T Gain9_Gain;                   /* Expression: 1
                                        * Referenced by: '<S11>/Gain9'
                                        */
  real_T Gain10_Gain;                  /* Expression: 1
                                        * Referenced by: '<S11>/Gain10'
                                        */
  real_T Gain5_Gain;                   /* Expression: 1
                                        * Referenced by: '<S11>/Gain5'
                                        */
  real_T HitCrossingNeg_Offset;        /* Expression: 0
                                        * Referenced by: '<S18>/Hit  Crossing Neg'
                                        */
  real_T Gain8_Gain;                   /* Expression: 1
                                        * Referenced by: '<S11>/Gain8'
                                        */
  real_T HitCrossingPos_Offset;        /* Expression: 0
                                        * Referenced by: '<S18>/Hit  Crossing Pos'
                                        */
  real_T Gain3_Gain;                   /* Expression: 1
                                        * Referenced by: '<S11>/Gain3'
                                        */
  real_T Gain4_Gain;                   /* Expression: 2*pi
                                        * Referenced by: '<S11>/Gain4'
                                        */
  real_T Gain6_Gain;                   /* Expression: 1
                                        * Referenced by: '<S11>/Gain6'
                                        */
  real_T Gain7_Gain;                   /* Expression: 1/(2*pi)
                                        * Referenced by: '<S11>/Gain7'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0
                                        * Referenced by: '<S11>/Delay'
                                        */
  real_T Gain11_Gain;                  /* Expression: 1
                                        * Referenced by: '<S11>/Gain11'
                                        */
  real_T IO397AnalogInput1_P1_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P1_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P1;         /* Expression: boardType
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P2_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P2_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P2;         /* Expression: id
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P3_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P3_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P3[2];      /* Expression: chan
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P4_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P4_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P4;         /* Expression: trigger
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P5_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P5_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P5;         /* Expression: range
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P6_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P6_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P6;         /* Expression: ts
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T IO397AnalogInput1_P7_Size[2];
                                /* Computed Parameter: IO397AnalogInput1_P7_Size
                                 * Referenced by: '<S7>/IO397 Analog Input1'
                                 */
  real_T IO397AnalogInput1_P7[2];      /* Expression: pciSlot
                                        * Referenced by: '<S7>/IO397 Analog Input1'
                                        */
  real_T Gain1_Gain_n;                 /* Expression: 1
                                        * Referenced by: '<S11>/Gain1'
                                        */
  real_T Constant_Value_i;             /* Expression: 1
                                        * Referenced by: '<S12>/Constant'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S12>/Memory'
                                        */
  real_T Constant2_Value;              /* Expression: 2*pi
                                        * Referenced by: '<S13>/Constant2'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S22>/Integrator'
                                        */
  real_T Gain3_Gain_k;                 /* Expression: 2*pi
                                        * Referenced by: '<S22>/Gain3'
                                        */
  real_T Gain3_Gain_o;                 /* Expression: 1
                                        * Referenced by: '<S13>/Gain3'
                                        */
  real_T Gain4_Gain_c;                 /* Expression: 1
                                        * Referenced by: '<S13>/Gain4'
                                        */
  real_T Saturation_UpperSat[4];
            /* Expression: [pShearSatMax pShearSatMax pClampSatMax pClampSatMax]
             * Referenced by: '<S13>/Saturation'
             */
  real_T Saturation_LowerSat[4];
            /* Expression: [pShearSatMin pShearSatMin pClampSatMin pClampSatMin]
             * Referenced by: '<S13>/Saturation'
             */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S22>/Switch'
                                        */
  real_T Constant_Value_o;             /* Expression: period
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T LookUpTable1_bp01Data_h[3];   /* Expression: rep_seq_t - min(rep_seq_t)
                                        * Referenced by: '<S9>/Look-Up Table1'
                                        */
  real_T Constant_Value_n;             /* Expression: period
                                        * Referenced by: '<S10>/Constant'
                                        */
  real_T LookUpTable1_bp01Data_b[3];   /* Expression: rep_seq_t - min(rep_seq_t)
                                        * Referenced by: '<S10>/Look-Up Table1'
                                        */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Gain1_Gain_d;                 /* Expression: 1
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: 1
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T Gain3_Gain_a;                 /* Expression: 1
                                        * Referenced by: '<Root>/Gain3'
                                        */
  real_T Gain4_Gain_p;                 /* Expression: 1
                                        * Referenced by: '<Root>/Gain4'
                                        */
  real_T Gain5_Gain_k;                 /* Expression: 1
                                        * Referenced by: '<Root>/Gain5'
                                        */
  real_T IO397AnalogOutput1_P1_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P1_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P1;        /* Expression: boardType
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P2_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P2_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P2;        /* Expression: id
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P3_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P3_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P3[4];     /* Expression: chan
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P4_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P4_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P4[4];     /* Expression: initVal
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P5_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P5_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P5[4];     /* Expression: resetVal
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P6_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P6_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P6;        /* Expression: ts
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P7_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P7_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P7[2];     /* Expression: pciSlot
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  real_T IO397AnalogOutput1_P8_Size[2];
                               /* Computed Parameter: IO397AnalogOutput1_P8_Size
                                * Referenced by: '<S7>/IO397 Analog Output1'
                                */
  real_T IO397AnalogOutput1_P8;        /* Expression: span
                                        * Referenced by: '<S7>/IO397 Analog Output1'
                                        */
  uint32_T clamp2_maxIndex;            /* Computed Parameter: clamp2_maxIndex
                                        * Referenced by: '<S25>/clamp2'
                                        */
  uint32_T clamp2_dimSizes;            /* Computed Parameter: clamp2_dimSizes
                                        * Referenced by: '<S25>/clamp2'
                                        */
  uint32_T clamp2_numYWorkElts[2];    /* Computed Parameter: clamp2_numYWorkElts
                                       * Referenced by: '<S25>/clamp2'
                                       */
  uint32_T u55tot095shear1_maxIndex;
                                 /* Computed Parameter: u55tot095shear1_maxIndex
                                  * Referenced by: '<S25>/0.55 tot 0.95 shear1'
                                  */
  uint32_T u55tot095shear1_dimSizes;
                                 /* Computed Parameter: u55tot095shear1_dimSizes
                                  * Referenced by: '<S25>/0.55 tot 0.95 shear1'
                                  */
  uint32_T u55tot095shear1_numYWorkElts[2];
                             /* Computed Parameter: u55tot095shear1_numYWorkElts
                              * Referenced by: '<S25>/0.55 tot 0.95 shear1'
                              */
  uint32_T u05tot045shear1_maxIndex;
                                 /* Computed Parameter: u05tot045shear1_maxIndex
                                  * Referenced by: '<S25>/0.05 tot 0.45 shear1'
                                  */
  uint32_T u05tot045shear1_dimSizes;
                                 /* Computed Parameter: u05tot045shear1_dimSizes
                                  * Referenced by: '<S25>/0.05 tot 0.45 shear1'
                                  */
  uint32_T u05tot045shear1_numYWorkElts[2];
                             /* Computed Parameter: u05tot045shear1_numYWorkElts
                              * Referenced by: '<S25>/0.05 tot 0.45 shear1'
                              */
  uint32_T u55tot095shear2_maxIndex;
                                 /* Computed Parameter: u55tot095shear2_maxIndex
                                  * Referenced by: '<S25>/0.55 tot 0.95 shear2'
                                  */
  uint32_T u55tot095shear2_dimSizes;
                                 /* Computed Parameter: u55tot095shear2_dimSizes
                                  * Referenced by: '<S25>/0.55 tot 0.95 shear2'
                                  */
  uint32_T u55tot095shear2_numYWorkElts[2];
                             /* Computed Parameter: u55tot095shear2_numYWorkElts
                              * Referenced by: '<S25>/0.55 tot 0.95 shear2'
                              */
  uint32_T u05tot045shear2_maxIndex;
                                 /* Computed Parameter: u05tot045shear2_maxIndex
                                  * Referenced by: '<S25>/0.05 tot 0.45 shear2'
                                  */
  uint32_T u05tot045shear2_dimSizes;
                                 /* Computed Parameter: u05tot045shear2_dimSizes
                                  * Referenced by: '<S25>/0.05 tot 0.45 shear2'
                                  */
  uint32_T u05tot045shear2_numYWorkElts[2];
                             /* Computed Parameter: u05tot045shear2_numYWorkElts
                              * Referenced by: '<S25>/0.05 tot 0.45 shear2'
                              */
  uint32_T u55tot095clamp1_maxIndex;
                                 /* Computed Parameter: u55tot095clamp1_maxIndex
                                  * Referenced by: '<S25>/0.55 tot 0.95 clamp1'
                                  */
  uint32_T u55tot095clamp1_dimSizes;
                                 /* Computed Parameter: u55tot095clamp1_dimSizes
                                  * Referenced by: '<S25>/0.55 tot 0.95 clamp1'
                                  */
  uint32_T u55tot095clamp1_numYWorkElts[2];
                             /* Computed Parameter: u55tot095clamp1_numYWorkElts
                              * Referenced by: '<S25>/0.55 tot 0.95 clamp1'
                              */
  uint32_T u05tot045clamp1_maxIndex;
                                 /* Computed Parameter: u05tot045clamp1_maxIndex
                                  * Referenced by: '<S25>/0.05 tot 0.45 clamp1'
                                  */
  uint32_T u05tot045clamp1_dimSizes;
                                 /* Computed Parameter: u05tot045clamp1_dimSizes
                                  * Referenced by: '<S25>/0.05 tot 0.45 clamp1'
                                  */
  uint32_T u05tot045clamp1_numYWorkElts[2];
                             /* Computed Parameter: u05tot045clamp1_numYWorkElts
                              * Referenced by: '<S25>/0.05 tot 0.45 clamp1'
                              */
  uint32_T utot005_maxIndex;           /* Computed Parameter: utot005_maxIndex
                                        * Referenced by: '<S25>/0 tot 0.05'
                                        */
  uint32_T utot005_dimSizes;           /* Computed Parameter: utot005_dimSizes
                                        * Referenced by: '<S25>/0 tot 0.05'
                                        */
  uint32_T utot005_numYWorkElts[2];  /* Computed Parameter: utot005_numYWorkElts
                                      * Referenced by: '<S25>/0 tot 0.05'
                                      */
  uint32_T u95tot1_maxIndex;           /* Computed Parameter: u95tot1_maxIndex
                                        * Referenced by: '<S25>/0.95 tot 1'
                                        */
  uint32_T u95tot1_dimSizes;           /* Computed Parameter: u95tot1_dimSizes
                                        * Referenced by: '<S25>/0.95 tot 1'
                                        */
  uint32_T u95tot1_numYWorkElts[2];  /* Computed Parameter: u95tot1_numYWorkElts
                                      * Referenced by: '<S25>/0.95 tot 1'
                                      */
  uint32_T u55tot095clamp2_maxIndex;
                                 /* Computed Parameter: u55tot095clamp2_maxIndex
                                  * Referenced by: '<S25>/0.55 tot 0.95 clamp2'
                                  */
  uint32_T u55tot095clamp2_dimSizes;
                                 /* Computed Parameter: u55tot095clamp2_dimSizes
                                  * Referenced by: '<S25>/0.55 tot 0.95 clamp2'
                                  */
  uint32_T u55tot095clamp2_numYWorkElts[2];
                             /* Computed Parameter: u55tot095clamp2_numYWorkElts
                              * Referenced by: '<S25>/0.55 tot 0.95 clamp2'
                              */
  uint32_T u05tot045clamp2_maxIndex;
                                 /* Computed Parameter: u05tot045clamp2_maxIndex
                                  * Referenced by: '<S25>/0.05 tot 0.45 clamp2'
                                  */
  uint32_T u05tot045clamp2_dimSizes;
                                 /* Computed Parameter: u05tot045clamp2_dimSizes
                                  * Referenced by: '<S25>/0.05 tot 0.45 clamp2'
                                  */
  uint32_T u05tot045clamp2_numYWorkElts[2];
                             /* Computed Parameter: u05tot045clamp2_numYWorkElts
                              * Referenced by: '<S25>/0.05 tot 0.45 clamp2'
                              */
};

/* Real-time Model Data Structure */
struct tag_RTM_Model_T {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[2];
    SimStruct childSFunctions[3];
    SimStruct *childSFunctionPtrs[3];
    struct _ssBlkInfo2 blkInfo2[3];
    struct _ssSFcnModelMethods2 methods2[3];
    struct _ssSFcnModelMethods3 methods3[3];
    struct _ssSFcnModelMethods4 methods4[3];
    struct _ssStatesInfo2 statesInfo2[3];
    ssPeriodicStatesInfo periodicStatesInfo[3];
    struct _ssPortInfo2 inputOutputPortInfo2[3];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[4];
      struct _ssOutPortUnit outputPortUnits[4];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[4];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[4];
      struct _ssInPortUnit inputPortUnits[4];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[4];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn2;
  } NonInlinedSFcns;

  void *blockIO;
  const void *constBlockIO;
  void *defaultParam;
  ZCSigState *prevZCSigState;
  real_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  void *zcSignalValues;
  void *inputs;
  void *outputs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][1];
  ODE1_IntgData intgData;
  void *dwork;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[2];
    time_T offsetTimesArray[2];
    int_T sampleTimeTaskIDArray[2];
    int_T sampleHitArray[2];
    int_T perTaskSampleHitsArray[4];
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_Model_T Model_P;

/* Block signals (default storage) */
extern B_Model_T Model_B;

/* Continuous states (default storage) */
extern X_Model_T Model_X;

/* Block states (default storage) */
extern DW_Model_T Model_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_Model_T Model_PrevZCX;

/* Model entry point functions */
extern void Model_initialize(void);
extern void Model_output(void);
extern void Model_update(void);
extern void Model_terminate(void);

/*====================*
 * External functions *
 *====================*/
extern Model_rtModel *Model(void);
extern void MdlInitializeSizes(void);
extern void MdlInitializeSampleTimes(void);
extern void MdlInitialize(void);
extern void MdlStart(void);
extern void MdlOutputs(int_T tid);
extern void MdlUpdate(int_T tid);
extern void MdlTerminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  Model_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_Model_T *const Model_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Model'
 * '<S1>'   : 'Model/Control'
 * '<S2>'   : 'Model/Hardware Setup'
 * '<S3>'   : 'Model/Scope 2'
 * '<S4>'   : 'Model/Scope 3'
 * '<S5>'   : 'Model/Scope 5'
 * '<S6>'   : 'Model/Scope 6'
 * '<S7>'   : 'Model/Signals'
 * '<S8>'   : 'Model/Control/Repeating Sequence'
 * '<S9>'   : 'Model/Control/Repeating Sequence1'
 * '<S10>'  : 'Model/Control/Repeating Sequence2'
 * '<S11>'  : 'Model/Control/SinCos Decoder'
 * '<S12>'  : 'Model/Control/Subsystem'
 * '<S13>'  : 'Model/Control/Waveform Generator'
 * '<S14>'  : 'Model/Control/SinCos Decoder/MATLAB Function'
 * '<S15>'  : 'Model/Control/SinCos Decoder/Scope 5'
 * '<S16>'  : 'Model/Control/SinCos Decoder/Scope 6'
 * '<S17>'  : 'Model/Control/SinCos Decoder/Scope 7'
 * '<S18>'  : 'Model/Control/SinCos Decoder/Zero Detect Counter1'
 * '<S19>'  : 'Model/Control/SinCos Decoder/Zero Detect Counter1/Compare To Constant'
 * '<S20>'  : 'Model/Control/SinCos Decoder/Zero Detect Counter1/NegCounter'
 * '<S21>'  : 'Model/Control/SinCos Decoder/Zero Detect Counter1/PosCounter'
 * '<S22>'  : 'Model/Control/Waveform Generator/Scaling'
 * '<S23>'  : 'Model/Control/Waveform Generator/Scope 1'
 * '<S24>'  : 'Model/Control/Waveform Generator/Scope 2'
 * '<S25>'  : 'Model/Control/Waveform Generator/Walking waveform1'
 */
#endif                                 /* RTW_HEADER_Model_h_ */
