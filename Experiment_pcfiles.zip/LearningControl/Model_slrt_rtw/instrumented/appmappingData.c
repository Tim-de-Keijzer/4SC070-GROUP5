#include "slrtappmapping.h"
#include "./maps/Model.map"



const AppMapInfo appInfo[] = 
{
	{ /* Idx 0, <Model> */
		{ /* SignalMapInfo */
			Model_BIOMAP,
			Model_LBLMAP,
			Model_SIDMAP,
			Model_SBIO,
			Model_SLBL,
			{0,133},
			119,
		},
		{ /* ParamMapInfo */
			Model_PTIDSMAP,
			Model_PTNAMESMAP,
			Model_SPTMAP,
			{0,151},
			152,
		},
		"Model",
		"",
		"Model",
		3,
		Model_dtmap,
	},
};
int getNumRef(void){
	 return(sizeof(appInfo) / sizeof(AppMapInfo));
}