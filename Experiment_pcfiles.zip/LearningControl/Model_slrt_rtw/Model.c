/*
 * Model.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Model".
 *
 * Model version              : 1.779
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Jun 23 10:49:18 2023
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_logging_mmi.h"
#include "Model_capi.h"
#include "Model.h"
#include "Model_private.h"

/* Block signals (default storage) */
B_Model_T Model_B;

/* Continuous states */
X_Model_T Model_X;

/* Block states (default storage) */
DW_Model_T Model_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_Model_T Model_PrevZCX;

/* Real-time model */
RT_MODEL_Model_T Model_M_;
RT_MODEL_Model_T *const Model_M = &Model_M_;

/* n-D Spline interpolation function */
real_T look_SplNBinCZcd(uint32_T numDims, const real_T* u, const
  rt_LUTSplineWork * const SWork)
{
  /*
   *   n-D column-major table lookup operating on real_T with:
   *       - Spline interpolation
   *       - Clipping
   *       - Binary breakpoint search
   *       - Index search starts at the same place each time
   */
  rt_LUTnWork * const TWork_look = SWork->m_TWork;
  real_T* const fraction = (real_T*) TWork_look->m_bpLambda;
  uint32_T* const bpIdx = TWork_look->m_bpIndex;
  const uint32_T* const maxIndex = TWork_look->m_maxIndex;
  uint32_T k;
  for (k = 0U; k < numDims; k++) {
    const real_T* const bpData = ((const real_T * const *)
      TWork_look->m_bpDataSet)[k];
    bpIdx[k] = plook_binc(u[k], bpData, maxIndex[k], &fraction[k]);
  }

  return(intrp_NSplcd(numDims, SWork, 1U));
}

/*
 * Second derivative initialization function for spline
 * for last dimension.
 */
void rt_Spline2Derivd(const real_T *x, const real_T *y, uint32_T n, real_T *u,
                      real_T *y2)
{
  real_T p, qn, sig, un;
  uint32_T n1, i, k;
  n1 = n - 1U;
  y2[0U] = 0.0;
  u[0U] = 0.0;
  for (i = 1U; i < n1; i++) {
    real_T dxm1 = x[i] - x[i - 1U];
    real_T dxp1 = x[i + 1U] - x[i];
    real_T dxpm = dxp1 + dxm1;
    sig = dxm1 / dxpm;
    p = (sig * y2[i - 1U]) + 2.0;
    y2[i] = (sig - 1.0) / p;
    u[i] = ((y[i + 1U] - y[i]) / dxp1) - ((y[i] - y[i - 1U]) / dxm1);
    u[i] = (((6.0 * u[i]) / dxpm) - (sig * u[i - 1U])) / p;
  }

  qn = 0.0;
  un = 0.0;
  y2[n1] = (un - (qn * u[n1 - 1U])) / ((qn * y2[n1 - 1U]) + 1.0);
  for (k = n1; k > 0U; k--) {
    y2[k-1U] = (y2[k-1U] * y2[k]) + u[k-1U];
  }

  return;
}

/* n-D natural spline calculation function */
real_T intrp_NSplcd(uint32_T numDims, const rt_LUTSplineWork * const splWork,
                    uint32_T extrapMethod)
{
  uint32_T il;
  uint32_T iu, k, i;
  real_T h, s, p, smsq, pmsq;

  /* intermediate results work areas "this" and "next" */
  const rt_LUTnWork *TWork_interp = (const rt_LUTnWork *)splWork->m_TWork;
  const real_T *fraction = (real_T *) TWork_interp->m_bpLambda;
  const real_T *yp = (real_T *) TWork_interp->m_tableData;
  real_T *yyA = (real_T *) splWork->m_yyA;
  real_T *yyB = (real_T *) splWork->m_yyB;
  real_T *yy2 = (real_T *) splWork->m_yy2;
  real_T *up = (real_T *) splWork->m_up;
  real_T *y2 = (real_T *) splWork->m_y2;
  uint8_T* reCalc = splWork->m_reCalc;
  real_T *dp = (real_T *) splWork->m_preBp0AndTable;
  const real_T **bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
  const real_T *xp = bpDataSet[0U];
  real_T *yy = yyA;
  uint32_T bufBank = 0U;
  uint32_T len = TWork_interp->m_maxIndex[0U] + 1U;

  /* compare bp0 and table to see whether they get changed */
  {
    /* compare the bp0 data */
    if (memcmp(dp, xp,
               len * sizeof(real_T)) != 0) {
      *reCalc = 1;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
    }

    /* compare the table data */
    dp = &(dp[len]);
    if (memcmp(dp, yp,
               len * splWork->m_numYWorkElts[0U] * sizeof(real_T)) != 0) {
      *reCalc = 1;
      (void) memcpy(dp, yp,
                    len * splWork->m_numYWorkElts[0U] * sizeof(real_T));
    }
  }

  if (*reCalc == 1) {
    /* If table and bps are tunable calculate 1st dim 2nd deriv */
    /* Generate first dimension's second derivatives */
    for (i = 0U; i < splWork->m_numYWorkElts[0U]; i++) {
      rt_Spline2Derivd(xp, yp, len, up, y2);
      yp = &yp[len];
      y2 = &y2[len];
    }

    /* Set pointers back to beginning */
    yp = (const real_T *) TWork_interp->m_tableData;
    y2 = (real_T *) splWork->m_y2;
  }

  *reCalc = 0;

  /* Generate at-point splines in each dimension */
  for (k = 0U; k < numDims; k++ ) {
    /* this dimension's input setup */
    xp = bpDataSet[k];
    len = TWork_interp->m_maxIndex[k] + 1U;
    il = TWork_interp->m_bpIndex[k];
    iu = il + 1U;
    h = xp[iu] - xp[il];
    p = fraction[k];
    s = 1.0 - p;
    pmsq = p * ((p*p) - 1.0);
    smsq = s * ((s*s) - 1.0);

    /*
     * Calculate spline curves for input in this
     * dimension at each value of the higher
     * other dimensions\' points in the table.
     */
    if ((p > 1.0) && (extrapMethod == 2U) ) {
      real_T slope;
      for (i = 0U; i < splWork->m_numYWorkElts[k]; i++) {
        slope = (yp[iu] - yp[il]) + ((y2[il]*h*h)*(1.0/6.0));
        yy[i] = yp[iu] + (slope * (p-1.0));
        yp = &yp[len];
        y2 = &y2[len];
      }
    } else if ((p < 0.0) && (extrapMethod == 2U) ) {
      real_T slope;
      for (i = 0U; i < splWork->m_numYWorkElts[k]; i++) {
        slope = (yp[iu] - yp[il]) - ((y2[iu]*h*h)*(1.0/6.0));
        yy[i] = yp[il] + (slope * p);
        yp = &yp[len];
        y2 = &y2[len];
      }
    } else {
      for (i = 0U; i < splWork->m_numYWorkElts[k]; i++) {
        yy[i] = yp[il] + p * (yp[iu] - yp[il]) +
          ((smsq * y2[il] + pmsq * y2[iu])*h*h)*(1.0/6.0);
        yp = &yp[len];
        y2 = &y2[len];
      }
    }

    /* set pointers to new result and calculate second derivatives */
    yp = yy;
    y2 = yy2;
    if (splWork->m_numYWorkElts[k+1U] > 0U ) {
      uint32_T nextLen = TWork_interp->m_maxIndex[k+1U] + 1U;
      const real_T *nextXp = bpDataSet[k+1U];
      for (i = 0U; i < splWork->m_numYWorkElts[k+1U]; i++) {
        rt_Spline2Derivd(nextXp, yp, nextLen, up, y2);
        yp = &yp[nextLen];
        y2 = &y2[nextLen];
      }
    }

    /*
     * Set work vectors yp, y2 and yy for next iteration;
     * the yy just calculated becomes the yp in the
     * next iteration, y2 was just calculated for these
     * new points and the yy buffer is swapped to the space
     * for storing the next iteration\'s results.
     */
    yp = yy;
    y2 = yy2;

    /*
     * Swap buffers for next dimension and
     * toggle bufBank for next iteration.
     */
    if (bufBank == 0U) {
      yy = yyA;
      bufBank = 1U;
    } else {
      yy = yyB;
      bufBank = 0U;
    }
  }

  return( yp[0U] );
}

real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T bpIdx;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  return (table[iLeft + 1U] - table[iLeft]) * frac + table[iLeft];
}

uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex)
{
  uint32_T bpIndex;
  uint32_T iRght;
  uint32_T bpIdx;

  /* Binary Search */
  bpIdx = startIndex;
  bpIndex = 0U;
  iRght = maxIndex;
  while (iRght - bpIndex > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      bpIndex = bpIdx;
    }

    bpIdx = (iRght + bpIndex) >> 1U;
  }

  return bpIndex;
}

uint32_T plook_binc(real_T u, const real_T bp[], uint32_T maxIndex, real_T
                    *fraction)
{
  uint32_T bpIndex;

  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
    *fraction = 0.0;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d(u, bp, maxIndex >> 1U, maxIndex);
    *fraction = (u - bp[bpIndex]) / (bp[bpIndex + 1U] - bp[bpIndex]);
  } else {
    bpIndex = maxIndex - 1U;
    *fraction = 1.0;
  }

  return bpIndex;
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  Model_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T q;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    if (u1 < 0.0) {
      y = ceil(u1);
    } else {
      y = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != y)) {
      q = fabs(u0 / u1);
      if (!(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q)) {
        y = 0.0 * u0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T tmp;
  int32_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u1 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u0 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = atan2(tmp_0, tmp);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  boolean_T yEq;
  real_T q;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else if (rtIsInf(u1)) {
    if ((u1 < 0.0) != (u0 < 0.0)) {
      y = u1;
    }
  } else {
    y = fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > floor(u1))) {
      q = fabs(u0 / u1);
      yEq = !(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0;
    } else {
      if ((u0 < 0.0) != (u1 < 0.0)) {
        y += u1;
      }
    }
  }

  return y;
}

/* Model output function */
void Model_output(void)
{
  ZCEventType zcEvent;
  real_T *lastU;
  real_T u1;
  int32_T tableOffset;
  boolean_T zcEvent_0;
  real_T u2;
  real_T u0;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* set solver stop time */
    if (!(Model_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Model_M->solverInfo, ((Model_M->Timing.clockTickH0
        + 1) * Model_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Model_M->solverInfo, ((Model_M->Timing.clockTick0 +
        1) * Model_M->Timing.stepSize0 + Model_M->Timing.clockTickH0 *
        Model_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Model_M)) {
    Model_M->Timing.t[0] = rtsiGetT(&Model_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(Model_DW.NegCounter_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(Model_DW.PosCounter_SubsysRanBC);
  if (rtmIsMajorTimeStep(Model_M)) {
    /* S-Function (scblock): '<S3>/S-Function' */
    /* ok to acquire for <S3>/S-Function */
    Model_DW.SFunction_IWORK.AcquireOK = 1;
  }

  /* S-Function (scblock): '<S4>/S-Function' */
  /* ok to acquire for <S4>/S-Function */
  Model_DW.SFunction_IWORK_k.AcquireOK = 1;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* S-Function (scblock): '<S5>/S-Function' */
    /* ok to acquire for <S5>/S-Function */
    Model_DW.SFunction_IWORK_a.AcquireOK = 1;
  }

  /* S-Function (scblock): '<S6>/S-Function' */
  /* ok to acquire for <S6>/S-Function */
  Model_DW.SFunction_IWORK_n.AcquireOK = 1;

  /* Clock: '<S8>/Clock' */
  Model_B.Clock = Model_M->Timing.t[0];

  /* Sum: '<S8>/Sum' incorporates:
   *  S-Function (sfun_tstart): '<S8>/startTime'
   */
  Model_B.Sum = Model_B.Clock - (0.0);

  /* Math: '<S8>/Math Function' incorporates:
   *  Constant: '<S8>/Constant'
   */
  Model_B.MathFunction = rt_remd_snf(Model_B.Sum, Model_P.Constant_Value);

  /* Lookup_n-D: '<S8>/Look-Up Table1' */
  Model_B.LookUpTable1 = look1_binlxpw(Model_B.MathFunction,
    Model_P.LookUpTable1_bp01Data, Model_P.RepeatingSequence_rep_seq_y, 6U);

  /* SignalConversion: '<S8>/Output' */
  Model_B.Output = Model_B.LookUpTable1;

  /* Gain: '<S1>/Gain1' */
  Model_B.reference = Model_P.Gain1_Gain * Model_B.Output;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input' */

    /* Level2 S-Function Block: '<S7>/IO397 Analog Input' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[0];
      sfcnOutputs(rts,1);
    }

    /* Sum: '<S11>/Sum of Elements' */
    Model_B.SumofElements = Model_B.IO397AnalogInput_o1 -
      Model_B.IO397AnalogInput_o2;

    /* Gain: '<S11>/Gain9' */
    Model_B.encSinUnc = Model_P.Gain9_Gain * Model_B.SumofElements;

    /* Sum: '<S11>/Sum of Elements1' */
    Model_B.SumofElements1 = Model_B.IO397AnalogInput_o3 -
      Model_B.IO397AnalogInput_o4;

    /* Gain: '<S11>/Gain10' */
    Model_B.encCosUnc = Model_P.Gain10_Gain * Model_B.SumofElements1;

    /* MATLAB Function: '<S11>/MATLAB Function' incorporates:
     *  Constant: '<S11>/Constant2'
     *  Constant: '<S11>/Constant3'
     *  Constant: '<S11>/Constant4'
     *  Constant: '<S11>/Constant5'
     *  Constant: '<S11>/Constant6'
     */
    /* MATLAB Function 'Control/SinCos Decoder/MATLAB Function': '<S14>:1' */
    /* '<S14>:1:3' */
    u1 = Model_P.pCosineGain * Model_B.encCosUnc;

    /* '<S14>:1:7' */
    Model_B.cosC = u1 - Model_P.pCosineOffset;

    /* '<S14>:1:8' */
    Model_B.sinC = ((u1 - Model_P.pCosineOffset) * sin(Model_P.pAngleCorrection)
                    + (Model_B.encSinUnc - Model_P.pSineOffset) *
                    Model_P.pSineGain) * (1.0 / cos(Model_P.pAngleCorrection));

    /* Gain: '<S11>/Gain5' */
    Model_B.encSinCor = Model_P.Gain5_Gain * Model_B.sinC;

    /* HitCross: '<S18>/Hit  Crossing Neg' */
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                       &Model_PrevZCX.HitCrossingNeg_Input_ZCE,
                       (Model_B.encSinCor - Model_P.HitCrossingNeg_Offset));
    if (Model_DW.HitCrossingNeg_MODE == 0) {
      if (zcEvent != NO_ZCEVENT) {
        Model_B.HitCrossingNeg = !Model_B.HitCrossingNeg;
        Model_DW.HitCrossingNeg_MODE = 1;
      } else {
        if (Model_B.HitCrossingNeg) {
          Model_B.HitCrossingNeg = ((!(Model_B.encSinCor !=
            Model_P.HitCrossingNeg_Offset)) && Model_B.HitCrossingNeg);
        }
      }
    } else {
      Model_B.HitCrossingNeg = ((!(Model_B.encSinCor !=
        Model_P.HitCrossingNeg_Offset)) && Model_B.HitCrossingNeg);
      Model_DW.HitCrossingNeg_MODE = 0;
    }

    /* End of HitCross: '<S18>/Hit  Crossing Neg' */

    /* Gain: '<S11>/Gain8' */
    Model_B.encCosCor = Model_P.Gain8_Gain * Model_B.cosC;

    /* RelationalOperator: '<S19>/Compare' incorporates:
     *  Constant: '<S19>/Constant'
     */
    Model_B.Compare = (Model_B.encCosCor < Model_P.CompareToConstant_const);

    /* Logic: '<S18>/Logical Operator Neg' */
    Model_B.LogicalOperatorNeg = (Model_B.HitCrossingNeg && Model_B.Compare);

    /* Outputs for Triggered SubSystem: '<S18>/NegCounter' incorporates:
     *  TriggerPort: '<S20>/Trigger'
     */
    if (rtmIsMajorTimeStep(Model_M)) {
      zcEvent_0 = (Model_B.LogicalOperatorNeg &&
                   (Model_PrevZCX.NegCounter_Trig_ZCE != 1));
      if (zcEvent_0) {
        /* UnitDelay: '<S20>/Unit Delay' */
        Model_B.UnitDelay_p = Model_DW.UnitDelay_DSTATE_o;

        /* Sum: '<S20>/Sum' incorporates:
         *  Constant: '<S20>/Constant_neg'
         */
        Model_B.Sum_dz = Model_P.Constant_neg_Value + Model_B.UnitDelay_p;

        /* Update for UnitDelay: '<S20>/Unit Delay' */
        Model_DW.UnitDelay_DSTATE_o = Model_B.Sum_dz;
        Model_DW.NegCounter_SubsysRanBC = 4;
      }

      Model_PrevZCX.NegCounter_Trig_ZCE = Model_B.LogicalOperatorNeg;
    }

    /* End of Outputs for SubSystem: '<S18>/NegCounter' */

    /* HitCross: '<S18>/Hit  Crossing Pos' */
    zcEvent = rt_ZCFcn(FALLING_ZERO_CROSSING,
                       &Model_PrevZCX.HitCrossingPos_Input_ZCE,
                       (Model_B.encSinCor - Model_P.HitCrossingPos_Offset));
    if (Model_DW.HitCrossingPos_MODE == 0) {
      if (zcEvent != NO_ZCEVENT) {
        Model_B.HitCrossingPos = !Model_B.HitCrossingPos;
        Model_DW.HitCrossingPos_MODE = 1;
      } else {
        if (Model_B.HitCrossingPos) {
          Model_B.HitCrossingPos = ((!(Model_B.encSinCor !=
            Model_P.HitCrossingPos_Offset)) && Model_B.HitCrossingPos);
        }
      }
    } else {
      Model_B.HitCrossingPos = ((!(Model_B.encSinCor !=
        Model_P.HitCrossingPos_Offset)) && Model_B.HitCrossingPos);
      Model_DW.HitCrossingPos_MODE = 0;
    }

    /* End of HitCross: '<S18>/Hit  Crossing Pos' */

    /* Logic: '<S18>/Logical Operator Pos' */
    Model_B.LogicalOperatorPos = (Model_B.HitCrossingPos && Model_B.Compare);

    /* Outputs for Triggered SubSystem: '<S18>/PosCounter' incorporates:
     *  TriggerPort: '<S21>/Trigger'
     */
    if (rtmIsMajorTimeStep(Model_M)) {
      zcEvent_0 = (Model_B.LogicalOperatorPos &&
                   (Model_PrevZCX.PosCounter_Trig_ZCE != 1));
      if (zcEvent_0) {
        /* UnitDelay: '<S21>/Unit Delay' */
        Model_B.UnitDelay = Model_DW.UnitDelay_DSTATE;

        /* Sum: '<S21>/Sum' incorporates:
         *  Constant: '<S21>/Constant_pos'
         */
        Model_B.Sum_a = Model_P.Constant_pos_Value + Model_B.UnitDelay;

        /* Update for UnitDelay: '<S21>/Unit Delay' */
        Model_DW.UnitDelay_DSTATE = Model_B.Sum_a;
        Model_DW.PosCounter_SubsysRanBC = 4;
      }

      Model_PrevZCX.PosCounter_Trig_ZCE = Model_B.LogicalOperatorPos;
    }

    /* End of Outputs for SubSystem: '<S18>/PosCounter' */

    /* Sum: '<S18>/Add2' */
    Model_B.Add2 = Model_B.Sum_a - Model_B.Sum_dz;

    /* Gain: '<S11>/Gain3' */
    Model_B.encCount = Model_P.Gain3_Gain * Model_B.Add2;

    /* Gain: '<S11>/Gain4' */
    Model_B.Gain4 = Model_P.Gain4_Gain * Model_B.encCount;

    /* Trigonometry: '<S11>/atan2' */
    Model_B.atan2_l = rt_atan2d_snf(Model_B.encSinCor, Model_B.encCosCor);

    /* Gain: '<S11>/Gain6' */
    Model_B.encInt = Model_P.Gain6_Gain * Model_B.atan2_l;

    /* Sum: '<S11>/Sum1' */
    Model_B.Sum1 = Model_B.Gain4 + Model_B.encInt;

    /* Gain: '<S11>/Gain7' */
    Model_B.Gain7 = Model_P.Gain7_Gain * Model_B.Sum1;

    /* Gain: '<S11>/Gain2' */
    Model_B.Gain2 = Model_P.pEncRes * Model_B.Gain7;
  }

  /* Sum: '<S1>/Add1' */
  Model_B.error = Model_B.reference - Model_B.Gain2;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* S-Function (scblock): '<S15>/S-Function' */
    /* ok to acquire for <S15>/S-Function */
    Model_DW.SFunction_IWORK_no.AcquireOK = 1;

    /* S-Function (scblock): '<S16>/S-Function' */
    /* ok to acquire for <S16>/S-Function */
    Model_DW.SFunction_IWORK_ax.AcquireOK = 1;

    /* S-Function (scblock): '<S17>/S-Function' */
    /* ok to acquire for <S17>/S-Function */
    Model_DW.SFunction_IWORK_g.AcquireOK = 1;

    /* Delay: '<S11>/Delay' */
    Model_B.Delay = Model_DW.Delay_DSTATE;

    /* Sum: '<S11>/Add' */
    Model_B.Add = Model_B.Gain2 - Model_B.Delay;
  }

  /* Gain: '<S11>/Gain11' */
  Model_B.idealPos = Model_P.Gain11_Gain * Model_B.reference;

  /* Sum: '<S11>/Add1' */
  Model_B.Add1 = Model_B.idealPos - Model_B.Gain2;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* Product: '<S11>/Divide' incorporates:
     *  Constant: '<S11>/Constant1'
     */
    Model_B.Divide = Model_B.Add / Model_P.tSample;

    /* S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input1' */

    /* Level2 S-Function Block: '<S7>/IO397 Analog Input1' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[1];
      sfcnOutputs(rts,1);
    }

    /* Gain: '<S11>/Gain1' */
    Model_B.encRef[0] = Model_P.Gain1_Gain_n * Model_B.IO397AnalogInput1_o1;
    Model_B.encRef[1] = Model_P.Gain1_Gain_n * Model_B.IO397AnalogInput1_o2;

    /* Memory: '<S12>/Memory' */
    Model_B.Memory = Model_DW.Memory_PreviousInput;

    /* Sum: '<S12>/Sum' incorporates:
     *  Constant: '<S12>/Constant'
     */
    Model_B.index_counter = Model_B.Memory + Model_P.Constant_Value_i;

    /* LookupNDDirect: '<S12>/Direct Lookup Table (n-D)' incorporates:
     *  Constant: '<S12>/u_ff'
     *
     * About '<S12>/Direct Lookup Table (n-D)':
     *  1-dimensional Direct Look-Up returning a Scalar,
     *
     *     Remove protection against out-of-range input in generated code: 'off'
     */
    u0 = Model_B.index_counter;
    if (u0 > 50999.0) {
      u0 = 50999.0;
    } else {
      if (u0 < 0.0) {
        u0 = 0.0;
      }
    }

    tableOffset = (int32_T)u0;
    Model_B.DirectLookupTablenD = Model_P.u_ff[tableOffset];

    /* End of LookupNDDirect: '<S12>/Direct Lookup Table (n-D)' */
  }

  /* Sum: '<S1>/Sum' */
  Model_B.Sum_g = Model_B.DirectLookupTablenD + Model_B.reference;

  /* S-Function (scblock): '<S23>/S-Function' */
  /* ok to acquire for <S23>/S-Function */
  Model_DW.SFunction_IWORK_p.AcquireOK = 1;

  /* S-Function (scblock): '<S24>/S-Function' */
  /* ok to acquire for <S24>/S-Function */
  Model_DW.SFunction_IWORK_m.AcquireOK = 1;

  /* Integrator: '<S22>/Integrator' */
  Model_B.Integrator = Model_X.Integrator_CSTATE;

  /* Gain: '<S22>/Gain3' */
  Model_B.alpha = Model_P.Gain3_Gain_k * Model_B.Integrator;

  /* Math: '<S13>/Math Function' incorporates:
   *  Constant: '<S13>/Constant2'
   */
  Model_B.alpha_mod = rt_modd_snf(Model_B.alpha, Model_P.Constant2_Value);

  /* Outputs for Atomic SubSystem: '<S13>/Walking waveform1' */
  /* Lookup_n-D: '<S25>/C2' */
  Model_B.C2 = look1_binlxpw(Model_B.alpha_mod, Model_P.C2_bp01Data,
    Model_P.C2_tableData, 5U);

  /* Lookup_n-D: '<S25>/clamp2' */
  /*
   * About '<S25>/clamp2':
   *       Table size:  3
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.test1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod, (rt_LUTSplineWork*)
    &Model_DW.SWork[0]);

  /* Gain: '<S25>/Gain' */
  Model_B.Gain = Model_P.Clamp2Amp * Model_B.test1;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Sum: '<S25>/Add' */
  Model_B.Add_k = Model_B.C2 + Model_B.Gain;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Lookup_n-D: '<S25>/S1' */
  Model_B.S1 = look1_binlxpw(Model_B.alpha_mod, Model_P.S1_bp01Data,
    Model_P.S1_tableData, 3U);

  /* Lookup_n-D: '<S25>/0.55 tot 0.95 shear1' */
  /*
   * About '<S25>/0.55 tot 0.95 shear1':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u55tot095shear1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_d[0]);

  /* Gain: '<S25>/Gain8' */
  u1 = -Model_P.ShearAmp + Model_P.ofsetshear2;
  Model_B.Gain8 = u1 * Model_B.u55tot095shear1;

  /* Lookup_n-D: '<S25>/0.05 tot 0.45 shear1' */
  /*
   * About '<S25>/0.05 tot 0.45 shear1':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u05tot045shear1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_o[0]);

  /* Gain: '<S25>/Gain2' */
  Model_B.Gain2_m = Model_P.ShearAmp * Model_B.u05tot045shear1;

  /* Sum: '<S25>/Add8' */
  Model_B.Add8 = Model_B.Gain8 + Model_B.Gain2_m;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Sum: '<S25>/Add7' */
  Model_B.Add7 = Model_B.S1 + Model_B.Add8;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Lookup_n-D: '<S25>/S2' */
  Model_B.S2 = look1_binlxpw(Model_B.alpha_mod, Model_P.S2_bp01Data,
    Model_P.S2_tableData, 3U);

  /* Lookup_n-D: '<S25>/0.55 tot 0.95 shear2' */
  /*
   * About '<S25>/0.55 tot 0.95 shear2':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u55tot095shear2 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_f[0]);

  /* Gain: '<S25>/Gain4' */
  u1 = -Model_P.ShearAmp + Model_P.ofsetshear2;
  Model_B.Gain4_g = u1 * Model_B.u55tot095shear2;

  /* Lookup_n-D: '<S25>/0.05 tot 0.45 shear2' */
  /*
   * About '<S25>/0.05 tot 0.45 shear2':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u05tot045shear2 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_g[0]);

  /* Gain: '<S25>/Gain5' */
  Model_B.Gain5 = Model_P.ShearAmp * Model_B.u05tot045shear2;

  /* Sum: '<S25>/Add9' */
  Model_B.Add9 = Model_B.Gain4_g + Model_B.Gain5;

  /* Sum: '<S25>/Add6' */
  Model_B.Add6 = Model_B.S2 + Model_B.Add9;

  /* Lookup_n-D: '<S25>/0.55 tot 0.95 clamp1' */
  /*
   * About '<S25>/0.55 tot 0.95 clamp1':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u55tot095clamp1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_b[0]);

  /* Gain: '<S25>/Gain11' */
  u1 = Model_P.ClampsSineAmp + Model_P.clampofset;
  Model_B.Gain11 = u1 * Model_B.u55tot095clamp1;

  /* Lookup_n-D: '<S25>/0.05 tot 0.45 clamp1' */
  /*
   * About '<S25>/0.05 tot 0.45 clamp1':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u05tot045clamp1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_h[0]);

  /* Gain: '<S25>/Gain10' */
  u1 = -Model_P.ClampsSineAmp;
  Model_B.Gain10 = u1 * Model_B.u05tot045clamp1;

  /* Sum: '<S25>/Add11' */
  Model_B.Add11 = Model_B.Gain11 + Model_B.Gain10;

  /* Lookup_n-D: '<S25>/C1' */
  Model_B.C1 = look1_binlxpw(Model_B.alpha_mod, Model_P.C1_bp01Data,
    Model_P.C1_tableData, 5U);

  /* Lookup_n-D: '<S25>/0 tot 0.05' */
  /*
   * About '<S25>/0 tot 0.05':
   *       Table size:  3
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.utot005 = look_SplNBinCZcd(1U, &Model_B.alpha_mod, (rt_LUTSplineWork*)
    &Model_DW.SWork_n[0]);

  /* Gain: '<S25>/Gain1' */
  Model_B.Gain1_i = Model_P.Clamp1Amp * Model_B.utot005;

  /* Lookup_n-D: '<S25>/0.95 tot 1' */
  /*
   * About '<S25>/0.95 tot 1':
   *       Table size:  3
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u95tot1 = look_SplNBinCZcd(1U, &Model_B.alpha_mod, (rt_LUTSplineWork*)
    &Model_DW.SWork_e[0]);

  /* Gain: '<S25>/Gain3' */
  Model_B.Gain3 = Model_P.Clamp1Amp * Model_B.u95tot1;

  /* Sum: '<S25>/Add3' */
  Model_B.Add3 = Model_B.Gain1_i + Model_B.Gain3;

  /* Sum: '<S25>/Add2' */
  Model_B.Add2_h = Model_B.C1 + Model_B.Add3;

  /* Sum: '<S25>/Add4' */
  Model_B.Add4 = Model_B.Add11 + Model_B.Add2_h;

  /* Lookup_n-D: '<S25>/0.55 tot 0.95 clamp2' */
  /*
   * About '<S25>/0.55 tot 0.95 clamp2':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u55tot095clamp2 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_ee[0]);

  /* Gain: '<S25>/Gain6' */
  u1 = -Model_P.ClampsSineAmp - Model_P.clampofset;
  Model_B.Gain6 = u1 * Model_B.u55tot095clamp2;

  /* Lookup_n-D: '<S25>/0.05 tot 0.45 clamp2' */
  /*
   * About '<S25>/0.05 tot 0.45 clamp2':
   *       Table size:  5
   *    Interpolation:  Spline
   *    Extrapolation:  None - Clip
   *   Breakpt Search:  Binary
   *    Breakpt Cache:  OFF
   */
  Model_B.u05tot045clamp2 = look_SplNBinCZcd(1U, &Model_B.alpha_mod,
    (rt_LUTSplineWork*)&Model_DW.SWork_bg[0]);

  /* Gain: '<S25>/Gain7' */
  Model_B.Gain7_c = Model_P.ClampsSineAmp * Model_B.u05tot045clamp2;

  /* Sum: '<S25>/Add13' */
  Model_B.Add13 = Model_B.Gain6 + Model_B.Gain7_c;

  /* Sum: '<S25>/Add1' */
  Model_B.Add1_h = Model_B.Add13 + Model_B.Add_k;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Sum: '<S25>/Add10' */
  Model_B.Add10 = Model_B.C1 + Model_B.Add11;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* Sum: '<S25>/Add12' */
  Model_B.Add12 = Model_B.C2 + Model_B.Add13;
  if (rtmIsMajorTimeStep(Model_M)) {
  }

  /* End of Outputs for SubSystem: '<S13>/Walking waveform1' */

  /* Gain: '<S13>/Gain1' */
  Model_B.Gain1[0] = Model_P.pClampAmpl * Model_B.Add4;
  Model_B.Gain1[1] = Model_P.pClampAmpl * Model_B.Add1_h;

  /* Gain: '<S13>/Gain2' */
  Model_B.Gain2_j[0] = Model_P.pShearAmpl * Model_B.Add7;
  Model_B.Gain2_j[1] = Model_P.pShearAmpl * Model_B.Add6;

  /* Sum: '<S13>/Sum1' incorporates:
   *  Constant: '<S13>/Constant1'
   */
  Model_B.Sum1_o[0] = Model_B.Gain1[0] + Model_P.pClampOffs;
  Model_B.Sum1_o[1] = Model_B.Gain1[1] + Model_P.pClampOffs;

  /* Gain: '<S13>/Gain3' */
  Model_B.ClampTru[0] = Model_P.Gain3_Gain_o * Model_B.Sum1_o[0];
  Model_B.ClampTru[1] = Model_P.Gain3_Gain_o * Model_B.Sum1_o[1];

  /* Sum: '<S13>/Sum' incorporates:
   *  Constant: '<S13>/Constant'
   */
  Model_B.Sum_i[0] = Model_P.pShearOffs + Model_B.Gain2_j[0];
  Model_B.Sum_i[1] = Model_P.pShearOffs + Model_B.Gain2_j[1];

  /* Gain: '<S13>/Gain4' */
  Model_B.ShearTru[0] = Model_P.Gain4_Gain_c * Model_B.Sum_i[0];
  Model_B.ShearTru[1] = Model_P.Gain4_Gain_c * Model_B.Sum_i[1];

  /* Saturate: '<S13>/Saturation' */
  u0 = Model_B.Sum_i[0];
  u1 = Model_P.Saturation_LowerSat[0];
  u2 = Model_P.Saturation_UpperSat[0];
  if (u0 > u2) {
    u0 = u2;
  } else {
    if (u0 < u1) {
      u0 = u1;
    }
  }

  Model_B.Saturation[0] = u0;
  u0 = Model_B.Sum1_o[0];
  u1 = Model_P.Saturation_LowerSat[2];
  u2 = Model_P.Saturation_UpperSat[2];
  if (u0 > u2) {
    u0 = u2;
  } else {
    if (u0 < u1) {
      u0 = u1;
    }
  }

  Model_B.Saturation[2] = u0;
  u0 = Model_B.Sum_i[1];
  u1 = Model_P.Saturation_LowerSat[1];
  u2 = Model_P.Saturation_UpperSat[1];
  if (u0 > u2) {
    u0 = u2;
  } else {
    if (u0 < u1) {
      u0 = u1;
    }
  }

  Model_B.Saturation[1] = u0;
  u0 = Model_B.Sum1_o[1];
  u1 = Model_P.Saturation_LowerSat[3];
  u2 = Model_P.Saturation_UpperSat[3];
  if (u0 > u2) {
    u0 = u2;
  } else {
    if (u0 < u1) {
      u0 = u1;
    }
  }

  Model_B.Saturation[3] = u0;

  /* End of Saturate: '<S13>/Saturation' */

  /* Gain: '<S13>/Gain7' */
  Model_B.Gain7_j[0] = Model_P.pAmpGain[0] * Model_B.Saturation[0];
  Model_B.Gain7_j[1] = Model_P.pAmpGain[1] * Model_B.Saturation[1];
  Model_B.Gain7_j[2] = Model_P.pAmpGain[2] * Model_B.Saturation[2];
  Model_B.Gain7_j[3] = Model_P.pAmpGain[3] * Model_B.Saturation[3];

  /* Derivative: '<S22>/Derivative' */
  if ((Model_DW.TimeStampA >= Model_M->Timing.t[0]) && (Model_DW.TimeStampB >=
       Model_M->Timing.t[0])) {
    Model_B.Derivative = 0.0;
  } else {
    u1 = Model_DW.TimeStampA;
    lastU = &Model_DW.LastUAtTimeA;
    if (Model_DW.TimeStampA < Model_DW.TimeStampB) {
      if (Model_DW.TimeStampB < Model_M->Timing.t[0]) {
        u1 = Model_DW.TimeStampB;
        lastU = &Model_DW.LastUAtTimeB;
      }
    } else {
      if (Model_DW.TimeStampA >= Model_M->Timing.t[0]) {
        u1 = Model_DW.TimeStampB;
        lastU = &Model_DW.LastUAtTimeB;
      }
    }

    u1 = Model_M->Timing.t[0] - u1;
    Model_B.Derivative = (Model_B.Sum_g - *lastU) / u1;
  }

  /* End of Derivative: '<S22>/Derivative' */

  /* Signum: '<S22>/Sign' */
  u1 = Model_B.Derivative;
  if (u1 < 0.0) {
    Model_B.Sign = -1.0;
  } else if (u1 > 0.0) {
    Model_B.Sign = 1.0;
  } else if (u1 == 0.0) {
    Model_B.Sign = 0.0;
  } else {
    Model_B.Sign = (rtNaN);
  }

  /* End of Signum: '<S22>/Sign' */

  /* Switch: '<S22>/Switch' */
  if (Model_B.Sign > Model_P.Switch_Threshold) {
    /* Gain: '<S22>/Gain2' */
    u1 = 1.0 / Model_P.forwardGain;
    Model_B.Gain2_m4 = u1 * Model_B.Derivative;
    Model_B.Switch = Model_B.Gain2_m4;
  } else {
    /* Gain: '<S22>/Gain1' */
    u1 = 1.0 / Model_P.backwardGain;
    Model_B.Gain1_f = u1 * Model_B.Derivative;
    Model_B.Switch = Model_B.Gain1_f;
  }

  /* End of Switch: '<S22>/Switch' */

  /* Clock: '<S9>/Clock' */
  Model_B.Clock_h = Model_M->Timing.t[0];

  /* Sum: '<S9>/Sum' incorporates:
   *  S-Function (sfun_tstart): '<S9>/startTime'
   */
  Model_B.Sum_d = Model_B.Clock_h - (0.0);

  /* Math: '<S9>/Math Function' incorporates:
   *  Constant: '<S9>/Constant'
   */
  Model_B.MathFunction_e = rt_remd_snf(Model_B.Sum_d, Model_P.Constant_Value_o);

  /* Lookup_n-D: '<S9>/Look-Up Table1' */
  Model_B.LookUpTable1_d = look1_binlxpw(Model_B.MathFunction_e,
    Model_P.LookUpTable1_bp01Data_h, Model_P.RepeatingSequence1_rep_seq_y, 2U);

  /* SignalConversion: '<S9>/Output' */
  Model_B.Output_a = Model_B.LookUpTable1_d;

  /* Clock: '<S10>/Clock' */
  Model_B.Clock_f = Model_M->Timing.t[0];

  /* Sum: '<S10>/Sum' incorporates:
   *  S-Function (sfun_tstart): '<S10>/startTime'
   */
  Model_B.Sum_m = Model_B.Clock_f - (0.0);

  /* Math: '<S10>/Math Function' incorporates:
   *  Constant: '<S10>/Constant'
   */
  Model_B.MathFunction_a = rt_remd_snf(Model_B.Sum_m, Model_P.Constant_Value_n);

  /* Lookup_n-D: '<S10>/Look-Up Table1' */
  Model_B.LookUpTable1_b = look1_binlxpw(Model_B.MathFunction_a,
    Model_P.LookUpTable1_bp01Data_b, Model_P.RepeatingSequence2_rep_seq_y, 2U);

  /* SignalConversion: '<S10>/Output' */
  Model_B.Output_d = Model_B.LookUpTable1_b;

  /* Gain: '<Root>/Gain' */
  Model_B.Error = Model_P.Gain_Gain * Model_B.Add1;

  /* Gain: '<Root>/Gain3' */
  Model_B.CommAngle = Model_P.Gain3_Gain_a * Model_B.alpha_mod;

  /* Gain: '<Root>/Gain4' */
  Model_B.ClampAnl[0] = Model_P.Gain4_Gain_p * Model_B.Gain7_j[2];
  Model_B.ClampAnl[1] = Model_P.Gain4_Gain_p * Model_B.Gain7_j[3];

  /* Gain: '<Root>/Gain5' */
  Model_B.ShearAnl[0] = Model_P.Gain5_Gain_k * Model_B.Gain7_j[0];
  Model_B.ShearAnl[1] = Model_P.Gain5_Gain_k * Model_B.Gain7_j[1];
  if (rtmIsMajorTimeStep(Model_M)) {
    /* Gain: '<Root>/Gain1' */
    Model_B.Velocity = Model_P.Gain1_Gain_d * Model_B.Divide;

    /* Gain: '<Root>/Gain2' */
    Model_B.Position = Model_P.Gain2_Gain * Model_B.Gain2;

    /* S-Function (sg_fpga_IO397_da): '<S7>/IO397 Analog Output1' */

    /* Level2 S-Function Block: '<S7>/IO397 Analog Output1' (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Model_M->childSfunctions[2];
      sfcnOutputs(rts,1);
    }
  }
}

/* Model update function */
void Model_update(void)
{
  real_T *lastU;
  if (rtmIsMajorTimeStep(Model_M)) {
    /* Update for Delay: '<S11>/Delay' */
    Model_DW.Delay_DSTATE = Model_B.Gain2;

    /* Update for Memory: '<S12>/Memory' */
    Model_DW.Memory_PreviousInput = Model_B.index_counter;
  }

  /* Update for Derivative: '<S22>/Derivative' */
  if (Model_DW.TimeStampA == (rtInf)) {
    Model_DW.TimeStampA = Model_M->Timing.t[0];
    lastU = &Model_DW.LastUAtTimeA;
  } else if (Model_DW.TimeStampB == (rtInf)) {
    Model_DW.TimeStampB = Model_M->Timing.t[0];
    lastU = &Model_DW.LastUAtTimeB;
  } else if (Model_DW.TimeStampA < Model_DW.TimeStampB) {
    Model_DW.TimeStampA = Model_M->Timing.t[0];
    lastU = &Model_DW.LastUAtTimeA;
  } else {
    Model_DW.TimeStampB = Model_M->Timing.t[0];
    lastU = &Model_DW.LastUAtTimeB;
  }

  *lastU = Model_B.Sum_g;

  /* End of Update for Derivative: '<S22>/Derivative' */
  if (rtmIsMajorTimeStep(Model_M)) {
    rt_ertODEUpdateContinuousStates(&Model_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Model_M->Timing.clockTick0)) {
    ++Model_M->Timing.clockTickH0;
  }

  Model_M->Timing.t[0] = rtsiGetSolverStopTime(&Model_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.0001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Model_M->Timing.clockTick1)) {
      ++Model_M->Timing.clockTickH1;
    }

    Model_M->Timing.t[1] = Model_M->Timing.clockTick1 *
      Model_M->Timing.stepSize1 + Model_M->Timing.clockTickH1 *
      Model_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void Model_derivatives(void)
{
  XDot_Model_T *_rtXdot;
  _rtXdot = ((XDot_Model_T *) Model_M->derivs);

  /* Derivatives for Integrator: '<S22>/Integrator' */
  _rtXdot->Integrator_CSTATE = Model_B.Switch;
}

/* Model initialize function */
void Model_initialize(void)
{
  {
    /* user code (Start function Header) */
    {
      uint16_t moduleArchitecture;
      int32_t ErrCode;
      uint32_t *bitstream, i;
      uint8_t *fpgacode;
      char *devname;
      sg_fpga_io3xxModuleIdT moduleId;
      FILE *mcs;
      static char mcsFileName[200];
      static char msg[256];

      //Get the bitstream length and start of the array.

      //Create the MCS File and then add it to the mldatx
#ifdef _MSC_BUILD

      sprintf(mcsFileName, "\\private\\fpga\\speedgoat_IO397_50k_CI_02165.mcs");

#else

      //find the location of the mcs file
      FILE *find_cmd = popen(
        "find /home/slrt/applications -name speedgoat_IO397_50k_CI_02165.mcs -print | head -n 1",
        "r");
      if (find_cmd == NULL) {
        sprintf(msg, "Could not open file search comand.\n");
        rtmSetErrorStatus(Model_M, msg);
        return;
      }

      fscanf(find_cmd,"%s",mcsFileName);
      if (pclose(find_cmd) < 0) {
        sprintf(msg, "Could not close file search comand.\n");
        rtmSetErrorStatus(Model_M, msg);
        return;
      }

      SG_PRINTF(DEBUG, "Found bitstream at: %s\n",mcsFileName);

#endif

#ifdef _MSC_BUILD

      if (sg_isModelInit()) {

#endif

        if ((mcs = fopen(mcsFileName, "r")) == NULL) {
          sprintf(msg, "Bitstream file not found at %s.\n", mcsFileName);
          rtmSetErrorStatus(Model_M, msg);
          SG_PRINTF(ERROR,msg);
          return;
        }

        bitstream = (uint32_t *) malloc(2192012*sizeof(uint32_t));
        fpgacode = (uint8_t *) malloc(2192012*sizeof(uint8_t));
        for (i = 0; i<2192012; i++) {
          fscanf(mcs,"%d\n",&bitstream[i]);
          fpgacode[i] = bitstream[i];
        }

        fclose(mcs);

        // Get Module ID's (PIC info)
        SG_PRINTF(INFO,"Getting module information.\n");
        ErrCode = (int32_t)sg_fpga_IO3xxGetModuleId(39750, &moduleId);
        if (ErrCode >= 0) {
          devname = moduleId.devname;
          moduleArchitecture = moduleId.moduleArchitecture;
          SG_PRINTF(DEBUG, "boardType: %d\n", 39750);
          SG_PRINTF(DEBUG, "ErrCode: %d\n", ErrCode);
          SG_PRINTF(DEBUG, "******************************************\n");
          SG_PRINTF(DEBUG, "moduleId->devname: %s\n", moduleId.devname);
          SG_PRINTF(DEBUG, "moduleId->vendorid: 0x%x\n", moduleId.vendorid);
          SG_PRINTF(DEBUG, "moduleId->subvendorid: 0x%x\n", moduleId.subvendorid);
          SG_PRINTF(DEBUG, "moduleId->deviceid: 0x%x\n", moduleId.deviceid);
          SG_PRINTF(DEBUG, "moduleId->subdeviceid: 0x%x\n", moduleId.subdeviceid);
          SG_PRINTF(DEBUG, "moduleId.moduleArchitecture: %d\n",
                    moduleId.moduleArchitecture);
        } else {
          sprintf(msg, "Setup block: board type unknown.");
          rtmSetErrorStatus(Model_M, msg);
          SG_PRINTF(ERROR,msg);
          return;
        }

        //support for different architecture:
        SG_PRINTF(INFO,"Running board specific programming file.\n");
        switch (moduleArchitecture)
        {
         case TEWS_TPMC:
          ErrCode = IO30x_programFPGA(devname, (int16_t) 6 , (int16_t) 0 ,
            (int32_t) 1, (int32_t) 1 , (int32_t) 0, (uint32_t) 2192012,
            bitstream, &moduleId);
          break;

         case TEWS_TXMC:
          ErrCode = IO31x_IO32x_programmFPGA(devname, (int16_t) 6 , (int16_t) 0 ,
            (int32_t) 1, (int32_t) 1 , (int32_t) 0, (uint32_t) 2192012, fpgacode,
            &moduleId, (uint32_t) 85);
          break;

         case ACROMAG_PMC:
          ErrCode = IO331_programmFPGA(devname, (int16_t) 6 , (int16_t) 0 ,
            (int32_t) 1, (int32_t) 1 , (uint32_t) 2192012, bitstream, &moduleId);
          break;

         case ACROMAG_XMC:
          if (39750 == 332) {
            ErrCode = IO332_programmFPGA(devname, (int16_t) 6 , (int16_t) 0 ,
              (int32_t) 1, (int32_t) 1 , (uint32_t) 2192012, bitstream,(uint32_t)
              1546170855, &moduleId);
          } else                       // IO333
          {
            ErrCode = IO333_programmFPGA(devname, (int16_t) 6 , (int16_t) 0 ,
              (int32_t) 1, (int32_t) 1 , (uint32_t) 2192012, bitstream,(uint32_t)
              1546170855, &moduleId);
          }
          break;

         case TEWS_MPCIE:
          ErrCode = IO39x_programmFPGA(devname, (int16_t) 6, (int16_t) 0 ,
            (int32_t) 1, (int32_t) 1, (uint32_t) 2192012, fpgacode, (uint32_t)
            85, &moduleId);
          break;

         default:
          sprintf(msg, "Setup block: module architecture incorrect.");
          rtmSetErrorStatus(Model_M, msg);

          //Free the Bitstream allocation
          SG_PRINTF(ERROR,msg);
          free(bitstream);
          free(fpgacode);
          return;
        }

        //Free the Bitstream allocation
        free(bitstream);
        free(fpgacode);

        //Handle any error states
        switch (ErrCode)
        {
         case NO_ERR:
          {
            //Nothing to do.
            break;
          }

         case BOARD_NOT_FOUND:
          {
            sprintf(msg, "Setup block %s: Board could not be found.\n",devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case EEPROM_ERROR:
          {
            sprintf(msg, "Setup block %s: Error updating board EEPROM.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case REPROG_ERROR:
          {
            sprintf(msg,
                    "Setup block %s: Error writing new bitstream to FPGA.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case FLASH_ERROR:
          {
            sprintf(msg, "Setup block %s: Bitstream flash storage error.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case BIST_ERROR:
          {
            sprintf(msg, "Setup block %s: Built in self test error.\n", devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case ICAP_RECONF_FAILED:
          {
            sprintf(msg,
                    "Setup block %s: ICAP Reconfiguration was not successful.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case BOARD_TYPE_UNKNOWN:
          {
            sprintf(msg, "Setup block %s: The board type selected is unknown.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         default:
          {
            sprintf(msg, "Setup block %s: An unknown error occurred.\n",devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }
        }

        if (1 == 2) {
          IO3xx_21_update(devname, 1, 0, 0, 0);
        } else if (1 == 3) {
          IO3xx_22_update(devname, 1, 0, 0, 0);
        }

#ifdef _MSC_BUILD

      }

#endif

    }

    {
      uint16_t moduleArchitecture;
      int32_t ErrCode;
      uint32_t *bitstream, i;
      uint8_t *fpgacode;
      char *devname;
      sg_fpga_io3xxModuleIdT moduleId;
      FILE *mcs;
      static char mcsFileName[200];
      static char msg[256];

      //Get the bitstream length and start of the array.

      //Create the MCS File and then add it to the mldatx
#ifdef _MSC_BUILD

      sprintf(mcsFileName, "\\private\\fpga\\speedgoat_IO397_50k_CI_02165.mcs");

#else

      //find the location of the mcs file
      FILE *find_cmd = popen(
        "find /home/slrt/applications -name speedgoat_IO397_50k_CI_02165.mcs -print | head -n 1",
        "r");
      if (find_cmd == NULL) {
        sprintf(msg, "Could not open file search comand.\n");
        rtmSetErrorStatus(Model_M, msg);
        return;
      }

      fscanf(find_cmd,"%s",mcsFileName);
      if (pclose(find_cmd) < 0) {
        sprintf(msg, "Could not close file search comand.\n");
        rtmSetErrorStatus(Model_M, msg);
        return;
      }

      SG_PRINTF(DEBUG, "Found bitstream at: %s\n",mcsFileName);

#endif

#ifdef _MSC_BUILD

      if (sg_isModelInit()) {

#endif

        if ((mcs = fopen(mcsFileName, "r")) == NULL) {
          sprintf(msg, "Bitstream file not found at %s.\n", mcsFileName);
          rtmSetErrorStatus(Model_M, msg);
          SG_PRINTF(ERROR,msg);
          return;
        }

        bitstream = (uint32_t *) malloc(2192012*sizeof(uint32_t));
        fpgacode = (uint8_t *) malloc(2192012*sizeof(uint8_t));
        for (i = 0; i<2192012; i++) {
          fscanf(mcs,"%d\n",&bitstream[i]);
          fpgacode[i] = bitstream[i];
        }

        fclose(mcs);

        // Get Module ID's (PIC info)
        SG_PRINTF(INFO,"Getting module information.\n");
        ErrCode = (int32_t)sg_fpga_IO3xxGetModuleId(39750, &moduleId);
        if (ErrCode >= 0) {
          devname = moduleId.devname;
          moduleArchitecture = moduleId.moduleArchitecture;
          SG_PRINTF(DEBUG, "boardType: %d\n", 39750);
          SG_PRINTF(DEBUG, "ErrCode: %d\n", ErrCode);
          SG_PRINTF(DEBUG, "******************************************\n");
          SG_PRINTF(DEBUG, "moduleId->devname: %s\n", moduleId.devname);
          SG_PRINTF(DEBUG, "moduleId->vendorid: 0x%x\n", moduleId.vendorid);
          SG_PRINTF(DEBUG, "moduleId->subvendorid: 0x%x\n", moduleId.subvendorid);
          SG_PRINTF(DEBUG, "moduleId->deviceid: 0x%x\n", moduleId.deviceid);
          SG_PRINTF(DEBUG, "moduleId->subdeviceid: 0x%x\n", moduleId.subdeviceid);
          SG_PRINTF(DEBUG, "moduleId.moduleArchitecture: %d\n",
                    moduleId.moduleArchitecture);
        } else {
          sprintf(msg, "Setup block: board type unknown.");
          rtmSetErrorStatus(Model_M, msg);
          SG_PRINTF(ERROR,msg);
          return;
        }

        //support for different architecture:
        SG_PRINTF(INFO,"Running board specific programming file.\n");
        switch (moduleArchitecture)
        {
         case TEWS_TPMC:
          ErrCode = IO30x_programFPGA(devname, (int16_t) 12 , (int16_t) 0 ,
            (int32_t) 2, (int32_t) 3 , (int32_t) 0, (uint32_t) 2192012,
            bitstream, &moduleId);
          break;

         case TEWS_TXMC:
          ErrCode = IO31x_IO32x_programmFPGA(devname, (int16_t) 12 , (int16_t) 0
            , (int32_t) 2, (int32_t) 3 , (int32_t) 0, (uint32_t) 2192012,
            fpgacode, &moduleId, (uint32_t) 85);
          break;

         case ACROMAG_PMC:
          ErrCode = IO331_programmFPGA(devname, (int16_t) 12 , (int16_t) 0 ,
            (int32_t) 2, (int32_t) 3 , (uint32_t) 2192012, bitstream, &moduleId);
          break;

         case ACROMAG_XMC:
          if (39750 == 332) {
            ErrCode = IO332_programmFPGA(devname, (int16_t) 12 , (int16_t) 0 ,
              (int32_t) 2, (int32_t) 3 , (uint32_t) 2192012, bitstream,(uint32_t)
              1546170855, &moduleId);
          } else                       // IO333
          {
            ErrCode = IO333_programmFPGA(devname, (int16_t) 12 , (int16_t) 0 ,
              (int32_t) 2, (int32_t) 3 , (uint32_t) 2192012, bitstream,(uint32_t)
              1546170855, &moduleId);
          }
          break;

         case TEWS_MPCIE:
          ErrCode = IO39x_programmFPGA(devname, (int16_t) 12, (int16_t) 0 ,
            (int32_t) 2, (int32_t) 3, (uint32_t) 2192012, fpgacode, (uint32_t)
            85, &moduleId);
          break;

         default:
          sprintf(msg, "Setup block: module architecture incorrect.");
          rtmSetErrorStatus(Model_M, msg);

          //Free the Bitstream allocation
          SG_PRINTF(ERROR,msg);
          free(bitstream);
          free(fpgacode);
          return;
        }

        //Free the Bitstream allocation
        free(bitstream);
        free(fpgacode);

        //Handle any error states
        switch (ErrCode)
        {
         case NO_ERR:
          {
            //Nothing to do.
            break;
          }

         case BOARD_NOT_FOUND:
          {
            sprintf(msg, "Setup block %s: Board could not be found.\n",devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case EEPROM_ERROR:
          {
            sprintf(msg, "Setup block %s: Error updating board EEPROM.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case REPROG_ERROR:
          {
            sprintf(msg,
                    "Setup block %s: Error writing new bitstream to FPGA.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case FLASH_ERROR:
          {
            sprintf(msg, "Setup block %s: Bitstream flash storage error.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case BIST_ERROR:
          {
            sprintf(msg, "Setup block %s: Built in self test error.\n", devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case ICAP_RECONF_FAILED:
          {
            sprintf(msg,
                    "Setup block %s: ICAP Reconfiguration was not successful.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         case BOARD_TYPE_UNKNOWN:
          {
            sprintf(msg, "Setup block %s: The board type selected is unknown.\n",
                    devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }

         default:
          {
            sprintf(msg, "Setup block %s: An unknown error occurred.\n",devname);
            rtmSetErrorStatus(Model_M, msg);
            SG_PRINTF(ERROR,msg);
            return;
            break;
          }
        }

        if (1 == 2) {
          IO3xx_21_update(devname, 3, 0, 0, 0);
        } else if (1 == 3) {
          IO3xx_22_update(devname, 3, 0, 0, 0);
        }

#ifdef _MSC_BUILD

      }

#endif

    }

    /* Start for S-Function (scblock): '<S3>/S-Function' */

    /* S-Function Block: <S3>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(7)) == 0) {
        if ((i = rl32eDefScope(7,2)) != 0) {
          printf("Error creating scope 7\n");
        } else {
          rl32eAddSignal(7, rl32eGetSignalNo("Gain2"));
          rl32eSetScope(7, 4, 30000);
          rl32eSetScope(7, 5, 0);
          rl32eSetScope(7, 6, 1);
          rl32eSetScope(7, 0, 0);
          rl32eSetScope(7, 3, rl32eGetSignalNo("Gain2"));
          rl32eSetScope(7, 1, 0.0);
          rl32eSetScope(7, 2, 0);
          rl32eSetScope(7, 9, 0);
          rl32eSetTargetScope(7, 1, 2.0);
          rl32eSetTargetScope(7, 11, 0.0);
          rl32eSetTargetScope(7, 10, 0.0);
          xpceScopeAcqOK(7, &Model_DW.SFunction_IWORK.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(7);
      }
    }

    /* Start for S-Function (scblock): '<S4>/S-Function' */

    /* S-Function Block: <S4>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(6)) == 0) {
        if ((i = rl32eDefScope(6,2)) != 0) {
          printf("Error creating scope 6\n");
        } else {
          rl32eAddSignal(6, rl32eGetSignalNo("Gain3"));
          rl32eSetScope(6, 4, 251200);
          rl32eSetScope(6, 5, 0);
          rl32eSetScope(6, 6, 1);
          rl32eSetScope(6, 0, 0);
          rl32eSetScope(6, 3, rl32eGetSignalNo("Gain3"));
          rl32eSetScope(6, 1, 0.0);
          rl32eSetScope(6, 2, 0);
          rl32eSetScope(6, 9, 0);
          rl32eSetTargetScope(6, 1, 2.0);
          rl32eSetTargetScope(6, 11, 0.0);
          rl32eSetTargetScope(6, 10, 6.28);
          xpceScopeAcqOK(6, &Model_DW.SFunction_IWORK_k.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(6);
      }
    }

    /* Start for S-Function (scblock): '<S5>/S-Function' */

    /* S-Function Block: <S5>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(8)) == 0) {
        if ((i = rl32eDefScope(8,2)) != 0) {
          printf("Error creating scope 8\n");
        } else {
          rl32eAddSignal(8, rl32eGetSignalNo("Gain1"));
          rl32eSetScope(8, 4, 30000);
          rl32eSetScope(8, 5, 0);
          rl32eSetScope(8, 6, 1);
          rl32eSetScope(8, 0, 0);
          rl32eSetScope(8, 3, rl32eGetSignalNo("Gain1"));
          rl32eSetScope(8, 1, 0.0);
          rl32eSetScope(8, 2, 0);
          rl32eSetScope(8, 9, 0);
          rl32eSetTargetScope(8, 1, 2.0);
          rl32eSetTargetScope(8, 11, 0.0);
          rl32eSetTargetScope(8, 10, 0.0);
          xpceScopeAcqOK(8, &Model_DW.SFunction_IWORK_a.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(8);
      }
    }

    /* Start for S-Function (scblock): '<S6>/S-Function' */

    /* S-Function Block: <S6>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(9)) == 0) {
        if ((i = rl32eDefScope(9,2)) != 0) {
          printf("Error creating scope 9\n");
        } else {
          rl32eAddSignal(9, rl32eGetSignalNo("Gain"));
          rl32eSetScope(9, 4, 30000);
          rl32eSetScope(9, 5, 0);
          rl32eSetScope(9, 6, 1);
          rl32eSetScope(9, 0, 0);
          rl32eSetScope(9, 3, rl32eGetSignalNo("Gain"));
          rl32eSetScope(9, 1, 0.0);
          rl32eSetScope(9, 2, 0);
          rl32eSetScope(9, 9, 0);
          rl32eSetTargetScope(9, 1, 2.0);
          rl32eSetTargetScope(9, 11, 0.0);
          rl32eSetTargetScope(9, 10, 0.0);
          xpceScopeAcqOK(9, &Model_DW.SFunction_IWORK_n.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(9);
      }
    }

    /* Start for S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input' */
    /* Level2 S-Function Block: '<S7>/IO397 Analog Input' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scblock): '<S15>/S-Function' */

    /* S-Function Block: <S15>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(2)) == 0) {
        if ((i = rl32eDefScope(2,2)) != 0) {
          printf("Error creating scope 2\n");
        } else {
          rl32eAddSignal(2, rl32eGetSignalNo("Control/SinCos Decoder/Gain5"));
          rl32eSetScope(2, 4, 30000);
          rl32eSetScope(2, 5, 0);
          rl32eSetScope(2, 6, 1);
          rl32eSetScope(2, 0, 0);
          rl32eSetScope(2, 3, rl32eGetSignalNo("Control/SinCos Decoder/Gain5"));
          rl32eSetScope(2, 1, 0.0);
          rl32eSetScope(2, 2, 0);
          rl32eSetScope(2, 9, 0);
          rl32eSetTargetScope(2, 1, 2.0);
          rl32eSetTargetScope(2, 11, 0.0);
          rl32eSetTargetScope(2, 10, 0.0);
          xpceScopeAcqOK(2, &Model_DW.SFunction_IWORK_no.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(2);
      }
    }

    /* Start for S-Function (scblock): '<S16>/S-Function' */

    /* S-Function Block: <S16>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(3)) == 0) {
        if ((i = rl32eDefScope(3,2)) != 0) {
          printf("Error creating scope 3\n");
        } else {
          rl32eAddSignal(3, rl32eGetSignalNo("Control/SinCos Decoder/Gain8"));
          rl32eSetScope(3, 4, 30000);
          rl32eSetScope(3, 5, 0);
          rl32eSetScope(3, 6, 1);
          rl32eSetScope(3, 0, 0);
          rl32eSetScope(3, 3, rl32eGetSignalNo("Control/SinCos Decoder/Gain8"));
          rl32eSetScope(3, 1, 0.0);
          rl32eSetScope(3, 2, 0);
          rl32eSetScope(3, 9, 0);
          rl32eSetTargetScope(3, 1, 2.0);
          rl32eSetTargetScope(3, 11, 0.0);
          rl32eSetTargetScope(3, 10, 0.0);
          xpceScopeAcqOK(3, &Model_DW.SFunction_IWORK_ax.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(3);
      }
    }

    /* Start for S-Function (scblock): '<S17>/S-Function' */

    /* S-Function Block: <S17>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(1)) == 0) {
        if ((i = rl32eDefScope(1,2)) != 0) {
          printf("Error creating scope 1\n");
        } else {
          rl32eAddSignal(1, rl32eGetSignalNo("Control/SinCos Decoder/Gain1/s1"));
          rl32eAddSignal(1, rl32eGetSignalNo("Control/SinCos Decoder/Gain1/s2"));
          rl32eSetScope(1, 4, 30000);
          rl32eSetScope(1, 5, 0);
          rl32eSetScope(1, 6, 1);
          rl32eSetScope(1, 0, 0);
          rl32eSetScope(1, 3, rl32eGetSignalNo("Control/SinCos Decoder/Gain1/s1"));
          rl32eSetScope(1, 1, 0.0);
          rl32eSetScope(1, 2, 0);
          rl32eSetScope(1, 9, 0);
          rl32eSetTargetScope(1, 1, 2.0);
          rl32eSetTargetScope(1, 11, 0.0);
          rl32eSetTargetScope(1, 10, 0.0);
          xpceScopeAcqOK(1, &Model_DW.SFunction_IWORK_g.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(1);
      }
    }

    /* Start for S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input1' */
    /* Level2 S-Function Block: '<S7>/IO397 Analog Input1' (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scblock): '<S23>/S-Function' */

    /* S-Function Block: <S23>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(4)) == 0) {
        if ((i = rl32eDefScope(4,2)) != 0) {
          printf("Error creating scope 4\n");
        } else {
          rl32eAddSignal(4, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain4/s1"));
          rl32eAddSignal(4, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain4/s2"));
          rl32eSetScope(4, 4, 62800);
          rl32eSetScope(4, 5, 0);
          rl32eSetScope(4, 6, 1);
          rl32eSetScope(4, 0, 0);
          rl32eSetScope(4, 3, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain4/s1"));
          rl32eSetScope(4, 1, 0.0);
          rl32eSetScope(4, 2, 0);
          rl32eSetScope(4, 9, 0);
          rl32eSetTargetScope(4, 1, 2.0);
          rl32eSetTargetScope(4, 11, -150.0);
          rl32eSetTargetScope(4, 10, 150.0);
          xpceScopeAcqOK(4, &Model_DW.SFunction_IWORK_p.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(4);
      }
    }

    /* Start for S-Function (scblock): '<S24>/S-Function' */

    /* S-Function Block: <S24>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(5)) == 0) {
        if ((i = rl32eDefScope(5,2)) != 0) {
          printf("Error creating scope 5\n");
        } else {
          rl32eAddSignal(5, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain3/s1"));
          rl32eAddSignal(5, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain3/s2"));
          rl32eSetScope(5, 4, 62800);
          rl32eSetScope(5, 5, 0);
          rl32eSetScope(5, 6, 1);
          rl32eSetScope(5, 0, 0);
          rl32eSetScope(5, 3, rl32eGetSignalNo(
            "Control/Waveform Generator/Gain3/s1"));
          rl32eSetScope(5, 1, 0.0);
          rl32eSetScope(5, 2, 0);
          rl32eSetScope(5, 9, 0);
          rl32eSetTargetScope(5, 1, 2.0);
          rl32eSetTargetScope(5, 11, -30.0);
          rl32eSetTargetScope(5, 10, 60.0);
          xpceScopeAcqOK(5, &Model_DW.SFunction_IWORK_m.AcquireOK);
        }
      }

      if (i) {
        rl32eRestartAcquisition(5);
      }
    }

    /* Start for Atomic SubSystem: '<S13>/Walking waveform1' */

    /* Start for Lookup_n-D: '<S25>/clamp2' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet;
      TWork_start->m_dimSizes = (const uint32_T *) &Model_P.clamp2_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.clamp2_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda;
      TWork_start->m_maxIndex = (const uint32_T *) &Model_P.clamp2_maxIndex;
      bpDataSet[0] = (void *) Model_P.clamp2_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA;
      rt_SplWk->m_yyB = &Model_DW.m_yyB;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2;
      rt_SplWk->m_up = &Model_DW.m_up[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2[0];
      rt_SplWk->m_numYWorkElts = Model_P.clamp2_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.55 tot 0.95 shear1' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_n[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_m;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u55tot095shear1_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u55tot095shear1_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_l;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_m;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u55tot095shear1_maxIndex;
      bpDataSet[0] = (void *) Model_P.u55tot095shear1_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_d[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_n[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_i;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_f;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_h;
      rt_SplWk->m_up = &Model_DW.m_up_g[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_d[0];
      rt_SplWk->m_numYWorkElts = Model_P.u55tot095shear1_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_e;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_n[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.05 tot 0.45 shear1' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_l[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_i;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u05tot045shear1_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u05tot045shear1_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_b;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_k;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u05tot045shear1_maxIndex;
      bpDataSet[0] = (void *) Model_P.u05tot045shear1_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_o[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_l[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_j;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_c;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_e;
      rt_SplWk->m_up = &Model_DW.m_up_a[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_i[0];
      rt_SplWk->m_numYWorkElts = Model_P.u05tot045shear1_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_eq;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_j[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.55 tot 0.95 shear2' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_p[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_b;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u55tot095shear2_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u55tot095shear2_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_p;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_c;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u55tot095shear2_maxIndex;
      bpDataSet[0] = (void *) Model_P.u55tot095shear2_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_f[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_p[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_g;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_a;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_i;
      rt_SplWk->m_up = &Model_DW.m_up_e[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_n[0];
      rt_SplWk->m_numYWorkElts = Model_P.u55tot095shear2_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_c;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_m[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.05 tot 0.45 shear2' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_lm[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_d;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u05tot045shear2_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u05tot045shear2_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_p2;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_j;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u05tot045shear2_maxIndex;
      bpDataSet[0] = (void *) Model_P.u05tot045shear2_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_g[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_lm[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_o;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_h;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_k;
      rt_SplWk->m_up = &Model_DW.m_up_p[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_l[0];
      rt_SplWk->m_numYWorkElts = Model_P.u05tot045shear2_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_eo;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_h[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.55 tot 0.95 clamp1' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_o[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_j;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u55tot095clamp1_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u55tot095clamp1_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_bj;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_ja;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u55tot095clamp1_maxIndex;
      bpDataSet[0] = (void *) Model_P.u55tot095clamp1_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_b[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_o[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_e;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_p;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_p;
      rt_SplWk->m_up = &Model_DW.m_up_pq[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_b[0];
      rt_SplWk->m_numYWorkElts = Model_P.u55tot095clamp1_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_n;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_c[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.05 tot 0.45 clamp1' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_lj[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_c;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u05tot045clamp1_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u05tot045clamp1_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_n;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_g;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u05tot045clamp1_maxIndex;
      bpDataSet[0] = (void *) Model_P.u05tot045clamp1_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_h[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_lj[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_c;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_c1;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_d;
      rt_SplWk->m_up = &Model_DW.m_up_l[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_n1[0];
      rt_SplWk->m_numYWorkElts = Model_P.u05tot045clamp1_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_i;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_o[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0 tot 0.05' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_d[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_p;
      TWork_start->m_dimSizes = (const uint32_T *) &Model_P.utot005_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.utot005_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_h;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_j3;
      TWork_start->m_maxIndex = (const uint32_T *) &Model_P.utot005_maxIndex;
      bpDataSet[0] = (void *) Model_P.utot005_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_n[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_d[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_cd;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_d;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_b;
      rt_SplWk->m_up = &Model_DW.m_up_k[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_k[0];
      rt_SplWk->m_numYWorkElts = Model_P.utot005_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_np;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_g[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.95 tot 1' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_l1[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_n;
      TWork_start->m_dimSizes = (const uint32_T *) &Model_P.u95tot1_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u95tot1_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_c;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_kc;
      TWork_start->m_maxIndex = (const uint32_T *) &Model_P.u95tot1_maxIndex;
      bpDataSet[0] = (void *) Model_P.u95tot1_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_e[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_l1[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_a;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_g;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_pk;
      rt_SplWk->m_up = &Model_DW.m_up_af[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_a[0];
      rt_SplWk->m_numYWorkElts = Model_P.u95tot1_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_k;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_oj[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.55 tot 0.95 clamp2' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_c[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_a;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u55tot095clamp2_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u55tot095clamp2_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_d;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_my;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u55tot095clamp2_maxIndex;
      bpDataSet[0] = (void *) Model_P.u55tot095clamp2_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_ee[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_c[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_n;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_gl;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_e0;
      rt_SplWk->m_up = &Model_DW.m_up_m[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_m[0];
      rt_SplWk->m_numYWorkElts = Model_P.u55tot095clamp2_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_a;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_f[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* Start for Lookup_n-D: '<S25>/0.05 tot 0.45 clamp2' */
    {
      rt_LUTnWork *TWork_start = (rt_LUTnWork *) &Model_DW.TWork_i[0];
      void **bpDataSet = (void **) &Model_DW.m_bpDataSet_k;
      TWork_start->m_dimSizes = (const uint32_T *)
        &Model_P.u05tot045clamp2_dimSizes;
      TWork_start->m_tableData = (void *) Model_P.u05tot045clamp2_tableData;
      TWork_start->m_bpDataSet = bpDataSet;
      TWork_start->m_bpIndex = &Model_DW.m_bpIndex_lh;
      TWork_start->m_bpLambda = &Model_DW.m_bpLambda_ks;
      TWork_start->m_maxIndex = (const uint32_T *)
        &Model_P.u05tot045clamp2_maxIndex;
      bpDataSet[0] = (void *) Model_P.u05tot045clamp2_bp01Data;
    }

    {
      const real_T **bpDataSet;
      const real_T *xp, *yp;
      real_T *dp;
      uint32_T len;
      const rt_LUTnWork *TWork_interp;
      rt_LUTSplineWork *rt_SplWk = (rt_LUTSplineWork*)&Model_DW.SWork_bg[0];
      rt_SplWk->m_TWork = (rt_LUTnWork*)&Model_DW.TWork_i[0];
      rt_SplWk->m_yyA = &Model_DW.m_yyA_am;
      rt_SplWk->m_yyB = &Model_DW.m_yyB_e;
      rt_SplWk->m_yy2 = &Model_DW.m_yy2_dw;
      rt_SplWk->m_up = &Model_DW.m_up_f[0];
      rt_SplWk->m_y2 = &Model_DW.m_y2_aj[0];
      rt_SplWk->m_numYWorkElts = Model_P.u05tot045clamp2_numYWorkElts;
      rt_SplWk->m_reCalc = &Model_DW.reCalcSecDerivFirstDimCoeffs_o;
      rt_SplWk->m_preBp0AndTable = &Model_DW.prevBp0AndTableData_p[0];
      *rt_SplWk->m_reCalc = 1;

      /* cache table data and first breakpoint data */
      TWork_interp = (const rt_LUTnWork *)rt_SplWk->m_TWork;
      bpDataSet = (const real_T **) TWork_interp->m_bpDataSet;
      xp = bpDataSet[0U];
      len = TWork_interp->m_maxIndex[0U] + 1U;
      dp = (real_T *) rt_SplWk->m_preBp0AndTable;
      yp = (real_T *) TWork_interp->m_tableData;
      (void) memcpy(dp, xp,
                    len * sizeof(real_T));
      dp = &(dp[len]);

      /* save the table data */
      (void) memcpy(dp, yp,
                    len * rt_SplWk->m_numYWorkElts[0U] * sizeof(real_T));
    }

    /* End of Start for SubSystem: '<S13>/Walking waveform1' */

    /* Start for S-Function (sg_fpga_IO397_da): '<S7>/IO397 Analog Output1' */
    /* Level2 S-Function Block: '<S7>/IO397 Analog Output1' (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Model_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }
  }

  Model_PrevZCX.HitCrossingNeg_Input_ZCE = UNINITIALIZED_ZCSIG;
  Model_PrevZCX.HitCrossingPos_Input_ZCE = UNINITIALIZED_ZCSIG;
  Model_PrevZCX.NegCounter_Trig_ZCE = POS_ZCSIG;
  Model_PrevZCX.PosCounter_Trig_ZCE = POS_ZCSIG;

  /* InitializeConditions for Delay: '<S11>/Delay' */
  Model_DW.Delay_DSTATE = Model_P.Delay_InitialCondition;

  /* InitializeConditions for Memory: '<S12>/Memory' */
  Model_DW.Memory_PreviousInput = Model_P.Memory_InitialCondition;

  /* InitializeConditions for Integrator: '<S22>/Integrator' */
  Model_X.Integrator_CSTATE = Model_P.Integrator_IC;

  /* InitializeConditions for Derivative: '<S22>/Derivative' */
  Model_DW.TimeStampA = (rtInf);
  Model_DW.TimeStampB = (rtInf);

  /* SystemInitialize for Triggered SubSystem: '<S18>/NegCounter' */
  /* InitializeConditions for UnitDelay: '<S20>/Unit Delay' */
  Model_DW.UnitDelay_DSTATE_o = Model_P.UnitDelay_InitialCondition;

  /* SystemInitialize for Outport: '<S20>/Counts' */
  Model_B.Sum_dz = Model_P.Counts_Y0;

  /* End of SystemInitialize for SubSystem: '<S18>/NegCounter' */

  /* SystemInitialize for Triggered SubSystem: '<S18>/PosCounter' */
  /* InitializeConditions for UnitDelay: '<S21>/Unit Delay' */
  Model_DW.UnitDelay_DSTATE = Model_P.UnitDelay_InitialCondition_n;

  /* SystemInitialize for Outport: '<S21>/Counts' */
  Model_B.Sum_a = Model_P.Counts_Y0_h;

  /* End of SystemInitialize for SubSystem: '<S18>/PosCounter' */
}

/* Model terminate function */
void Model_terminate(void)
{
  /* Terminate for S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input' */
  /* Level2 S-Function Block: '<S7>/IO397 Analog Input' (sg_fpga_IO397_ad) */
  {
    SimStruct *rts = Model_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_fpga_IO397_ad): '<S7>/IO397 Analog Input1' */
  /* Level2 S-Function Block: '<S7>/IO397 Analog Input1' (sg_fpga_IO397_ad) */
  {
    SimStruct *rts = Model_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_fpga_IO397_da): '<S7>/IO397 Analog Output1' */
  /* Level2 S-Function Block: '<S7>/IO397 Analog Output1' (sg_fpga_IO397_da) */
  {
    SimStruct *rts = Model_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* user code (Terminate function Trailer) */
  {
    volatile io3xx_pull *ptrIO31x_pull;
    volatile io3xx_2x *ptrio3xx_2x;
    uint16_t moduleArchitecture;
    sg_fpga_io3xxModuleIdT moduleId;

#ifdef _MSC_BUILD

    if (!sg_isModelInit()) {

#endif

      // Get Module ID's (PIC info)
      sg_fpga_IO3xxGetModuleId(39750, &moduleId);
      moduleArchitecture = moduleId.moduleArchitecture;
      SG_PRINTF(DEBUG, "moduleArchitecture %d\n",moduleArchitecture);
      if (moduleArchitecture == TEWS_TXMC) {
        //get pointer to io31x_pull
        ptrIO31x_pull= (io3xx_pull *)((uintptr_t)io3xxGetAddressSgLib((int32_t)
          1, SG_FPGA_IO3XX_BAR2) + IO3xx_PULL_BASE);

        //disable pull resistors
        ptrIO31x_pull->enable = 0x0;   //disable
      }

      // pull down and disable dio's
      if (1 >= 2) {
        ptrio3xx_2x = (io3xx_2x *)((uintptr_t)io3xxGetAddressSgLib((int32_t) 1,
          SG_FPGA_IO3XX_BAR2) + IO3xx_2x_BASE);
        ptrio3xx_2x->pull = 0xffffffff;//pull down
        ptrio3xx_2x->dir = 0x0;        //input
        ptrio3xx_2x->update = 0x1;
        sg_wait_s(SG_FPGA_WAIT_TIME_100us);
        ptrio3xx_2x->update = 0x0;
        sg_wait_s(SG_FPGA_WAIT_TIME_1ms);

#if DEBUGGING

        //for Debugging Output Port Register of IO-Expander
        sg_wait_s(SG_FPGA_WAIT_TIME_100ms);
        SG_PRINTF(INFO, "last configuration from mdl start\n");
        SG_PRINTF(INFO, "rxData of Expander1: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander1);
        SG_PRINTF(INFO, "rxData of Expander2: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander2);
        SG_PRINTF(INFO, "rxData of Expander3: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander3);
        SG_PRINTF(INFO, "rxData of Expander4: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander4);

#endif

      }

#ifdef _MSC_BUILD

    }

#endif

  }

  {
    volatile io3xx_pull *ptrIO31x_pull;
    volatile io3xx_2x *ptrio3xx_2x;
    uint16_t moduleArchitecture;
    sg_fpga_io3xxModuleIdT moduleId;

#ifdef _MSC_BUILD

    if (!sg_isModelInit()) {

#endif

      // Get Module ID's (PIC info)
      sg_fpga_IO3xxGetModuleId(39750, &moduleId);
      moduleArchitecture = moduleId.moduleArchitecture;
      SG_PRINTF(DEBUG, "moduleArchitecture %d\n",moduleArchitecture);
      if (moduleArchitecture == TEWS_TXMC) {
        //get pointer to io31x_pull
        ptrIO31x_pull= (io3xx_pull *)((uintptr_t)io3xxGetAddressSgLib((int32_t)
          3, SG_FPGA_IO3XX_BAR2) + IO3xx_PULL_BASE);

        //disable pull resistors
        ptrIO31x_pull->enable = 0x0;   //disable
      }

      // pull down and disable dio's
      if (1 >= 2) {
        ptrio3xx_2x = (io3xx_2x *)((uintptr_t)io3xxGetAddressSgLib((int32_t) 3,
          SG_FPGA_IO3XX_BAR2) + IO3xx_2x_BASE);
        ptrio3xx_2x->pull = 0xffffffff;//pull down
        ptrio3xx_2x->dir = 0x0;        //input
        ptrio3xx_2x->update = 0x1;
        sg_wait_s(SG_FPGA_WAIT_TIME_100us);
        ptrio3xx_2x->update = 0x0;
        sg_wait_s(SG_FPGA_WAIT_TIME_1ms);

#if DEBUGGING

        //for Debugging Output Port Register of IO-Expander
        sg_wait_s(SG_FPGA_WAIT_TIME_100ms);
        SG_PRINTF(INFO, "last configuration from mdl start\n");
        SG_PRINTF(INFO, "rxData of Expander1: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander1);
        SG_PRINTF(INFO, "rxData of Expander2: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander2);
        SG_PRINTF(INFO, "rxData of Expander3: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander3);
        SG_PRINTF(INFO, "rxData of Expander4: 0x%X\n",
                  ptrio3xx_2x->rxDataExpander4);

#endif

      }

#ifdef _MSC_BUILD

    }

#endif

  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  Model_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Model_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Model_initialize();
}

void MdlTerminate(void)
{
  Model_terminate();
}

/* Registration function */
RT_MODEL_Model_T *Model(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Model_M, 0,
                sizeof(RT_MODEL_Model_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Model_M->solverInfo, &Model_M->Timing.simTimeStep);
    rtsiSetTPtr(&Model_M->solverInfo, &rtmGetTPtr(Model_M));
    rtsiSetStepSizePtr(&Model_M->solverInfo, &Model_M->Timing.stepSize0);
    rtsiSetdXPtr(&Model_M->solverInfo, &Model_M->derivs);
    rtsiSetContStatesPtr(&Model_M->solverInfo, (real_T **) &Model_M->contStates);
    rtsiSetNumContStatesPtr(&Model_M->solverInfo, &Model_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Model_M->solverInfo,
      &Model_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Model_M->solverInfo,
      &Model_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Model_M->solverInfo,
      &Model_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Model_M->solverInfo, (&rtmGetErrorStatus(Model_M)));
    rtsiSetRTModelPtr(&Model_M->solverInfo, Model_M);
  }

  rtsiSetSimTimeStep(&Model_M->solverInfo, MAJOR_TIME_STEP);
  Model_M->intgData.f[0] = Model_M->odeF[0];
  Model_M->contStates = ((real_T *) &Model_X);
  rtsiSetSolverData(&Model_M->solverInfo, (void *)&Model_M->intgData);
  rtsiSetSolverName(&Model_M->solverInfo,"ode1");
  Model_M->solverInfoPtr = (&Model_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Model_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    Model_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Model_M->Timing.sampleTimes = (&Model_M->Timing.sampleTimesArray[0]);
    Model_M->Timing.offsetTimes = (&Model_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Model_M->Timing.sampleTimes[0] = (0.0);
    Model_M->Timing.sampleTimes[1] = (0.0001);

    /* task offsets */
    Model_M->Timing.offsetTimes[0] = (0.0);
    Model_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(Model_M, &Model_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Model_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    Model_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Model_M, 5.1000000000000005);
  Model_M->Timing.stepSize0 = 0.0001;
  Model_M->Timing.stepSize1 = 0.0001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Model_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Model_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Model_M->rtwLogInfo, (NULL));
    rtliSetLogT(Model_M->rtwLogInfo, "tout");
    rtliSetLogX(Model_M->rtwLogInfo, "");
    rtliSetLogXFinal(Model_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Model_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Model_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(Model_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Model_M->rtwLogInfo, 1);
    rtliSetLogY(Model_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Model_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Model_M->rtwLogInfo, (NULL));
  }

  Model_M->solverInfoPtr = (&Model_M->solverInfo);
  Model_M->Timing.stepSize = (0.0001);
  rtsiSetFixedStepSize(&Model_M->solverInfo, 0.0001);
  rtsiSetSolverMode(&Model_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Model_M->blockIO = ((void *) &Model_B);
  (void) memset(((void *) &Model_B), 0,
                sizeof(B_Model_T));

  /* parameters */
  Model_M->defaultParam = ((real_T *)&Model_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &Model_X;
    Model_M->contStates = (x);
    (void) memset((void *)&Model_X, 0,
                  sizeof(X_Model_T));
  }

  /* states (dwork) */
  Model_M->dwork = ((void *) &Model_DW);
  (void) memset((void *)&Model_DW, 0,
                sizeof(DW_Model_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  Model_InitializeDataMapInfo();

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &Model_M->NonInlinedSFcns.sfcnInfo;
    Model_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(Model_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &Model_M->Sizes.numSampTimes);
    Model_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(Model_M)[0]);
    Model_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr(Model_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,Model_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(Model_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(Model_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(Model_M));
    rtssSetStepSizePtr(sfcnInfo, &Model_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(Model_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &Model_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &Model_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &Model_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &Model_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo, &Model_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &Model_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &Model_M->solverInfoPtr);
  }

  Model_M->Sizes.numSFcns = (3);

  /* register each child */
  {
    (void) memset((void *)&Model_M->NonInlinedSFcns.childSFunctions[0], 0,
                  3*sizeof(SimStruct));
    Model_M->childSfunctions = (&Model_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    Model_M->childSfunctions[0] = (&Model_M->NonInlinedSFcns.childSFunctions[0]);
    Model_M->childSfunctions[1] = (&Model_M->NonInlinedSFcns.childSFunctions[1]);
    Model_M->childSfunctions[2] = (&Model_M->NonInlinedSFcns.childSFunctions[2]);

    /* Level2 S-Function Block: Model/<S7>/IO397 Analog Input (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = Model_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = Model_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = Model_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Model_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Model_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Model_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Model_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Model_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Model_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Model_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &Model_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Model_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 4);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Model_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Model_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &Model_B.IO397AnalogInput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &Model_B.IO397AnalogInput_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *) &Model_B.IO397AnalogInput_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *) &Model_B.IO397AnalogInput_o4));
        }
      }

      /* path info */
      ssSetModelName(rts, "IO397 Analog Input");
      ssSetPath(rts, "Model/Signals/IO397 Analog Input");
      ssSetRTModel(rts,Model_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Model_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Model_P.IO397AnalogInput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)Model_P.IO397AnalogInput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)Model_P.IO397AnalogInput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)Model_P.IO397AnalogInput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)Model_P.IO397AnalogInput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)Model_P.IO397AnalogInput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)Model_P.IO397AnalogInput_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &Model_DW.IO397AnalogInput_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Model_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Model_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &Model_DW.IO397AnalogInput_PWORK[0]);
      }

      /* registration */
      sg_fpga_IO397_ad(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Model/<S7>/IO397 Analog Input1 (sg_fpga_IO397_ad) */
    {
      SimStruct *rts = Model_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = Model_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = Model_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = Model_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Model_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Model_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Model_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Model_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Model_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Model_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Model_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &Model_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Model_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Model_M->NonInlinedSFcns.Sfcn1.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Model_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &Model_B.IO397AnalogInput1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &Model_B.IO397AnalogInput1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "IO397 Analog Input1");
      ssSetPath(rts, "Model/Signals/IO397 Analog Input1");
      ssSetRTModel(rts,Model_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Model_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Model_P.IO397AnalogInput1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)Model_P.IO397AnalogInput1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)Model_P.IO397AnalogInput1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)Model_P.IO397AnalogInput1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)Model_P.IO397AnalogInput1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)Model_P.IO397AnalogInput1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)Model_P.IO397AnalogInput1_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **) &Model_DW.IO397AnalogInput1_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Model_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Model_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &Model_DW.IO397AnalogInput1_PWORK[0]);
      }

      /* registration */
      sg_fpga_IO397_ad(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Model/<S7>/IO397 Analog Output1 (sg_fpga_IO397_da) */
    {
      SimStruct *rts = Model_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = Model_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = Model_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = Model_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Model_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Model_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Model_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Model_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Model_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Model_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Model_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &Model_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 4);
        ssSetPortInfoForInputs(rts,
          &Model_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Model_M->NonInlinedSFcns.Sfcn2.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &Model_M->NonInlinedSFcns.Sfcn2.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &Model_B.Gain7_j[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &Model_B.Gain7_j[1]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &Model_B.Gain7_j[2]);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3, &Model_B.Gain7_j[3]);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidth(rts, 3, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "IO397 Analog Output1");
      ssSetPath(rts, "Model/Signals/IO397 Analog Output1");
      ssSetRTModel(rts,Model_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Model_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Model_P.IO397AnalogOutput1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)Model_P.IO397AnalogOutput1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)Model_P.IO397AnalogOutput1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)Model_P.IO397AnalogOutput1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)Model_P.IO397AnalogOutput1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)Model_P.IO397AnalogOutput1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)Model_P.IO397AnalogOutput1_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)Model_P.IO397AnalogOutput1_P8_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &Model_DW.IO397AnalogOutput1_IWORK);
      ssSetPWork(rts, (void **) &Model_DW.IO397AnalogOutput1_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Model_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Model_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &Model_DW.IO397AnalogOutput1_IWORK);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &Model_DW.IO397AnalogOutput1_PWORK[0]);
      }

      /* registration */
      sg_fpga_IO397_da(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
    }
  }

  /* Initialize Sizes */
  Model_M->Sizes.numContStates = (1);  /* Number of continuous states */
  Model_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  Model_M->Sizes.numY = (0);           /* Number of model outputs */
  Model_M->Sizes.numU = (0);           /* Number of model inputs */
  Model_M->Sizes.sysDirFeedThru = (0); /* The model is not direct feedthrough */
  Model_M->Sizes.numSampTimes = (2);   /* Number of sample times */
  Model_M->Sizes.numBlocks = (165);    /* Number of blocks */
  Model_M->Sizes.numBlockIO = (119);   /* Number of block outputs */
  Model_M->Sizes.numBlockPrms = (51359);/* Sum of parameter "widths" */
  return Model_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
