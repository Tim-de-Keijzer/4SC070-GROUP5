/*
 * Model_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Model".
 *
 * Model version              : 1.779
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Jun 23 10:49:18 2023
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "Model_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "Model.h"
#include "Model_capi.h"
#include "Model_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 0, TARGET_STRING("Gain"),
    TARGET_STRING("Error"), 0, 0, 0, 0, 0 },

  { 1, 0, TARGET_STRING("Gain1"),
    TARGET_STRING("Velocity"), 0, 0, 0, 0, 1 },

  { 2, 0, TARGET_STRING("Gain2"),
    TARGET_STRING("Position"), 0, 0, 0, 0, 1 },

  { 3, 0, TARGET_STRING("Gain3"),
    TARGET_STRING("CommAngle"), 0, 0, 0, 0, 0 },

  { 4, 0, TARGET_STRING("Gain4"),
    TARGET_STRING("ClampAnl"), 0, 0, 1, 0, 0 },

  { 5, 0, TARGET_STRING("Gain5"),
    TARGET_STRING("ShearAnl"), 0, 0, 1, 0, 0 },

  { 6, 0, TARGET_STRING("Control/Gain1"),
    TARGET_STRING("reference"), 0, 0, 0, 0, 0 },

  { 7, 0, TARGET_STRING("Control/Add1"),
    TARGET_STRING("error"), 0, 0, 0, 0, 0 },

  { 8, 0, TARGET_STRING("Control/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 9, 0, TARGET_STRING("Signals/IO397 Analog Input/p1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 10, 0, TARGET_STRING("Signals/IO397 Analog Input/p2"),
    TARGET_STRING(""), 1, 0, 0, 0, 1 },

  { 11, 0, TARGET_STRING("Signals/IO397 Analog Input/p3"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 12, 0, TARGET_STRING("Signals/IO397 Analog Input/p4"),
    TARGET_STRING(""), 3, 0, 0, 0, 1 },

  { 13, 0, TARGET_STRING("Signals/IO397 Analog Input1/p1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 14, 0, TARGET_STRING("Signals/IO397 Analog Input1/p2"),
    TARGET_STRING(""), 1, 0, 0, 0, 1 },

  { 15, 0, TARGET_STRING("Control/Repeating Sequence/Clock"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 16, 0, TARGET_STRING("Control/Repeating Sequence/Output"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 17, 0, TARGET_STRING("Control/Repeating Sequence/Look-Up Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 18, 0, TARGET_STRING("Control/Repeating Sequence/Math Function"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 19, 0, TARGET_STRING("Control/Repeating Sequence/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 20, 0, TARGET_STRING("Control/Repeating Sequence1/Clock"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 21, 0, TARGET_STRING("Control/Repeating Sequence1/Output"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 22, 0, TARGET_STRING("Control/Repeating Sequence1/Look-Up Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 23, 0, TARGET_STRING("Control/Repeating Sequence1/Math Function"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 24, 0, TARGET_STRING("Control/Repeating Sequence1/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 25, 0, TARGET_STRING("Control/Repeating Sequence2/Clock"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 26, 0, TARGET_STRING("Control/Repeating Sequence2/Output"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 27, 0, TARGET_STRING("Control/Repeating Sequence2/Look-Up Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 28, 0, TARGET_STRING("Control/Repeating Sequence2/Math Function"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 29, 0, TARGET_STRING("Control/Repeating Sequence2/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 30, 1, TARGET_STRING("Control/SinCos Decoder/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 31, 1, TARGET_STRING("Control/SinCos Decoder/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 0, 0, 0, 1 },

  { 32, 0, TARGET_STRING("Control/SinCos Decoder/Gain1"),
    TARGET_STRING("encRef"), 0, 0, 1, 0, 1 },

  { 33, 0, TARGET_STRING("Control/SinCos Decoder/Gain10"),
    TARGET_STRING("encCosUnc"), 0, 0, 0, 0, 1 },

  { 34, 0, TARGET_STRING("Control/SinCos Decoder/Gain11"),
    TARGET_STRING("idealPos"), 0, 0, 0, 0, 0 },

  { 35, 0, TARGET_STRING("Control/SinCos Decoder/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 36, 0, TARGET_STRING("Control/SinCos Decoder/Gain3"),
    TARGET_STRING("encCount"), 0, 0, 0, 0, 1 },

  { 37, 0, TARGET_STRING("Control/SinCos Decoder/Gain4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 38, 0, TARGET_STRING("Control/SinCos Decoder/Gain5"),
    TARGET_STRING("encSinCor"), 0, 0, 0, 0, 1 },

  { 39, 0, TARGET_STRING("Control/SinCos Decoder/Gain6"),
    TARGET_STRING("encInt"), 0, 0, 0, 0, 1 },

  { 40, 0, TARGET_STRING("Control/SinCos Decoder/Gain7"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 41, 0, TARGET_STRING("Control/SinCos Decoder/Gain8"),
    TARGET_STRING("encCosCor"), 0, 0, 0, 0, 1 },

  { 42, 0, TARGET_STRING("Control/SinCos Decoder/Gain9"),
    TARGET_STRING("encSinUnc"), 0, 0, 0, 0, 1 },

  { 43, 0, TARGET_STRING("Control/SinCos Decoder/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 44, 0, TARGET_STRING("Control/SinCos Decoder/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 45, 0, TARGET_STRING("Control/SinCos Decoder/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 46, 0, TARGET_STRING("Control/SinCos Decoder/Sum of Elements"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 47, 0, TARGET_STRING("Control/SinCos Decoder/Sum of Elements1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 48, 0, TARGET_STRING("Control/SinCos Decoder/Sum1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 49, 0, TARGET_STRING("Control/SinCos Decoder/atan2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 50, 0, TARGET_STRING("Control/SinCos Decoder/Delay"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 51, 0, TARGET_STRING("Control/Subsystem/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 52, 0, TARGET_STRING("Control/Subsystem/Sum"),
    TARGET_STRING("index_counter"), 0, 0, 0, 0, 1 },

  { 53, 0, TARGET_STRING("Control/Subsystem/Direct Lookup Table (n-D)"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 54, 0, TARGET_STRING("Control/Waveform Generator/Gain1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 55, 0, TARGET_STRING("Control/Waveform Generator/Gain2"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 56, 0, TARGET_STRING("Control/Waveform Generator/Gain3"),
    TARGET_STRING("ClampTru"), 0, 0, 1, 0, 0 },

  { 57, 0, TARGET_STRING("Control/Waveform Generator/Gain4"),
    TARGET_STRING("ShearTru"), 0, 0, 1, 0, 0 },

  { 58, 0, TARGET_STRING("Control/Waveform Generator/Gain7"),
    TARGET_STRING(""), 0, 0, 2, 0, 0 },

  { 59, 0, TARGET_STRING("Control/Waveform Generator/Math Function"),
    TARGET_STRING("alpha_mod"), 0, 0, 0, 0, 0 },

  { 60, 0, TARGET_STRING("Control/Waveform Generator/Saturation"),
    TARGET_STRING(""), 0, 0, 2, 0, 0 },

  { 61, 0, TARGET_STRING("Control/Waveform Generator/Sum"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 62, 0, TARGET_STRING("Control/Waveform Generator/Sum1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 63, 0, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/Hit  Crossing Neg"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 64, 0, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/Hit  Crossing Pos"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 65, 0, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/Logical Operator Neg"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 66, 0, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/Logical Operator Pos"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 67, 0, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/Add2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 68, 0, TARGET_STRING("Control/Waveform Generator/Scaling/Derivative"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 69, 4, TARGET_STRING("Control/Waveform Generator/Scaling/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 70, 5, TARGET_STRING("Control/Waveform Generator/Scaling/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 71, 0, TARGET_STRING("Control/Waveform Generator/Scaling/Gain3"),
    TARGET_STRING("alpha"), 0, 0, 0, 0, 0 },

  { 72, 0, TARGET_STRING("Control/Waveform Generator/Scaling/Integrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 73, 0, TARGET_STRING("Control/Waveform Generator/Scaling/Sign"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 74, 0, TARGET_STRING("Control/Waveform Generator/Scaling/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 75, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 76, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 77, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain10"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 78, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain11"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 79, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 80, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 81, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain4"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 82, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain5"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 83, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain6"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 84, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain7"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 85, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Gain8"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 86, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 87, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 88, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 89, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 90, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 91, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 92, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 93, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 94, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 95, 6, TARGET_STRING(
    "Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 96, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C1"),
    TARGET_STRING("C1"), 0, 0, 0, 0, 0 },

  { 97, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C2"),
    TARGET_STRING("C2"), 0, 0, 0, 0, 0 },

  { 98, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S1"),
    TARGET_STRING("S1"), 0, 0, 0, 0, 0 },

  { 99, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S2"),
    TARGET_STRING("S2"), 0, 0, 0, 0, 0 },

  { 100, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("test1"), 0, 0, 0, 0, 0 },

  { 101, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 102, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 103, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add10"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 104, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add11"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 105, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add12"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 106, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add13"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 107, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 108, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 109, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add4"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 110, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add6"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 111, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add7"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 112, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add8"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 113, 6, TARGET_STRING("Control/Waveform Generator/Walking waveform1/Add9"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 114, 0, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 115, 2, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/NegCounter/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 116, 2, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/NegCounter/Unit Delay"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 117, 3, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/PosCounter/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 118, 3, TARGET_STRING(
    "Control/SinCos Decoder/Zero Detect Counter1/PosCounter/Unit Delay"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 119, TARGET_STRING("Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 120, TARGET_STRING("Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 121, TARGET_STRING("Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 122, TARGET_STRING("Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 123, TARGET_STRING("Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 124, TARGET_STRING("Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 125, TARGET_STRING("Control/Repeating Sequence"),
    TARGET_STRING("rep_seq_y"), 0, 3, 0 },

  { 126, TARGET_STRING("Control/Repeating Sequence1"),
    TARGET_STRING("rep_seq_y"), 0, 4, 0 },

  { 127, TARGET_STRING("Control/Repeating Sequence2"),
    TARGET_STRING("rep_seq_y"), 0, 4, 0 },

  { 128, TARGET_STRING("Control/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 129, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P1"), 0, 0, 0 },

  { 130, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 131, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P3"), 0, 5, 0 },

  { 132, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P4"), 0, 0, 0 },

  { 133, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 134, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 135, TARGET_STRING("Signals/IO397 Analog Input"),
    TARGET_STRING("P7"), 0, 6, 0 },

  { 136, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P1"), 0, 0, 0 },

  { 137, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 138, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P3"), 0, 6, 0 },

  { 139, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P4"), 0, 0, 0 },

  { 140, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P5"), 0, 0, 0 },

  { 141, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 142, TARGET_STRING("Signals/IO397 Analog Input1"),
    TARGET_STRING("P7"), 0, 6, 0 },

  { 143, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P1"), 0, 0, 0 },

  { 144, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P2"), 0, 0, 0 },

  { 145, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P3"), 0, 5, 0 },

  { 146, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P4"), 0, 5, 0 },

  { 147, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P5"), 0, 5, 0 },

  { 148, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P6"), 0, 0, 0 },

  { 149, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P7"), 0, 6, 0 },

  { 150, TARGET_STRING("Signals/IO397 Analog Output1"),
    TARGET_STRING("P8"), 0, 0, 0 },

  { 151, TARGET_STRING("Control/Repeating Sequence/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 152, TARGET_STRING("Control/Repeating Sequence/Look-Up Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 3, 0 },

  { 153, TARGET_STRING("Control/Repeating Sequence1/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 154, TARGET_STRING("Control/Repeating Sequence1/Look-Up Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 4, 0 },

  { 155, TARGET_STRING("Control/Repeating Sequence2/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 156, TARGET_STRING("Control/Repeating Sequence2/Look-Up Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 4, 0 },

  { 157, TARGET_STRING("Control/SinCos Decoder/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 158, TARGET_STRING("Control/SinCos Decoder/Gain10"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 159, TARGET_STRING("Control/SinCos Decoder/Gain11"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 160, TARGET_STRING("Control/SinCos Decoder/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 161, TARGET_STRING("Control/SinCos Decoder/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 162, TARGET_STRING("Control/SinCos Decoder/Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 163, TARGET_STRING("Control/SinCos Decoder/Gain6"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 164, TARGET_STRING("Control/SinCos Decoder/Gain7"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 165, TARGET_STRING("Control/SinCos Decoder/Gain8"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 166, TARGET_STRING("Control/SinCos Decoder/Gain9"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 167, TARGET_STRING("Control/SinCos Decoder/Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 168, TARGET_STRING("Control/Subsystem/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 169, TARGET_STRING("Control/Subsystem/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 170, TARGET_STRING("Control/Waveform Generator/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 171, TARGET_STRING("Control/Waveform Generator/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 172, TARGET_STRING("Control/Waveform Generator/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 173, TARGET_STRING("Control/Waveform Generator/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 5, 0 },

  { 174, TARGET_STRING("Control/Waveform Generator/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 5, 0 },

  { 175, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 176, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/Hit  Crossing Neg"),
    TARGET_STRING("HitCrossingOffset"), 0, 0, 0 },

  { 177, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/Hit  Crossing Pos"),
    TARGET_STRING("HitCrossingOffset"), 0, 0, 0 },

  { 178, TARGET_STRING("Control/Waveform Generator/Scaling/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 179, TARGET_STRING("Control/Waveform Generator/Scaling/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 180, TARGET_STRING("Control/Waveform Generator/Scaling/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 181, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING("Table"), 0, 4, 0 },

  { 182, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 4, 0 },

  { 183, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 184, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 185, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0 tot 0.05"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 186, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 187, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 188, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 189, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 190, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp1"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 191, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 192, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 193, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 194, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 195, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 clamp2"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 196, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 197, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 198, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 199, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 200, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear1"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 201, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 202, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 203, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 204, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 205, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.05 tot 0.45 shear2"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 206, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 207, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 208, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 209, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 210, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp1"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 211, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 212, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 213, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 214, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 215, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 clamp2"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 216, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 217, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 218, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 219, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 220, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear1"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 221, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 222, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 223, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 224, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 225, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.55 tot 0.95 shear2"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 226, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING("Table"), 0, 4, 0 },

  { 227, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 4, 0 },

  { 228, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 229, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 230, TARGET_STRING("Control/Waveform Generator/Walking waveform1/0.95 tot 1"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 231, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C1"),
    TARGET_STRING("Table"), 0, 8, 0 },

  { 232, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 8, 0 },

  { 233, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C2"),
    TARGET_STRING("Table"), 0, 8, 0 },

  { 234, TARGET_STRING("Control/Waveform Generator/Walking waveform1/C2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 8, 0 },

  { 235, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S1"),
    TARGET_STRING("Table"), 0, 5, 0 },

  { 236, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 5, 0 },

  { 237, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S2"),
    TARGET_STRING("Table"), 0, 5, 0 },

  { 238, TARGET_STRING("Control/Waveform Generator/Walking waveform1/S2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 5, 0 },

  { 239, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("Table"), 0, 4, 0 },

  { 240, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 4, 0 },

  { 241, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 242, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("dimSizes"), 2, 0, 0 },

  { 243, TARGET_STRING("Control/Waveform Generator/Walking waveform1/clamp2"),
    TARGET_STRING("numYWorkElts"), 2, 1, 0 },

  { 244, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/NegCounter/Counts"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 245, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/NegCounter/Constant_neg"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 246, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/NegCounter/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 247, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/PosCounter/Counts"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 248, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/PosCounter/Constant_pos"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 249, TARGET_STRING("Control/SinCos Decoder/Zero Detect Counter1/PosCounter/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 250, TARGET_STRING("Clamp1Amp"), 0, 0, 0 },

  { 251, TARGET_STRING("Clamp2Amp"), 0, 0, 0 },

  { 252, TARGET_STRING("ClampsSineAmp"), 0, 0, 0 },

  { 253, TARGET_STRING("ShearAmp"), 0, 0, 0 },

  { 254, TARGET_STRING("backwardGain"), 0, 0, 0 },

  { 255, TARGET_STRING("clampofset"), 0, 0, 0 },

  { 256, TARGET_STRING("forwardGain"), 0, 0, 0 },

  { 257, TARGET_STRING("ofsetshear2"), 0, 0, 0 },

  { 258, TARGET_STRING("pAmpGain"), 0, 5, 0 },

  { 259, TARGET_STRING("pAngleCorrection"), 0, 0, 0 },

  { 260, TARGET_STRING("pClampAmpl"), 0, 0, 0 },

  { 261, TARGET_STRING("pClampOffs"), 0, 0, 0 },

  { 262, TARGET_STRING("pCosineGain"), 0, 0, 0 },

  { 263, TARGET_STRING("pCosineOffset"), 0, 0, 0 },

  { 264, TARGET_STRING("pEncRes"), 0, 0, 0 },

  { 265, TARGET_STRING("pShearAmpl"), 0, 0, 0 },

  { 266, TARGET_STRING("pShearOffs"), 0, 0, 0 },

  { 267, TARGET_STRING("pSineGain"), 0, 0, 0 },

  { 268, TARGET_STRING("pSineOffset"), 0, 0, 0 },

  { 269, TARGET_STRING("tSample"), 0, 0, 0 },

  { 270, TARGET_STRING("u_ff"), 0, 9, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &Model_B.Error,                      /* 0: Signal */
  &Model_B.Velocity,                   /* 1: Signal */
  &Model_B.Position,                   /* 2: Signal */
  &Model_B.CommAngle,                  /* 3: Signal */
  &Model_B.ClampAnl[0],                /* 4: Signal */
  &Model_B.ShearAnl[0],                /* 5: Signal */
  &Model_B.reference,                  /* 6: Signal */
  &Model_B.error,                      /* 7: Signal */
  &Model_B.Sum_g,                      /* 8: Signal */
  &Model_B.IO397AnalogInput_o1,        /* 9: Signal */
  &Model_B.IO397AnalogInput_o2,        /* 10: Signal */
  &Model_B.IO397AnalogInput_o3,        /* 11: Signal */
  &Model_B.IO397AnalogInput_o4,        /* 12: Signal */
  &Model_B.IO397AnalogInput1_o1,       /* 13: Signal */
  &Model_B.IO397AnalogInput1_o2,       /* 14: Signal */
  &Model_B.Clock,                      /* 15: Signal */
  &Model_B.Output,                     /* 16: Signal */
  &Model_B.LookUpTable1,               /* 17: Signal */
  &Model_B.MathFunction,               /* 18: Signal */
  &Model_B.Sum,                        /* 19: Signal */
  &Model_B.Clock_h,                    /* 20: Signal */
  &Model_B.Output_a,                   /* 21: Signal */
  &Model_B.LookUpTable1_d,             /* 22: Signal */
  &Model_B.MathFunction_e,             /* 23: Signal */
  &Model_B.Sum_d,                      /* 24: Signal */
  &Model_B.Clock_f,                    /* 25: Signal */
  &Model_B.Output_d,                   /* 26: Signal */
  &Model_B.LookUpTable1_b,             /* 27: Signal */
  &Model_B.MathFunction_a,             /* 28: Signal */
  &Model_B.Sum_m,                      /* 29: Signal */
  &Model_B.sinC,                       /* 30: Signal */
  &Model_B.cosC,                       /* 31: Signal */
  &Model_B.encRef[0],                  /* 32: Signal */
  &Model_B.encCosUnc,                  /* 33: Signal */
  &Model_B.idealPos,                   /* 34: Signal */
  &Model_B.Gain2,                      /* 35: Signal */
  &Model_B.encCount,                   /* 36: Signal */
  &Model_B.Gain4,                      /* 37: Signal */
  &Model_B.encSinCor,                  /* 38: Signal */
  &Model_B.encInt,                     /* 39: Signal */
  &Model_B.Gain7,                      /* 40: Signal */
  &Model_B.encCosCor,                  /* 41: Signal */
  &Model_B.encSinUnc,                  /* 42: Signal */
  &Model_B.Divide,                     /* 43: Signal */
  &Model_B.Add,                        /* 44: Signal */
  &Model_B.Add1,                       /* 45: Signal */
  &Model_B.SumofElements,              /* 46: Signal */
  &Model_B.SumofElements1,             /* 47: Signal */
  &Model_B.Sum1,                       /* 48: Signal */
  &Model_B.atan2_l,                    /* 49: Signal */
  &Model_B.Delay,                      /* 50: Signal */
  &Model_B.Memory,                     /* 51: Signal */
  &Model_B.index_counter,              /* 52: Signal */
  &Model_B.DirectLookupTablenD,        /* 53: Signal */
  &Model_B.Gain1[0],                   /* 54: Signal */
  &Model_B.Gain2_j[0],                 /* 55: Signal */
  &Model_B.ClampTru[0],                /* 56: Signal */
  &Model_B.ShearTru[0],                /* 57: Signal */
  &Model_B.Gain7_j[0],                 /* 58: Signal */
  &Model_B.alpha_mod,                  /* 59: Signal */
  &Model_B.Saturation[0],              /* 60: Signal */
  &Model_B.Sum_i[0],                   /* 61: Signal */
  &Model_B.Sum1_o[0],                  /* 62: Signal */
  &Model_B.HitCrossingNeg,             /* 63: Signal */
  &Model_B.HitCrossingPos,             /* 64: Signal */
  &Model_B.LogicalOperatorNeg,         /* 65: Signal */
  &Model_B.LogicalOperatorPos,         /* 66: Signal */
  &Model_B.Add2,                       /* 67: Signal */
  &Model_B.Derivative,                 /* 68: Signal */
  &Model_B.Gain1_f,                    /* 69: Signal */
  &Model_B.Gain2_m4,                   /* 70: Signal */
  &Model_B.alpha,                      /* 71: Signal */
  &Model_B.Integrator,                 /* 72: Signal */
  &Model_B.Sign,                       /* 73: Signal */
  &Model_B.Switch,                     /* 74: Signal */
  &Model_B.Gain,                       /* 75: Signal */
  &Model_B.Gain1_i,                    /* 76: Signal */
  &Model_B.Gain10,                     /* 77: Signal */
  &Model_B.Gain11,                     /* 78: Signal */
  &Model_B.Gain2_m,                    /* 79: Signal */
  &Model_B.Gain3,                      /* 80: Signal */
  &Model_B.Gain4_g,                    /* 81: Signal */
  &Model_B.Gain5,                      /* 82: Signal */
  &Model_B.Gain6,                      /* 83: Signal */
  &Model_B.Gain7_c,                    /* 84: Signal */
  &Model_B.Gain8,                      /* 85: Signal */
  &Model_B.utot005,                    /* 86: Signal */
  &Model_B.u05tot045clamp1,            /* 87: Signal */
  &Model_B.u05tot045clamp2,            /* 88: Signal */
  &Model_B.u05tot045shear1,            /* 89: Signal */
  &Model_B.u05tot045shear2,            /* 90: Signal */
  &Model_B.u55tot095clamp1,            /* 91: Signal */
  &Model_B.u55tot095clamp2,            /* 92: Signal */
  &Model_B.u55tot095shear1,            /* 93: Signal */
  &Model_B.u55tot095shear2,            /* 94: Signal */
  &Model_B.u95tot1,                    /* 95: Signal */
  &Model_B.C1,                         /* 96: Signal */
  &Model_B.C2,                         /* 97: Signal */
  &Model_B.S1,                         /* 98: Signal */
  &Model_B.S2,                         /* 99: Signal */
  &Model_B.test1,                      /* 100: Signal */
  &Model_B.Add_k,                      /* 101: Signal */
  &Model_B.Add1_h,                     /* 102: Signal */
  &Model_B.Add10,                      /* 103: Signal */
  &Model_B.Add11,                      /* 104: Signal */
  &Model_B.Add12,                      /* 105: Signal */
  &Model_B.Add13,                      /* 106: Signal */
  &Model_B.Add2_h,                     /* 107: Signal */
  &Model_B.Add3,                       /* 108: Signal */
  &Model_B.Add4,                       /* 109: Signal */
  &Model_B.Add6,                       /* 110: Signal */
  &Model_B.Add7,                       /* 111: Signal */
  &Model_B.Add8,                       /* 112: Signal */
  &Model_B.Add9,                       /* 113: Signal */
  &Model_B.Compare,                    /* 114: Signal */
  &Model_B.Sum_dz,                     /* 115: Signal */
  &Model_B.UnitDelay_p,                /* 116: Signal */
  &Model_B.Sum_a,                      /* 117: Signal */
  &Model_B.UnitDelay,                  /* 118: Signal */
  &Model_P.Gain_Gain,                  /* 119: Block Parameter */
  &Model_P.Gain1_Gain_d,               /* 120: Block Parameter */
  &Model_P.Gain2_Gain,                 /* 121: Block Parameter */
  &Model_P.Gain3_Gain_a,               /* 122: Block Parameter */
  &Model_P.Gain4_Gain_p,               /* 123: Block Parameter */
  &Model_P.Gain5_Gain_k,               /* 124: Block Parameter */
  &Model_P.RepeatingSequence_rep_seq_y[0],/* 125: Mask Parameter */
  &Model_P.RepeatingSequence1_rep_seq_y[0],/* 126: Mask Parameter */
  &Model_P.RepeatingSequence2_rep_seq_y[0],/* 127: Mask Parameter */
  &Model_P.Gain1_Gain,                 /* 128: Block Parameter */
  &Model_P.IO397AnalogInput_P1,        /* 129: Block Parameter */
  &Model_P.IO397AnalogInput_P2,        /* 130: Block Parameter */
  &Model_P.IO397AnalogInput_P3[0],     /* 131: Block Parameter */
  &Model_P.IO397AnalogInput_P4,        /* 132: Block Parameter */
  &Model_P.IO397AnalogInput_P5,        /* 133: Block Parameter */
  &Model_P.IO397AnalogInput_P6,        /* 134: Block Parameter */
  &Model_P.IO397AnalogInput_P7[0],     /* 135: Block Parameter */
  &Model_P.IO397AnalogInput1_P1,       /* 136: Block Parameter */
  &Model_P.IO397AnalogInput1_P2,       /* 137: Block Parameter */
  &Model_P.IO397AnalogInput1_P3[0],    /* 138: Block Parameter */
  &Model_P.IO397AnalogInput1_P4,       /* 139: Block Parameter */
  &Model_P.IO397AnalogInput1_P5,       /* 140: Block Parameter */
  &Model_P.IO397AnalogInput1_P6,       /* 141: Block Parameter */
  &Model_P.IO397AnalogInput1_P7[0],    /* 142: Block Parameter */
  &Model_P.IO397AnalogOutput1_P1,      /* 143: Block Parameter */
  &Model_P.IO397AnalogOutput1_P2,      /* 144: Block Parameter */
  &Model_P.IO397AnalogOutput1_P3[0],   /* 145: Block Parameter */
  &Model_P.IO397AnalogOutput1_P4[0],   /* 146: Block Parameter */
  &Model_P.IO397AnalogOutput1_P5[0],   /* 147: Block Parameter */
  &Model_P.IO397AnalogOutput1_P6,      /* 148: Block Parameter */
  &Model_P.IO397AnalogOutput1_P7[0],   /* 149: Block Parameter */
  &Model_P.IO397AnalogOutput1_P8,      /* 150: Block Parameter */
  &Model_P.Constant_Value,             /* 151: Block Parameter */
  &Model_P.LookUpTable1_bp01Data[0],   /* 152: Block Parameter */
  &Model_P.Constant_Value_o,           /* 153: Block Parameter */
  &Model_P.LookUpTable1_bp01Data_h[0], /* 154: Block Parameter */
  &Model_P.Constant_Value_n,           /* 155: Block Parameter */
  &Model_P.LookUpTable1_bp01Data_b[0], /* 156: Block Parameter */
  &Model_P.Gain1_Gain_n,               /* 157: Block Parameter */
  &Model_P.Gain10_Gain,                /* 158: Block Parameter */
  &Model_P.Gain11_Gain,                /* 159: Block Parameter */
  &Model_P.Gain3_Gain,                 /* 160: Block Parameter */
  &Model_P.Gain4_Gain,                 /* 161: Block Parameter */
  &Model_P.Gain5_Gain,                 /* 162: Block Parameter */
  &Model_P.Gain6_Gain,                 /* 163: Block Parameter */
  &Model_P.Gain7_Gain,                 /* 164: Block Parameter */
  &Model_P.Gain8_Gain,                 /* 165: Block Parameter */
  &Model_P.Gain9_Gain,                 /* 166: Block Parameter */
  &Model_P.Delay_InitialCondition,     /* 167: Block Parameter */
  &Model_P.Constant_Value_i,           /* 168: Block Parameter */
  &Model_P.Memory_InitialCondition,    /* 169: Block Parameter */
  &Model_P.Constant2_Value,            /* 170: Block Parameter */
  &Model_P.Gain3_Gain_o,               /* 171: Block Parameter */
  &Model_P.Gain4_Gain_c,               /* 172: Block Parameter */
  &Model_P.Saturation_UpperSat[0],     /* 173: Block Parameter */
  &Model_P.Saturation_LowerSat[0],     /* 174: Block Parameter */
  &Model_P.CompareToConstant_const,    /* 175: Mask Parameter */
  &Model_P.HitCrossingNeg_Offset,      /* 176: Block Parameter */
  &Model_P.HitCrossingPos_Offset,      /* 177: Block Parameter */
  &Model_P.Gain3_Gain_k,               /* 178: Block Parameter */
  &Model_P.Integrator_IC,              /* 179: Block Parameter */
  &Model_P.Switch_Threshold,           /* 180: Block Parameter */
  &Model_P.utot005_tableData[0],       /* 181: Block Parameter */
  &Model_P.utot005_bp01Data[0],        /* 182: Block Parameter */
  &Model_P.utot005_maxIndex,           /* 183: Block Parameter */
  &Model_P.utot005_dimSizes,           /* 184: Block Parameter */
  &Model_P.utot005_numYWorkElts[0],    /* 185: Block Parameter */
  &Model_P.u05tot045clamp1_tableData[0],/* 186: Block Parameter */
  &Model_P.u05tot045clamp1_bp01Data[0],/* 187: Block Parameter */
  &Model_P.u05tot045clamp1_maxIndex,   /* 188: Block Parameter */
  &Model_P.u05tot045clamp1_dimSizes,   /* 189: Block Parameter */
  &Model_P.u05tot045clamp1_numYWorkElts[0],/* 190: Block Parameter */
  &Model_P.u05tot045clamp2_tableData[0],/* 191: Block Parameter */
  &Model_P.u05tot045clamp2_bp01Data[0],/* 192: Block Parameter */
  &Model_P.u05tot045clamp2_maxIndex,   /* 193: Block Parameter */
  &Model_P.u05tot045clamp2_dimSizes,   /* 194: Block Parameter */
  &Model_P.u05tot045clamp2_numYWorkElts[0],/* 195: Block Parameter */
  &Model_P.u05tot045shear1_tableData[0],/* 196: Block Parameter */
  &Model_P.u05tot045shear1_bp01Data[0],/* 197: Block Parameter */
  &Model_P.u05tot045shear1_maxIndex,   /* 198: Block Parameter */
  &Model_P.u05tot045shear1_dimSizes,   /* 199: Block Parameter */
  &Model_P.u05tot045shear1_numYWorkElts[0],/* 200: Block Parameter */
  &Model_P.u05tot045shear2_tableData[0],/* 201: Block Parameter */
  &Model_P.u05tot045shear2_bp01Data[0],/* 202: Block Parameter */
  &Model_P.u05tot045shear2_maxIndex,   /* 203: Block Parameter */
  &Model_P.u05tot045shear2_dimSizes,   /* 204: Block Parameter */
  &Model_P.u05tot045shear2_numYWorkElts[0],/* 205: Block Parameter */
  &Model_P.u55tot095clamp1_tableData[0],/* 206: Block Parameter */
  &Model_P.u55tot095clamp1_bp01Data[0],/* 207: Block Parameter */
  &Model_P.u55tot095clamp1_maxIndex,   /* 208: Block Parameter */
  &Model_P.u55tot095clamp1_dimSizes,   /* 209: Block Parameter */
  &Model_P.u55tot095clamp1_numYWorkElts[0],/* 210: Block Parameter */
  &Model_P.u55tot095clamp2_tableData[0],/* 211: Block Parameter */
  &Model_P.u55tot095clamp2_bp01Data[0],/* 212: Block Parameter */
  &Model_P.u55tot095clamp2_maxIndex,   /* 213: Block Parameter */
  &Model_P.u55tot095clamp2_dimSizes,   /* 214: Block Parameter */
  &Model_P.u55tot095clamp2_numYWorkElts[0],/* 215: Block Parameter */
  &Model_P.u55tot095shear1_tableData[0],/* 216: Block Parameter */
  &Model_P.u55tot095shear1_bp01Data[0],/* 217: Block Parameter */
  &Model_P.u55tot095shear1_maxIndex,   /* 218: Block Parameter */
  &Model_P.u55tot095shear1_dimSizes,   /* 219: Block Parameter */
  &Model_P.u55tot095shear1_numYWorkElts[0],/* 220: Block Parameter */
  &Model_P.u55tot095shear2_tableData[0],/* 221: Block Parameter */
  &Model_P.u55tot095shear2_bp01Data[0],/* 222: Block Parameter */
  &Model_P.u55tot095shear2_maxIndex,   /* 223: Block Parameter */
  &Model_P.u55tot095shear2_dimSizes,   /* 224: Block Parameter */
  &Model_P.u55tot095shear2_numYWorkElts[0],/* 225: Block Parameter */
  &Model_P.u95tot1_tableData[0],       /* 226: Block Parameter */
  &Model_P.u95tot1_bp01Data[0],        /* 227: Block Parameter */
  &Model_P.u95tot1_maxIndex,           /* 228: Block Parameter */
  &Model_P.u95tot1_dimSizes,           /* 229: Block Parameter */
  &Model_P.u95tot1_numYWorkElts[0],    /* 230: Block Parameter */
  &Model_P.C1_tableData[0],            /* 231: Block Parameter */
  &Model_P.C1_bp01Data[0],             /* 232: Block Parameter */
  &Model_P.C2_tableData[0],            /* 233: Block Parameter */
  &Model_P.C2_bp01Data[0],             /* 234: Block Parameter */
  &Model_P.S1_tableData[0],            /* 235: Block Parameter */
  &Model_P.S1_bp01Data[0],             /* 236: Block Parameter */
  &Model_P.S2_tableData[0],            /* 237: Block Parameter */
  &Model_P.S2_bp01Data[0],             /* 238: Block Parameter */
  &Model_P.clamp2_tableData[0],        /* 239: Block Parameter */
  &Model_P.clamp2_bp01Data[0],         /* 240: Block Parameter */
  &Model_P.clamp2_maxIndex,            /* 241: Block Parameter */
  &Model_P.clamp2_dimSizes,            /* 242: Block Parameter */
  &Model_P.clamp2_numYWorkElts[0],     /* 243: Block Parameter */
  &Model_P.Counts_Y0,                  /* 244: Block Parameter */
  &Model_P.Constant_neg_Value,         /* 245: Block Parameter */
  &Model_P.UnitDelay_InitialCondition, /* 246: Block Parameter */
  &Model_P.Counts_Y0_h,                /* 247: Block Parameter */
  &Model_P.Constant_pos_Value,         /* 248: Block Parameter */
  &Model_P.UnitDelay_InitialCondition_n,/* 249: Block Parameter */
  &Model_P.Clamp1Amp,                  /* 250: Model Parameter */
  &Model_P.Clamp2Amp,                  /* 251: Model Parameter */
  &Model_P.ClampsSineAmp,              /* 252: Model Parameter */
  &Model_P.ShearAmp,                   /* 253: Model Parameter */
  &Model_P.backwardGain,               /* 254: Model Parameter */
  &Model_P.clampofset,                 /* 255: Model Parameter */
  &Model_P.forwardGain,                /* 256: Model Parameter */
  &Model_P.ofsetshear2,                /* 257: Model Parameter */
  &Model_P.pAmpGain[0],                /* 258: Model Parameter */
  &Model_P.pAngleCorrection,           /* 259: Model Parameter */
  &Model_P.pClampAmpl,                 /* 260: Model Parameter */
  &Model_P.pClampOffs,                 /* 261: Model Parameter */
  &Model_P.pCosineGain,                /* 262: Model Parameter */
  &Model_P.pCosineOffset,              /* 263: Model Parameter */
  &Model_P.pEncRes,                    /* 264: Model Parameter */
  &Model_P.pShearAmpl,                 /* 265: Model Parameter */
  &Model_P.pShearOffs,                 /* 266: Model Parameter */
  &Model_P.pSineGain,                  /* 267: Model Parameter */
  &Model_P.pSineOffset,                /* 268: Model Parameter */
  &Model_P.tSample,                    /* 269: Model Parameter */
  &Model_P.u_ff[0],                    /* 270: Model Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  2,                                   /* 2 */
  1,                                   /* 3 */
  4,                                   /* 4 */
  1,                                   /* 5 */
  1,                                   /* 6 */
  7,                                   /* 7 */
  1,                                   /* 8 */
  3,                                   /* 9 */
  1,                                   /* 10 */
  4,                                   /* 11 */
  1,                                   /* 12 */
  2,                                   /* 13 */
  1,                                   /* 14 */
  5,                                   /* 15 */
  1,                                   /* 16 */
  6,                                   /* 17 */
  51000,                               /* 18 */
  1                                    /* 19 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 0.0001
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[0],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[0],
    1, 0 },

  { (NULL), (NULL), -1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 119,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 131,
    rtModelParameters, 21 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 4141504546U,
    2492853434U,
    925271582U,
    2801460151U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  Model_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void Model_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(Model_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(Model_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(Model_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(Model_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(Model_M->DataMapInfo.mmi, rtVarDimsAddrMap);

  /* Cache C-API rtp Address and size  into the Real-Time Model Data structure */
  Model_M->DataMapInfo.mmi.InstanceMap.rtpAddress = rtmGetDefaultParam(Model_M);
  Model_M->DataMapInfo.mmi.staticMap->rtpSize = sizeof(P_Model_T);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(Model_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(Model_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(Model_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void Model_host_InitializeDataMapInfo(Model_host_DataMapInfo_T *dataMap, const
    char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: Model_capi.c */
