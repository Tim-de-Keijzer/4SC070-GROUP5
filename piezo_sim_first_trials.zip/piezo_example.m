clc
clear


%% Piezo model example

% This example  script is inspired by Figures 2, 3 and 8 of the following 
% paper: http://www.toomen.eu/pdf/StrijboschTacVerOom2019.pdf

% The Piezo actuator is simulated as if commutation functions are 
% implemented 'under the hood'. The commutation functions  are not 
% explicitly in the model. 

% Two example piezo models are included:
%   (a) the commutation functions lead to a monotone y-alpha relationship
%   (b) the commutation functions lead to an y-alpha relationship that is
%   not invertible. 

% Start with use_monotone_function = true and implement your ILC/RC 
% approach to accurately track the reference in the exercise. Then, set 
% use_monotone_function = false. does your implementation still work? 
% If not, how can you ensure good tracking performance on the experimental 
% setup if the piezo behaves like case (b)? 

use_monotone_function = false;


%% Set Piezo parameters

if ~use_monotone_function
    c = 0.8;
else
    c = 0.2;
end
piezo_gain = 1e-7;

load("time_array.mat")
amount_it = 5;
%% Simulate Piezo
% error = [out.error.Time zeros(4011,1)];
% % Edit the simulink file to include your ILC/RC implementation
% 
% for i = 1:amount_it
%     out = sim('piezo_sim');
%     error = out.error.Data;
%     error = [out.error.Time out.error.Data];
% end

figure(1); clf;
subplot(2,1,1)
plot(out.alpha_mod)
ylim([0 2*pi])
title('Commutation angle')
ylabel('Alpha [rad]')
xlabel('Time [s]')
grid on

subplot(2,1,2)
plot(out.y)
title('Piezo position')
ylabel('Position [m]')
xlabel('Time [s]')
grid on
